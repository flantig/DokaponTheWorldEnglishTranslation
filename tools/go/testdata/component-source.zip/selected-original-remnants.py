def remnants(orig, s):
    """opaque connected pieces inside s['in'] that contain no white pixel (= bits of
    old letters poking out below the erase zone, not the white thought bubbles)."""
    x, y, w, h = s['in']
    sub = orig[y:y + h, x:x + w]
    if s.get('bg') == 'cream':
        op = np.abs(sub[..., :3].astype(np.int32) - np.array(CREAM[:3])).max(axis=2) > s.get('tol', 12)
    else:
        op = sub[..., 3] > s.get('alpha_gt', 8)
    white = (sub[..., :3].min(axis=2) > 225) & op
    lab, n = ndi.label(op, np.ones((3, 3), bool))
    keep = set(np.unique(lab[white])) - {0}
    m = op & ~np.isin(lab, list(keep))
    out = np.zeros(orig.shape[:2], bool)
    out[y:y + h, x:x + w] = m
    return out
