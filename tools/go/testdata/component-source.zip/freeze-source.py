from pathlib import Path
import ast, datetime, hashlib, json, zipfile
import numpy as np
from scipy import ndimage as ndi

out=Path(__file__).parent;core=Path('/var/tmp/dokapon-original-permission-source-jdo2V5Rg')
core_hash='4c6e945eeb8643ece9597941c0dd20f28bf1947b308cc2b3ad862fbb2ef16222'
assert hashlib.sha256((core/'manifest.json').read_bytes()).hexdigest()==core_hash
for rel,row in json.loads((core/'manifest.json').read_text()).items():
 data=(core/rel).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
census=json.loads((core/'resolved-provider-census.json').read_text());providers=[p for p in census['providers'] if p['provider'] in {'batch_c_card_art:art_components','batch_c_logo_art:remnants','batch_c_card_art:g03_bursts'}]
records=[r for p in providers for r in p['records'] if not r['maskfn'].endswith(':g03_bursts')];burst=next(p for p in providers if p['provider'].endswith(':g03_bursts'))['records'][0]
assert len(records)==6
for rel in ['sources/batch_c_card_art.py','sources/batch_c_logo_art.py','sources/specs/batch_c.json','selected-batch_c_card_art.py','library-provenance.json']:
 data=(core/rel).read_bytes();dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
card={'np':np,'ndi':ndi};exec(compile(ast.parse((core/'selected-batch_c_card_art.py').read_text()),'AST-only-original-card','exec'),card)
tree=ast.parse((core/'sources/batch_c_logo_art.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='remnants'];assert len(nodes)==1
program=ast.Module(body=nodes,type_ignores=[]);(out/'selected-original-remnants.py').write_text(ast.unparse(program)+'\n');logo={'np':np,'ndi':ndi,'CREAM':(254,230,154,255)};exec(compile(program,'AST-only-original-remnants','exec'),logo)

fixtures={};fixture_records=[]
for phase,name in enumerate(['components-A','components-B']):
 a=np.empty((512,512,4),np.uint8);a[:]=[244,195,110,0] if phase==0 else [238,187,100,255]
 # Two seeded art areas: connected diagonal/edge branches and separate unseeded pieces.
 a[137:144+phase,82:89+phase]=[0,0,0,0]
 a[140,55:86]=[0,0,0,255];a[144,89]=[0,0,0,255];a[145:151,90:97+phase]=[10,20,30,0]
 a[138:143+phase,427:434+phase]=[0,0,0,255];a[140,430:465]=[0,0,0,255]
 a[168:173+phase,185:190+phase]=[0,0,0,0];a[173+phase,190+phase]=[0,0,0,255]
 a[180:184,200:204]=[0,0,0,255] # unseeded component must remain unselected
 # Cream-mode remnants ignores alpha, with inclusive near12 and strictwhite>225.
 a[80:85,168:336]=[254,230,154,0]
 a[81:83,173:182+phase]=[100,10,10,0]
 a[81,200]=[0,0,0,255];a[82,201]=[226,226,226,0];a[83,202]=[0,0,0,255]
 a[81,220]=[242,230,154,255];a[81,223]=[241,230,154,0]
 a[83,240:243+phase]=[225,225,225,9]
 # Alpha-mode remnants: hidden white is not foreground; alpha8 is excluded.
 a[87:95,32:221]=[250,250,250,0]
 a[88:90,40:46+phase]=[0,0,0,9]
 a[89,79]=[0,0,0,255];a[90,80]=[226,226,226,9];a[91,81]=[0,0,0,255]
 a[90,100]=[0,0,0,9];a[91,101]=[226,226,226,8]
 a[93,120:123+phase]=[225,225,225,9]
 # g03 actual crop gets hidden-RGB positives at a crop edge and a separated whitepatch.
 a[150,100]=[255,100,100,0];a[280:282+phase,400:403]=[226,226,216,0]
 if phase:a[155,120:123]=[236,100,127,0]
 raw=a.tobytes();(out/(name+'.rgba')).write_bytes(raw);fixtures[name]=a;fixture_records.append({'id':name,'raw':name+'.rgba','shape':[512,512,4],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'construction':'Literal deterministic assignments in freeze-source.py. No RNG, sourceart or candidate values. Source seeds/threshold/cropgeometry remain unchanged.'})

cases=[]
# Small exact masks, with manually enumerated expectations independent of source output.
for name,seed,point in [('left-of-crop-wrap',[0,2],[3,2]),('negative-global-wrap',[-1,2],[2,2]),('above-crop-wrap',[2,0],[2,3])]:
 a=np.empty((5,5,4),np.uint8);a[:]=[244,195,110,255];a[point[1],point[0]]=[0,0,0,0]
 cases.append({'id':name,'provider':'art_components','original':a,'spec':{'in':[1,1,3,3],'seeds':[seed],'grow':0},'manual_ones':[point],'equation':'Source subtracts croporigin then uses NumPyindexing; localindices within[-dimension,-1] wrap rather than rejecting out-of-crop/globalnegative seeds.'})
a=np.empty((5,5,4),np.uint8);a[:]=[244,195,110,255]
for x,y in [(0,0),(4,4)]:a[y,x]=[0,0,0,0]
for name,seeds,ones in [('multiple-and-duplicate-seeds',[[0,0],[4,4],[0,0]],[[0,0],[4,4]]),('empty-seeds',[],[])]:cases.append({'id':name,'provider':'art_components','original':a,'spec':{'in':[0,0,5,5],'seeds':seeds,'grow':1 if not seeds else 0},'manual_ones':ones,'equation':'Unionforeground seedcomponents; duplicatesidempotent, emptylist yields empty source mask withoutrefusal.'})
a=np.empty((3,8,4),np.uint8);a[:]=[244,195,110,255]
values=[[238,187,100,0],[250,203,120,255],[237,195,110,0],[251,195,110,255],[244,186,110,0],[244,204,110,255],[244,195,99,0],[244,195,121,255]];a[1]=values
cases.append({'id':'panel-inclusive-cube-alpha-independent','provider':'art_components','original':a,'spec':{'in':[0,0,8,3],'seeds':[[x,1] for x in range(2,8)],'grow':0},'manual_ones':[[x,1] for x in range(2,8)],'equation':'Panel=R238..250 ANDG187..203 ANDB100..120 inclusively. Nonpanelcomplement selected independent ofalpha; exactedgevalues remainpanel.'})
for grow in [1,0,-1]:
 a=np.empty((7,7,4),np.uint8);a[:]=[244,195,110,255];a[3,3]=[0,0,0,0]
 ones=[[3,3],[2,3],[4,3],[3,2],[3,4]] if grow==1 else [[3,3]]
 cases.append({'id':'art-fullcanvas-grow-'+str(grow),'provider':'art_components','original':a,'spec':{'in':[3,3,2,2],'seeds':[[3,3]],'grow':grow},'manual_ones':ones,'equation':'Art8labelincrop ->seedunion ->embed ->default4growthonwholecanvas onlyifGrow>0. Cropedgecanexpandoutside; zeroANDnegativegrowthskipcall.'})
for alpha in [8,9]:
 a=np.empty((5,5,4),np.uint8);a[:]=[250,250,250,0];a[1,1]=[0,0,0,9];a[2,2]=[226,226,226,alpha];a[0,4]=[0,0,0,9]
 cases.append({'id':'remnant-alpha-white-tag-'+str(alpha),'provider':'remnants','original':a,'spec':{'in':[0,0,5,5]},'manual_ones':[[1,1],[4,0]] if alpha==8 else [[4,0]],'equation':'Foregroundalpha>8. White=minRGB>225 ANDforeground, so excludedwhitealpha8doesnotreject neighboringcomponent; alpha9joinsdiagonallyand rejectswhole8component.'})
a=np.empty((3,6,4),np.uint8);a[:]=[254,230,154,0];a[1,0]=[242,230,154,255];a[1,2]=[241,230,154,0];a[1,4]=[225,225,225,0]
cases.append({'id':'cream-notnear12-hidden-RGB','provider':'remnants','original':a,'spec':{'in':[0,0,6,3],'bg':'cream'},'manual_ones':[[2,1],[4,1]],'equation':'Cream foregroundMaxRGBdistance>12, alphaignored. Distance12isnotforeground,13is. White225doesnotmeettagthreshold>225.'})
a=np.empty((5,5,4),np.uint8);a[:]=[250,250,250,0]
for x,y in [(1,1),(2,2),(3,3),(4,0)]:a[y,x]=[0,0,0,9]
a[2,2]=[226,226,226,9]
cases.append({'id':'remnant-component-wide-diagonal-rejection','provider':'remnants','original':a,'spec':{'in':[0,0,5,5],'grow':99},'manual_ones':[[4,0]],'equation':'One8component containing anywhiteforegroundpixel isremovedinfull, notjustwhitepixels. Source ignores suppliedgrowfield; no morphology follows rejection.'})

# Separate g03 predicate/domain cases; grow0/negative invokes untilstable, unlike art.
samples=[[236,100,127,0],[236,100,128,255],[236,127,100,0],[236,128,100,255],[235,100,100,0],[255,239,212,0],[255,240,213,255],[226,226,216,0],[225,226,216,255],[226,225,216,0],[226,226,215,255]]
a=np.zeros((5,4*len(samples)+3,4),np.uint8);positive={0,2,5,7};ones=[]
for i,v in enumerate(samples):
 x=4*i+2;a[2,x]=v
 if i in positive:ones.extend([[x,2],[x-1,2],[x+1,2],[x,1],[x,3]])
cases.append({'id':'g03-strict-pink-white-boundaries','provider':'g03_bursts','original':a,'spec':{'in':[0,0,a.shape[1],5],'grow':1},'manual_ones':ones,'equation':'Pink:R>235 ANDabs(G-B)<28 ANDG<240; white:R>225 ANDG>225 ANDB>215. Alphaignored. Separatedsamples avoidcrossgrowthhiding thresholdties.'})
for grow in [0,-1]:
 a=np.zeros((7,7,4),np.uint8);a[3,3]=[255,100,100,0]
 cases.append({'id':'g03-grow-until-stable-'+str(grow),'provider':'g03_bursts','original':a,'spec':{'in':[3,3,1,1],'grow':grow},'manual_ones':[[x,y] for y in range(7) for x in range(7)],'equation':'g03unconditionallypassesiterations toSciPy; zeroORnegativeiteratesdefault4dilationuntilstable, yieldingwholecanvaswhenanyforegroundexists.'})

(out/'blobs').mkdir(exist_ok=True);expected_actual={};mask_cases=[]
for name,a in fixtures.items():
 before=hashlib.sha256(a.tobytes()).hexdigest();expected_actual[name]={}
 for i,r in enumerate(records+[burst]):
  symbol=r['maskfn'].split(':')[1];env=logo if symbol=='remnants' else card;m=env[symbol](a,r['shape']);raw=(m.astype(np.uint8)*255).tobytes();sha=hashlib.sha256(raw).hexdigest();rel='blobs/'+sha+'.mask';(out/rel).write_bytes(raw);assert m.any();assert hashlib.sha256(a.tobytes()).hexdigest()==before
  expected_actual[name]['actual/%02d'%i]={'source_record':r,'expected_mask':rel,'sha256':sha,'selected_pixels':int(m.sum()),'source_original_unchanged':True}
assert all(expected_actual['components-A'][k]['sha256']!=expected_actual['components-B'][k]['sha256'] for k in expected_actual['components-A'])
for case in cases:
 a=case.pop('original');before=hashlib.sha256(a.tobytes()).hexdigest();env=logo if case['provider']=='remnants' else card;m=env[case['provider']](a,case['spec']);manual=np.zeros(a.shape[:2],bool)
 for x,y in case['manual_ones']:manual[y,x]=True
 assert np.array_equal(m,manual),case['id'];assert hashlib.sha256(a.tobytes()).hexdigest()==before
 raw=(m.astype(np.uint8)*255).tobytes();sha=hashlib.sha256(raw).hexdigest();rel='blobs/'+sha+'.mask';(out/rel).write_bytes(raw);inputrel='inputs/'+before+'.rgba';dest=out/inputrel;dest.parent.mkdir(exist_ok=True);dest.write_bytes(a.tobytes());case.update({'shape':list(a.shape),'original_raw':inputrel,'original_sha256':before,'expected_mask':rel,'mask_sha256':sha,'selected_pixels':int(m.sum()),'manual_fullmask_equals_original_helper':True});mask_cases.append(case)

a=np.empty((5,5,4),np.uint8);a[:]=[244,195,110,255];a[2,2]=[0,0,0,0]
refusals=[]
for name,spec in [('panel-seed',{'in':[1,1,3,3],'seeds':[[1,1]]}),('right-of-crop',{'in':[1,1,3,3],'seeds':[[4,2]]}),('below-crop',{'in':[1,1,3,3],'seeds':[[2,4]]}),('too-negative-local',{'in':[1,1,3,3],'seeds':[[-3,2]]}),('missing-seeds',{'in':[1,1,3,3]}),('bad-seed-arity',{'in':[1,1,3,3],'seeds':[[2]]}),('fractional-seed',{'in':[1,1,3,3],'seeds':[[2.5,2]]}),('valid-then-background',{'in':[1,1,3,3],'seeds':[[2,2],[1,1]]})]:
 before=hashlib.sha256(a.tobytes()).hexdigest()
 try:result=card['art_components'](a,spec);r={'outcome':'success','selected_pixels':int(result.sum())}
 except (SystemExit,IndexError,KeyError,TypeError,ValueError) as exc:r={'outcome':type(exc).__name__,'message':str(exc)}
 assert r['outcome']!='success';assert hashlib.sha256(a.tobytes()).hexdigest()==before;refusals.append({'id':name,'source_spec':spec,'original_shape':[5,5,4],'original_rgba_hex':a.tobytes().hex(),**r,'original_unchanged':True,'qualification':'Unmodified sourcehelper observation, not selected futurepublic validation/refusal policy.'})

facts={'status':'Original-only precode component-selection study. No implementation/schema/APIchosen.','ancestry':{'manifest':str(core/'manifest.json'),'sha256':core_hash},'counts':{'actual_component_provider_calls':6,'actual_component_literal_records':4,'actual_fixture_inputs':2,'actual_component_results':12,'separate_actual_g03_calls':1,'separate_actual_g03_results':2,'small_manual_mask_cases':len(mask_cases),'original_refusal_observations':len(refusals)},'source_providers':providers,'fixtures':fixture_records,'expected_actual':expected_actual,'small_source_cases':mask_cases,'source_refusal_observations':refusals,'source_equations':['Art foreground=NOT(R238..250 ANDG187..203 ANDB100..120), alphaignored; label8localcrop; unionforegroundlabelofeachglobal(seed-croporigin) throughNumPyindex; v0refuses; embedthenwholecanvascrossgrowthonlyifGrow>0.','Remnantsforeground=notNear(CREAM,toldefault12)whenbgcream, otherwisealpha>default8; white=minRGB>225 ANDforeground; label8crop; rejectEVERYcomponent meetingwhite; embedonly, nogrowth.','g03originalRGBpredicatepinkORwhiteincrop ->embed ->wholecanvasdefaultcrossdilation withsourceiterations, includinguntilstableforGrow<=0.'],'seed_boundaries':'Emptylist succeeds empty; repeated/multipleseeds union. Out-of-crop positiveindicesraise, boundednegativeindiceswrap; negativeglobalcoordinatescanalsowrapaftercroporiginsubtraction. Source validseedprecondition isnot a canvas/crop bounds guard. Earlier validseeds do not suppress a laterbackground refusal.','shared_contract_assessment':'Meaningful common duty is8connectedcomponent labeling plus component selection by foregroundseed-inclusion or tag-containing-component rejection. Keep default4currentgrow/fill/minimum behavior unchanged; connectivity, aggregation/policy, cropdomain and growthorder are separate facts. Existing parent-described selectRaster scalar evaluator and transformRasterMask topology owner are reuse candidates, no mutableGo read/execution or newfunction/APIchoice.','scalar_assessment':'Currentnineproperties can express panelcube complement, alpha/creamforeground and whiteRGBtag exactly. g03pink requiresabs(G-B)<28, a green-minus-blue relation not directly amongnineproperties; boundedsimpleexistingpropertyclauses do not provide that plane without finitevalueenumeration. Whitebranchalreadyexpressible. Fullcanvasgrowthdomain also remainsseparate; no newscalarfield/schema chosen.','limits_and_holds':'Sourcehelpers have no validated seed/count/crop/workcaps. Keep sourceexceptionandPythonnegativeindexbehavior distinct from futureboundedpublicrefusals. No actual art, sourcepipeline, permissionstage or migrationcredit inferred from12syntheticactualrecord results. Otheroriginalproviders, dynamicacquisition/fontcoverage/radial/flood/morphology remainheld.','protected_scope':'No game/artwork/registry/processes, candidateGo/output, LIVE writes or new410crawl. OnlyAST-isolatedoriginalpurehelpers+NumPy/SciPy on syntheticarrays.'}
(out/'source-facts.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps({'counts':facts['counts'],'actual_pixels':{k:[v['selected_pixels'] for v in r.values()] for k,r in expected_actual.items()},'small_pixels':[(r['id'],r['selected_pixels']) for r in mask_cases],'refusals':[(r['id'],r['outcome'],r['message']) for r in refusals]},indent=2))
