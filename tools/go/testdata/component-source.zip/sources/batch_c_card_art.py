#!/usr/bin/env python3
"""batch_c_card_art.py - hook functions for tools/make_batch_c_png.py (explainer
batch C, card bodies).

g09_cards: the two small cards baked into the Survive rules card
(EVENT.CMB event/guide/mini_g09.txd): セーフ on the mint SAFE card and アウト! on
the BOMB card become SAFE / OUT! (same words as the shipped survive.txd).  Each
edit stays strictly inside the card's inner border line (frame byte-identical:
the hook only writes inside the inner rects below, the driver re-checks the
allow mask); the card face under the old letters is rebuilt from the same card's own
face (vertical blend between the face pixels above and below: the faces are
vertical gradients); letters keep the JP colours and outline style
(cyan + navy outline; red + brown outline, italic)."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_explainer_png as mx  # noqa: E402
from scipy import ndimage as ndi  # noqa: E402

# inner areas (inside the 2-px frame lines measured on the art: SAFE frame x 172-173 /
# 228-229, y 175-176 / 245; BOMB frame x 281-282 / 337-338, y 175-176)
SAFE_IN = (175, 179, 226, 242)     # x0, y0, x1, y1 inclusive
SAFE_TXT_ROWS = (193, 228)
OUT_IN = (283, 178, 336, 205)      # top part only (the BOMB!! art below stays)


def _box(shape, b):
    m = np.zeros(shape, bool)
    x0, y0, x1, y1 = b
    m[y0:y1 + 1, x0:x1 + 1] = True
    return m


def g09_cards(a, orig, op, colors, allow):
    H, W = a.shape[:2]
    c = orig[..., :3].astype(np.int32)
    L = mx.lum(orig)
    sat = c.max(axis=2) - c.min(axis=2)

    # ---- SAFE card
    inner = _box((H, W), SAFE_IN) & allow
    band = np.zeros((H, W), bool)
    band[SAFE_TXT_ROWS[0]:SAFE_TXT_ROWS[1] + 1] = True
    hole = ((sat > 45) | (L < 200)) & inner & band
    hole = ndi.binary_dilation(hole, np.ones((3, 3), bool)) & inner & band
    _cols(a, hole, inner)
    before = a.copy()
    mx.op_text(a, {"op": "text", "text": "SAFE", "at": [200.5, 210.5], "px": 21, "max_w": 44, "min_px": 10,
                   "font": "Black", "color": "cyan", "strokes": [[2.2, "navy"]], "tracking": 0.4,
                   "_orig": orig, "_icons": {}}, colors, [])
    _check(a, before, inner, "SAFE")

    # ---- BOMB card top: アウト! -> OUT!
    inner = _box((H, W), OUT_IN) & allow
    red = (c[..., 0] > 150) & (c[..., 1] < 110)
    hole = (red | (L < 200)) & inner
    hole = ndi.binary_dilation(hole, np.ones((3, 3), bool)) & inner
    # known pixels for the vertical blend: the cream row under the frame line (y 177)
    # and the card face below the old plate (rows 203-212, cloud / cream)
    _cols(a, hole, inner | _box((H, W), (283, 177, 336, 212)))
    before = a.copy()
    mx.op_text(a, {"op": "text", "text": "OUT!", "at": [309.5, 191.5], "px": 24, "max_w": 46, "min_px": 10,
                   "font": "BlackItalic", "skew": 0.06, "color": "red", "strokes": [[2.6, "brown"]],
                   "_orig": orig, "_icons": {}}, colors, [])
    _check(a, before, inner, "OUT!")


def _cols(a, hole, region):
    """vertical (per-column) linear blend across `hole` between the nearest known
    pixels of `region` above and below: the card faces are vertical gradients, so
    this rebuilds the face under the old letters without streaks or a box."""
    ys, xs = np.nonzero(region)
    for x in np.unique(xs):
        col = region[:, x]
        hy = np.nonzero(hole[:, x] & col)[0]
        if len(hy) == 0:
            continue
        ky = np.nonzero(col & ~hole[:, x])[0]
        if len(ky) == 0:
            raise SystemExit("column %d has no known pixels" % x)
        for ch in range(4):
            a[hy, x, ch] = np.rint(np.interp(hy, ky, a[ky, x, ch].astype(float))).astype(np.uint8)


def _check(a, before, inner, what):
    leak = (a != before).any(axis=2) & ~inner
    if leak.any():
        ys, xs = np.nonzero(leak)
        raise SystemExit("g09 %s leaks %d px outside the card's inner area, e.g. %s"
                         % (what, len(xs), list(zip(xs.tolist(), ys.tolist()))[:6]))


def g03_bursts(orig, s):
    """maskfn: the pink/white starbursts of the Escape-from-Pinch card (their tips
    touch the old text lines): pinkish (r high, g ~= b) or near-white pixels inside
    s["in"], grown 1 px.  Text AA/halo is orange (b << g) and is not matched."""
    H, W = orig.shape[:2]
    x, y, w, h = s["in"]
    c = orig[y:y + h, x:x + w, :3].astype(np.int32)
    r, g, b = c[..., 0], c[..., 1], c[..., 2]
    pink = (r > 235) & (np.abs(g - b) < 28) & (g < 240)
    white = (r > 225) & (g > 225) & (b > 215)
    m = np.zeros((H, W), bool)
    m[y:y + h, x:x + w] = pink | white
    return ndi.binary_dilation(m, iterations=s.get("grow", 1))


def art_components(orig, s):
    """maskfn: connected art (non-panel pixels, 8-connected) containing each seed
    in s["seeds"], inside s["in"], grown s["grow"] px.  Used to protect the hands /
    icons next to a text line pixel-exactly (a rect around them would either clip
    the old letters or leave slivers of them)."""
    H, W = orig.shape[:2]
    x, y, w, h = s["in"]
    c = orig[y:y + h, x:x + w, :3].astype(np.int32)
    pan = (np.abs(c[..., 0] - 244) <= 6) & (np.abs(c[..., 1] - 195) <= 8) & (np.abs(c[..., 2] - 110) <= 10)
    lab, _ = ndi.label(~pan, np.ones((3, 3), bool))
    m = np.zeros((H, W), bool)
    for sx, sy in s["seeds"]:
        v = lab[sy - y, sx - x]
        if v == 0:
            raise SystemExit("art_components: seed %r is on the panel" % ((sx, sy),))
        m[y:y + h, x:x + w] |= lab == v
    g = s.get("grow", 0)
    return ndi.binary_dilation(m, iterations=g) if g > 0 else m
