#!/usr/bin/env python3
r"""batch_c_logo_art.py - hook functions (tools/make_batch_c_png.py "hook" ops and
"maskfn" allow shapes) for the English mini-game title logos of explainer batch C:
EVENT.CMB event/mgtitle/mini_t2/t4/t5/t7 and the logo areas of the rules cards
event/guide/mini_g02/g04/g06/g08/g09/g11/g12.

Every hook works on the ORIGINAL pixels: it erases the old Japanese lettering
(footprint = lettering colours + their outline, found per logo), rebuilds what
was under it (flat cream, the smooth glow, the card grid by its own period, the
cloud ellipse, transparency where the original was transparent), then draws the
English with the logo's own style (gradient / texture fill sampled from the old
letters, outline colour and thickness, slant).  Non-lettering art that the old
letters did not cover is excluded from the allow mask (maskfn), so the driver
proves it byte-identical.

Lettering: Noto Sans (SIL OFL 1.1, /usr/share/fonts/google-noto/), rendered by
make_explainer_png.text_layer (4x supersampling).  No game/proprietary font.
"""
import os
import sys

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_explainer_png as mx  # noqa: E402
import make_junky_card_png as J  # noqa: E402
from make_vs_set_icons import exemplar_inpaint  # noqa: E402

CREAM = (254, 230, 154, 255)
FD = "/usr/share/fonts/google-noto/NotoSans-"
BLACKS = [FD + "ExtraCondensedBlack.ttf", FD + "CondensedBlack.ttf", FD + "SemiCondensedBlack.ttf",
          FD + "Black.ttf"]


# ------------------------------------------------------------------ helpers
def rect_mask(shape, r):
    m = np.zeros(shape[:2], bool)
    x, y, w, h = r
    m[max(0, y):y + h, max(0, x):x + w] = True
    return m


def ellipse_mask(shape, cx, cy, rx, ry):
    H, W = shape[:2]
    yy, xx = np.mgrid[0:H, 0:W]
    return ((xx + 0.5 - cx) / rx) ** 2 + ((yy + 0.5 - cy) / ry) ** 2 <= 1.0


def comp(a, layer):
    """alpha-composite a float/uint8 RGBA layer (H,W,4) over a (in place)."""
    mx.composite(a, np.asarray(layer, np.float32))


def text(a, o, colors=None):
    """draw one make_explainer_png text op; returns the coverage (alpha>0) mask."""
    before = a.copy()
    rep = []
    mx.op_text(a, dict(o, _orig=o.get("_orig"), _icons={}), colors or {}, rep)
    return (a != before).any(axis=2)


def finish(a, orig, allow, key):
    bad = (a != orig).any(axis=2) & ~allow
    if bad.any():
        ys, xs = np.nonzero(bad)
        raise SystemExit("%s: hook changed %d px outside allow, e.g. %s" % (
            key, len(xs), list(zip(xs.tolist(), ys.tolist()))[:6]))


def lumi(a):
    return mx.lum(a)


# ------------------------------------------------------------------ janken (g02, g12, t2)
def janken(a, orig, o, colors, allow):
    """repaint the cloud ellipse (ring + white) inside `zone`, background = cream or
    transparent outside it, keep `keep` rects, draw DOKA DOKA + JANKEN! like the
    shipped English mini_g01 (tools/make_junky_card_png.py)."""
    cx, cy, A, B, T = o["ellipse"]
    zone = rect_mask(a.shape, o["zone"])
    keep = np.zeros(a.shape[:2], bool)
    for r in o.get("keep", []):
        keep |= rect_mask(a.shape, r)
    H, W = a.shape[:2]
    yy, xx = np.mgrid[0:H, 0:W]
    d_out = ((xx - cx) / A) ** 2 + ((yy - cy) / B) ** 2
    d_in = ((xx - cx) / (A - T)) ** 2 + ((yy - cy) / (B - T)) ** 2
    new = np.empty_like(a)
    new[:] = CREAM if o.get("bg", "cream") == "cream" else (0, 0, 0, 0)
    new[d_out <= 1.0] = (0, 0, 0, 255)
    new[d_in <= 1.0] = (255, 255, 255, 255)
    m = zone & ~keep
    a[m] = new[m]
    if o.get("bg") == "clear":  # transparent stays exactly the original transparent pixel
        t = m & (orig[..., 3] == 0) & (a[..., 3] == 0)
        a[t] = orig[t]
    img = Image.fromarray(a, "RGBA")
    grad = [(254, 242, 1), (255, 187, 2), (254, 121, 2), (253, 59, 0), (251, 0, 1)]
    jw, jx, jy, jo, js = o["janken"]
    img.alpha_composite(J.logo_text(img.size, "JANKEN!", J.F_LOGO, 0, jw, jx, jy, grad, jo, stretch=js))
    tw, tx, ty, to = o["tag"]
    img.alpha_composite(J.logo_text(img.size, "DOKA DOKA", J.F_LOGO, 0, tw, tx, ty,
                                    [(254, 242, 1), (254, 242, 1)], to))
    a[:] = np.array(img)
    a[~allow] = orig[~allow]


# ------------------------------------------------------------------ generic footprint
def footprint(orig, s):
    """old lettering footprint inside s['in']: pixels matching any of s['letter']
    colour tests, closed/filled and grown by s['grow'] px (outline + AA)."""
    x, y, w, h = s["in"]
    sub = orig[y:y + h, x:x + w].astype(np.int32)
    m = _tests(sub, s["letter"])
    if s.get("close"):
        m = ndi.binary_closing(m, iterations=s["close"])
    if s.get("fill", True) == "core":   # fill holes of the letter fills only (no enclosed art)
        m |= ndi.binary_fill_holes(_tests(sub, s["core"]))
    elif s.get("fill", True):
        m = ndi.binary_fill_holes(m)
    if "core" in s:   # keep only what lies near the letter fills (not other dark art)
        m &= ndi.binary_dilation(_tests(sub, s["core"]), iterations=s.get("core_grow", 4))
    if s.get("min_size"):
        lab, n = ndi.label(m)
        sizes = ndi.sum(m, lab, range(1, n + 1))
        m = np.isin(lab, [i + 1 for i, z in enumerate(sizes) if z >= s["min_size"]])
    m = ndi.binary_dilation(m, iterations=s.get("grow", 1)) if s.get("grow", 1) else m
    out = np.zeros(orig.shape[:2], bool)
    out[y:y + h, x:x + w] = m
    if "clip" in s:
        out &= rect_mask(orig.shape, s["clip"])
    for r in s.get("exclude", []):   # art next to the letters that must stay (e.g. a bubble tail)
        out &= ~rect_mask(orig.shape, r)
    return out


def _tests(sub, tests):
    h, w = sub.shape[:2]
    r, g, b, al = sub[..., 0], sub[..., 1], sub[..., 2], sub[..., 3]
    L = lumi(sub)
    m = np.zeros((h, w), bool)
    for t in tests:
        mm = np.ones((h, w), bool)
        for k, v in t.items():
            if k == "lum_lt":
                mm &= L < v
            elif k == "lum_gt":
                mm &= L > v
            elif k == "rb_gt":      # red minus blue (orange/red/yellow letters)
                mm &= (r - b) > v
            elif k == "br_gt":      # blue minus red (blue letters)
                mm &= (b - r) > v
            elif k == "rg_gt":      # red minus green (red/orange, not yellow/olive)
                mm &= (r - g) > v
            elif k == "r_gt":
                mm &= r > v
            elif k == "r_lt":
                mm &= r < v
            elif k == "b_gt":
                mm &= b > v
            elif k == "b_lt":
                mm &= b < v
            elif k == "g_gt":
                mm &= g > v
            elif k == "g_lt":
                mm &= g < v
            elif k == "alpha_gt":
                mm &= al > v
            elif k == "alpha_lt":
                mm &= al < v
            elif k == "sat_gt":
                mm &= (sub[..., :3].max(axis=2) - sub[..., :3].min(axis=2)) > v
            elif k == "sat_lt":
                mm &= (sub[..., :3].max(axis=2) - sub[..., :3].min(axis=2)) < v
            elif k == "near":
                c = np.array(v[:3])
                mm &= np.abs(sub[..., :3] - c).max(axis=2) <= t.get("tol", 0)
            elif k == "far":        # NOT near colour v (tolerance t["ftol"])
                c = np.array(v[:3])
                mm &= np.abs(sub[..., :3] - c).max(axis=2) > t.get("ftol", 0)
            elif k in ("tol", "ftol"):
                pass
            else:
                raise SystemExit("footprint: unknown key %r" % k)
        m |= mm
    return m


def logo_allow(orig, s):
    """allow part = zone AND (background-like pixels OR old-lettering footprint).
    s = {"zone": R, "fp": footprint spec, "bg": [tests] (pixels new art may cover,
    e.g. transparent or flat cream)}.  Art that is neither (bubble, card, grid)
    stays outside the allow mask unless the old letters covered it."""
    zone = rect_mask(orig.shape, s["zone"])
    fp = footprint(orig, s["fp"]) if "fp" in s else np.zeros(orig.shape[:2], bool)
    bgm = np.zeros(orig.shape[:2], bool)
    if s.get("bg"):
        bgm = footprint(orig, {"in": s["zone"], "letter": s["bg"], "grow": 0, "fill": False})
    return zone & (bgm | fp)


def remnants(orig, s):
    """opaque connected pieces inside s['in'] that contain no white pixel (= bits of
    old letters poking out below the erase zone, not the white thought bubbles)."""
    x, y, w, h = s["in"]
    sub = orig[y:y + h, x:x + w]
    if s.get("bg") == "cream":   # opaque card: 'opaque' = not the flat cream
        op = np.abs(sub[..., :3].astype(np.int32) - np.array(CREAM[:3])).max(axis=2) > s.get("tol", 12)
    else:
        op = sub[..., 3] > s.get("alpha_gt", 8)
    white = (sub[..., :3].min(axis=2) > 225) & op
    lab, n = ndi.label(op, np.ones((3, 3), bool))
    keep = set(np.unique(lab[white])) - {0}
    m = op & ~np.isin(lab, list(keep))
    out = np.zeros(orig.shape[:2], bool)
    out[y:y + h, x:x + w] = m
    return out


def clear_mask(a, orig, o, colors, allow):
    """make the maskfn pixels fully transparent (original background there was
    transparent: these are stray bits of the old letters)."""
    m = (footprint(orig, o) if "letter" in o else remnants(orig, o)) & allow
    a[m] = CREAM if o.get("bg") == "cream" else (255, 255, 255, 0)


# ------------------------------------------------------------------ generic re-lettering
def fit_style(o):
    """o['fit'] = [cx, cy, w, cap]: font px from the cap height, sx so the text is
    exactly w wide (clamped to sx_range)."""
    o = dict(o)
    if "fit" not in o:
        return o
    cx, cy, w, cap = o.pop("fit")
    lo, hi = o.pop("sx_range", [0.55, 1.25])
    best = None
    # o["fonts"]: candidates; the one needing the least horizontal squash/stretch wins
    # (sx is applied AFTER stroking, so a big squash thins the vertical outline)
    for fn in o.pop("fonts", [o.get("font", "Black")]):
        f = mx.get_font(fn, 100)
        capbb = f.getbbox("H", anchor="ls")
        capr = -capbb[1] / mx.SS / 100.0
        px = cap / capr
        runs = mx.parse_runs(o["text"], (0, 0, 0, 255), {})
        wid = mx.measure(runs, dict(o, font=fn, px=px, sx=1.0))
        sx = w / wid
        if best is None or abs(np.log(sx)) < abs(np.log(best[2])):
            best = (fn, px, sx)
    o["font"], o["px"], sx = best
    o["sx"] = float(np.clip(sx, lo, hi)) * o.get("sx", 1.0)
    o["at"] = [cx, cy]
    o.setdefault("valign", "cap")
    return o


def _bg_fill(a, orig, m, mode):
    if mode == "clear":
        t = m & (orig[..., 3] == 0)
        a[m] = (255, 255, 255, 0)
        a[t] = orig[t]
    elif mode == "cream":
        a[m] = CREAM
    elif isinstance(mode, (list, tuple)):
        a[m] = tuple(mode)
    elif mode in ("telea", "ns"):
        import cv2
        flag = cv2.INPAINT_TELEA if mode == "telea" else cv2.INPAINT_NS
        mk = m.astype(np.uint8) * 255
        rgb = cv2.inpaint(np.ascontiguousarray(a[..., :3]), mk, 4, flag)
        al = cv2.inpaint(np.ascontiguousarray(a[..., 3]), mk, 4, flag)
        a[m, :3] = rgb[m]
        a[m, 3] = al[m]
    elif isinstance(mode, dict) and "smooth" in mode:
        # smooth gradient (bubble interior, glow): linear interpolation over the
        # nearby KNOWN background pixels (matching mode["smooth"] tests, not in m)
        from scipy.interpolate import griddata
        ys, xs = np.nonzero(m)
        pad = mode.get("pad", 8)
        y0, y1 = max(0, ys.min() - pad), min(a.shape[0], ys.max() + pad + 1)
        x0, x1 = max(0, xs.min() - pad), min(a.shape[1], xs.max() + pad + 1)
        sub = orig[y0:y1, x0:x1].astype(np.int32)
        known = _tests(sub, mode["smooth"]) & ~m[y0:y1, x0:x1]
        if mode.get("erode"):
            known = ndi.binary_erosion(known, iterations=mode["erode"])
        ky, kx = np.nonzero(known)
        vals = a[y0:y1, x0:x1][known].astype(np.float64)
        q = np.stack([ys - y0, xs - x0], 1)
        out = griddata(np.stack([ky, kx], 1), vals, q, method="linear")
        bad = np.isnan(out).any(axis=1)
        if bad.any():
            out[bad] = griddata(np.stack([ky, kx], 1), vals, q[bad], method="nearest")
        a[ys, xs] = np.clip(np.rint(out), 0, 255).astype(np.uint8)
    else:
        raise SystemExit("unknown bg mode %r" % mode)


def relogo(a, orig, o, colors, allow):
    """erase the old lettering footprint(s), rebuild under it, draw new text.
    o = {"erase": [{"fp": spec, "bg": mode, "rebuild": [{"poly"|"rect", "donor_rect",
         "donor": tests, "P": 4}]}], "texts": [mx text ops (+ "fit")], "key": name}"""
    key = o.get("key", "logo")
    cover = np.zeros(a.shape[:2], bool)
    if o.get("cover_first"):
        # pixels the new lettering will paint opaquely: art under them needs no rebuild
        tmp = np.zeros_like(a)
        for t in o.get("texts", []):
            st = fit_style(t)
            st["_orig"] = orig
            draw_text(tmp, orig, dict(st, _icons={}), colors)
        cover = tmp[..., 3] >= o.get("cover_alpha", 250)
    for e in o.get("erase", []):
        fp = footprint(orig, e["fp"]) & allow
        _bg_fill(a, orig, fp, e.get("bg", "clear"))
        for rb in e.get("rebuild", []):
            H, W = a.shape[:2]
            if "line" in rb:
                contour_rebuild(a, orig, fp, rb, colors)
                continue
            if rb.get("method") == "periodic":
                # regular tile grid: each hole pixel is copied from a same-phase position
                # (offset ~k*period, +-1 px jitter because the tile pitch alternates, e.g.
                # 36/37) chosen by the best 5x5 match with the already-known neighbours;
                # filled from the hole border inwards (onion order)
                px_, py_ = rb["period"]
                gx, gy, gw, gh = rb["grid"]
                cands = set()
                for i in range(-5, 6):
                    for j in range(-2, 3):
                        if i == 0 and j == 0:
                            continue
                        for ex in (-1, 0, 1):
                            for ey in ((-1, 0, 1) if j else (0,)):
                                cands.add((int(round(i * px_)) + (ex if i else 0), int(round(j * py_)) + ey))
                vm = rb.get("vmax", 14)   # straight gap lines: small shifts along them (fallback,
                # penalised so a same-phase tile position wins whenever one is free)
                fall = ({(0, d) for d in range(-vm, vm + 1) if d} | {(d, 0) for d in range(-gw, gw + 1) if d}) - cands
                cands = np.array(sorted(cands) + sorted(fall))
                pen = np.array([0.0] * (len(cands) - len(fall)) + [rb.get("fallback_penalty", 3000.0)] * len(fall))
                hole = fp & ~cover & rect_mask(a.shape, rb.get("rect", rb["grid"]))
                known = ~hole
                img = a.astype(np.float32)
                R = 2
                todo = hole.copy()
                while todo.any():
                    front = todo & ndi.binary_dilation(known, np.ones((3, 3), bool))
                    if not front.any():
                        raise SystemExit("%s: periodic rebuild stuck" % key)
                    for yy, xx in zip(*np.nonzero(front)):
                        sx_ = xx + cands[:, 0]
                        sy_ = yy + cands[:, 1]
                        ok = (sx_ >= gx + R) & (sx_ < gx + gw - R) & (sy_ >= gy + R) & (sy_ < gy + gh - R)
                        cy_, cx_ = np.clip(sy_, 0, H - 1), np.clip(sx_, 0, W - 1)
                        ok &= ~fp[cy_, cx_] & (orig[cy_, cx_, 3] == 255)   # never the grid's AA rim
                        if not ok.any():
                            raise SystemExit("%s: periodic rebuild: no source for (%d,%d)" % (key, xx, yy))
                        c = cands[ok]
                        cp = pen[ok]
                        y0, y1, x0, x1 = yy - R, yy + R + 1, xx - R, xx + R + 1
                        if y0 < 0 or x0 < 0 or y1 > H or x1 > W:
                            continue
                        km = known[y0:y1, x0:x1]
                        tgt = img[y0:y1, x0:x1, :3][km]
                        best, bi = None, 0
                        for n, (dx, dy) in enumerate(c):
                            src = orig[y0 + dy:y1 + dy, x0 + dx:x1 + dx, :3][km].astype(np.float32)
                            d = ((src - tgt) ** 2).sum() + 4.0 * (abs(dx) + abs(dy)) + cp[n]
                            if best is None or d < best:
                                best, bi = d, n
                        dx, dy = c[bi]
                        a[yy, xx] = orig[yy + dy, xx + dx]
                        img[yy, xx] = a[yy, xx]
                        known[yy, xx] = True
                        todo[yy, xx] = False
                    todo &= ~known
                continue
            if rb.get("method") == "shift":
                # translated patch copy: hole pixels in rb["rect"] take the ORIGINAL pixel at
                # +offset (a matching region of the same art, e.g. the cloud lower on a card)
                # wherever that source is not itself under the old letters
                dx, dy = rb["offset"]
                hole = fp & ~cover & rect_mask(a.shape, rb["rect"])
                ys, xs = np.nonzero(hole)
                sy_, sx_ = ys + dy, xs + dx
                ok = (sy_ >= 0) & (sy_ < H) & (sx_ >= 0) & (sx_ < W)
                ok[ok] &= ~fp[sy_[ok], sx_[ok]] & (orig[sy_[ok], sx_[ok], 3] == 255)
                if rb.get("donor"):   # only source pixels of the wanted kind (e.g. cloud, not frame)
                    ok[ok] &= _tests(orig[sy_[ok], sx_[ok]][None].astype(np.int32), rb["donor"])[0]
                if rb.get("feather"):
                    # blend into a patch-copy fill near the hole border so the copied
                    # block has no hard seam against the surrounding art
                    dr = rect_mask(a.shape, rb["donor_rect"])
                    donor = footprint(orig, {"in": rb["donor_rect"], "letter": rb["donor"], "grow": 0,
                                             "fill": False}) & ~fp
                    hole_all = fp & ~cover
                    ex = exemplar_inpaint(a, hole_all, (dr & donor) | hole_all, P=rb.get("P", 4), seed=1,
                                          core=1, donor=donor)
                    from scipy.ndimage import distance_transform_edt
                    dist = distance_transform_edt(hole_all)
                    okm = np.zeros(a.shape[:2], bool)
                    okm[ys[ok], xs[ok]] = True
                    dist = np.minimum(dist, distance_transform_edt(okm))   # also fade out where the
                    #   shifted source runs out (off the card / under the old letters)
                    w = np.clip((dist[ys, xs] - 1) / rb["feather"], 0, 1)[:, None]
                    blend = ex[ys, xs].astype(np.float32)
                    src = orig[np.clip(sy_, 0, H - 1), np.clip(sx_, 0, W - 1)].astype(np.float32)
                    blend[ok] = blend[ok] * (1 - w[ok]) + src[ok] * w[ok]
                    a[ys, xs] = np.rint(blend).astype(np.uint8)
                    a[ys, xs, 3] = 255
                    ok[:] = True
                else:
                    a[ys[ok], xs[ok]] = orig[sy_[ok], sx_[ok]]
                cover = cover.copy()
                cover[ys[ok], xs[ok]] = True   # filled: later rebuild steps skip them
                continue
            if rb.get("method") == "cols":
                # straight vertical art (a card's side frame): column interpolation
                # between the known pixels above and below the hole
                x, y, w, h = rb["rect"]
                hm = (fp & ~cover)[y:y + h, x:x + w]
                sub = a[y:y + h, x:x + w].astype(np.float64)
                for j in range(w):
                    if not hm[:, j].any():
                        continue
                    good = np.nonzero(~fp[y:y + h, x + j])[0]
                    for c in range(4):
                        sub[:, j, c] = np.interp(np.arange(h), good, orig[y + good, x + j, c])
                hh = np.zeros(a.shape[:2], bool)
                hh[y:y + h, x:x + w] = hm
                a[hh] = np.rint(sub[hm]).astype(np.uint8)
                continue
            if "poly" in rb:
                from PIL import ImageDraw
                im = Image.new("L", (W, H), 0)
                ImageDraw.Draw(im).polygon([tuple(p) for p in rb["poly"]], fill=255)
                reg = np.array(im) > 0
            else:
                reg = rect_mask(a.shape, rb["rect"])
            hole = fp & reg & ~cover
            if not hole.any():
                continue
            dr = rect_mask(a.shape, rb["donor_rect"])
            donor = footprint(orig, {"in": rb["donor_rect"], "letter": rb["donor"], "grow": 0, "fill": False})
            donor &= ~fp
            region = (dr & donor) | hole
            out = exemplar_inpaint(a, hole, region, P=rb.get("P", 3), seed=1, core=1, donor=donor)
            a[hole] = out[hole]
            a[hole, 3] = 255
    for t in o.get("texts", []):
        st = fit_style(t)
        st["_orig"] = orig
        before = a.copy()
        draw_text(a, orig, dict(st, _icons={}), colors)
        drawn = (a != before).any(axis=2)
        leak = drawn & ~allow
        if leak.any() and not o.get("allow_clip"):
            ys, xs = np.nonzero(leak)
            raise SystemExit("%s: text %r leaks %d px outside allow, e.g. %s" % (
                key, t["text"], len(xs), list(zip(xs.tolist(), ys.tolist()))[:8]))
        print("    %s: text %r %s px=%.2f sx=%.3f" % (key, t["text"], os.path.basename(st.get("font", "")),
                                                  st["px"], st.get("sx", 1.0)))
    a[~allow] = orig[~allow]


def _dilate_aa(cov, r):
    """isotropic grey dilation of a 0..255 coverage map by radius r px (4x supersampled)."""
    if r <= 0:
        return cov.astype(np.float32)
    S = 4
    big = np.array(Image.fromarray(cov.astype(np.uint8), "L").resize(
        (cov.shape[1] * S, cov.shape[0] * S), Image.BILINEAR))
    big = mx.dilate(big, r * S)
    H, W = cov.shape
    return big.reshape(H, S, W, S).astype(np.float32).mean(axis=(1, 3))


def _shift(m, dx, dy):
    out = np.zeros_like(m)
    H, W = m.shape
    dx, dy = int(round(dx)), int(round(dy))
    out[max(0, dy):H + min(0, dy), max(0, dx):W + min(0, dx)] = m[max(0, -dy):H - max(0, dy), max(0, -dx):W - max(0, dx)]
    return out


def _solid(shape, c, alpha):
    lay = np.zeros(shape[:2] + (4,), np.float32)
    lay[..., :3] = c[:3]
    lay[..., 3] = np.clip(alpha, 0, 255)
    return lay


def draw_text(a, orig, st, colors):
    """mx text_layer for the glyph COVERAGE only; outline / shadow / extrusion are
    dilated at 1x after sx/sy scaling, so they stay isotropic (mx strokes are drawn
    before the sx squash, which thins vertical outlines).  Fill = solid colour,
    vertical gradient {"grad":[...]} over the glyph bbox, or {"from_orig":...}."""
    st = dict(st)
    strokes = st.pop("strokes", [])
    shadow = st.pop("shadow", None)
    extrude = st.pop("extrude", None)
    fill = st.pop("fill", None)
    glow = st.pop("glow", None)
    default = mx.col(st.get("color", [0, 0, 0, 255]), colors)
    runs = mx.parse_runs(st["text"], default, colors)
    st2 = dict(st)
    if fill and "from_orig" in fill:
        st2["fill"] = fill
    layer, w, fa, ic = mx.text_layer(a.shape, runs, st2, colors)
    cov = fa if fa is not None else layer[..., 3]
    cov = np.asarray(cov, np.float32)
    if glow:   # soft outer glow: list of [radius, colour, strength]
        for r, c, k in glow:
            g = _dilate_aa(cov, r)
            from scipy.ndimage import gaussian_filter
            g = gaussian_filter(g, r / 2.0) * k
            comp(a, _solid(a.shape, mx.col(c, colors), g))
    outer = _dilate_aa(cov, strokes[0][0]) if strokes else cov
    if shadow:
        comp(a, _solid(a.shape, mx.col(shadow["color"], colors),
                       _shift(_dilate_aa(cov, shadow.get("radius", strokes[0][0] if strokes else 0)),
                              shadow.get("dx", 0), shadow.get("dy", 0))))
    if extrude:
        n = int(max(abs(extrude["dx"]), abs(extrude["dy"]))) or 1
        acc = np.zeros_like(cov)
        base = outer if extrude.get("of_outline", True) else cov
        for k in range(1, n + 1):
            acc = np.maximum(acc, _shift(base, extrude["dx"] * k / n, extrude["dy"] * k / n))
        if "color2" in extrude:   # outline colour around the extrusion
            comp(a, _solid(a.shape, mx.col(extrude["color2"], colors), _dilate_aa(acc, extrude.get("r2", 1.0))))
        comp(a, _solid(a.shape, mx.col(extrude["color"], colors), acc))
    for r, c in strokes:
        comp(a, _solid(a.shape, mx.col(c, colors), _dilate_aa(cov, r)))
    if fa is not None and "tests" in fill["from_orig"]:
        _texture_fill(a, fa, fill["from_orig"], orig)
    elif fa is not None:
        mx.texture_fill(a, fa, fill["from_orig"], colors, orig)
    elif fill and "grad" in fill:
        ys = np.nonzero(cov.max(axis=1) > 0)[0]
        y0, y1 = (fill.get("rows") or [ys.min(), ys.max()])
        G = np.array([mx.col(c, colors) for c in fill["grad"]], np.float32)
        t = np.clip((np.arange(a.shape[0]) - y0) / max(1, y1 - y0), 0, 1) * (len(G) - 1)
        i0 = np.floor(t).astype(int)
        i1 = np.minimum(i0 + 1, len(G) - 1)
        f = (t - i0)[:, None]
        rows = G[i0] * (1 - f) + G[i1] * f
        lay = np.zeros(a.shape[:2] + (4,), np.float32)
        lay[..., :3] = rows[:, None, :3]
        lay[..., 3] = cov
        comp(a, lay)
    else:
        comp(a, layer)
    return cov


def contour_rebuild(a, orig, hole, rb, colors):
    """redraw hidden art edge under erased letters: pixels of `hole` inside rb['rect']
    = transparent (or rb['outside'] colour), the bubble side (rb['inside'] polygon,
    AA) filled by smooth interpolation of rb['fill'] pixels, then the outline
    polyline rb['line'] (width rb['width']) in rb['color']."""
    from PIL import ImageDraw
    H, W = a.shape[:2]
    S = 4
    R = rect_mask(a.shape, rb["rect"]) & hole
    if not R.any():
        return
    im = Image.new("L", (W * S, H * S), 0)
    ImageDraw.Draw(im).polygon([(x * S, y * S) for x, y in rb["inside"]], fill=255)
    ins = np.array(im, np.float32).reshape(H, S, W, S).mean(axis=(1, 3))
    li = Image.new("L", (W * S, H * S), 0)
    ImageDraw.Draw(li).line([(x * S, y * S) for x, y in rb["line"]], fill=255, width=int(round(rb["width"] * S)),
                            joint="curve")
    lin = np.array(li, np.float32).reshape(H, S, W, S).mean(axis=(1, 3))
    work = a.copy()
    _bg_fill(work, orig, R, rb.get("outside", "clear"))
    interior = a.copy()
    _bg_fill(interior, orig, R, {"smooth": rb["fill"], "pad": rb.get("pad", 10)})
    lay = np.zeros(a.shape[:2] + (4,), np.float32)
    lay[..., :3] = interior[..., :3]
    lay[..., 3] = ins
    comp(work, lay)
    comp(work, _solid(a.shape, mx.col(rb.get("color", [0, 0, 0, 255]), colors), lin))
    a[R] = work[R]


def _texture_fill(a, alpha, spec, orig):
    """like make_explainer_png.texture_fill, source pixels chosen by _tests (spec['tests'])."""
    from scipy.ndimage import distance_transform_edt, binary_erosion
    x, y, w, h = spec["rect"]
    H, W = alpha.shape
    src = np.zeros((H, W), bool)
    src[y:y + h, x:x + w] = _tests(orig[y:y + h, x:x + w].astype(np.int32), spec["tests"])
    if "fp" in spec:   # only pixels inside the old letters (footprint, eroded)
        f = footprint(orig, spec["fp"])
        src &= binary_erosion(f, iterations=spec.get("fp_erode", 2))
    if spec.get("erode"):
        src = binary_erosion(src, iterations=spec["erode"])
    _, (iy, ix) = distance_transform_edt(~src, return_indices=True)
    sxo, syo = spec.get("offset", [0, 0])
    yy, xx = np.mgrid[0:H, 0:W]
    qy = np.clip(yy + syo, 0, H - 1)
    qx = np.clip(xx + sxo, 0, W - 1)
    if spec.get("tile_x"):   # targets right of the source rect sample it again from its left
        over = qx >= x + w
        qx = np.where(over, x + (qx - x) % w, qx)
    lay = np.zeros((H, W, 4), np.float32)
    lay[..., :3] = orig[iy[qy, qx], ix[qy, qx], :3]
    lay[..., 3] = alpha
    comp(a, lay)
