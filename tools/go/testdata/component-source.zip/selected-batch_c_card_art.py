def g03_bursts(orig, s):
    """maskfn: the pink/white starbursts of the Escape-from-Pinch card (their tips
    touch the old text lines): pinkish (r high, g ~= b) or near-white pixels inside
    s["in"], grown 1 px.  Text AA/halo is orange (b << g) and is not matched."""
    H, W = orig.shape[:2]
    x, y, w, h = s['in']
    c = orig[y:y + h, x:x + w, :3].astype(np.int32)
    r, g, b = (c[..., 0], c[..., 1], c[..., 2])
    pink = (r > 235) & (np.abs(g - b) < 28) & (g < 240)
    white = (r > 225) & (g > 225) & (b > 215)
    m = np.zeros((H, W), bool)
    m[y:y + h, x:x + w] = pink | white
    return ndi.binary_dilation(m, iterations=s.get('grow', 1))

def art_components(orig, s):
    """maskfn: connected art (non-panel pixels, 8-connected) containing each seed
    in s["seeds"], inside s["in"], grown s["grow"] px.  Used to protect the hands /
    icons next to a text line pixel-exactly (a rect around them would either clip
    the old letters or leave slivers of them)."""
    H, W = orig.shape[:2]
    x, y, w, h = s['in']
    c = orig[y:y + h, x:x + w, :3].astype(np.int32)
    pan = (np.abs(c[..., 0] - 244) <= 6) & (np.abs(c[..., 1] - 195) <= 8) & (np.abs(c[..., 2] - 110) <= 10)
    lab, _ = ndi.label(~pan, np.ones((3, 3), bool))
    m = np.zeros((H, W), bool)
    for sx, sy in s['seeds']:
        v = lab[sy - y, sx - x]
        if v == 0:
            raise SystemExit('art_components: seed %r is on the panel' % ((sx, sy),))
        m[y:y + h, x:x + w] |= lab == v
    g = s.get('grow', 0)
    return ndi.binary_dilation(m, iterations=g) if g > 0 else m
