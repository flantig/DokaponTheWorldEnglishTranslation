#!/usr/bin/env python3
"""Preview the owner's complete A-horizontal logo; never writes an ISO.

Uses the current ISO's original CLUT and unchanged pixel indices. Outputs are
isolated from batch-E specs/approved art. Running this script is its self-check.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageOps
from scipy import ndimage as ndi

import batch_e_art as art
import cmb_tex_patch as cmb
import ps2_tex as tex

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'generated/texture-previews/explainers/logo-concepts/A-horizontal.png'
OUT = ROOT / 'generated/art/logo-A-integration'
TARGETS = [
    ('title', 'GRAPHIC/ETC.CMB', 'etc/textures/title.txd', (4, 40, 532, 196)),
    ('allmap_1', 'GRAPHIC/SYSTEM.CMB', 'system/allmap_1.txd', (6, 4, 244, 70)),
    ('allmap_2', 'GRAPHIC/SYSTEM.CMB', 'system/allmap_2.txd', (6, 4, 244, 70)),
]
# Title: 0x366658..0x366680 builds UV {0,34,544,161}, passed to
# 0x27d6d0 at0x3666f0. Map: 0x2911bc..0x291248 builds {0,0,512,448},
# passed to0x29f270; both allmap names select this path at0x2909d0.
DRAW_BOUNDS = {'title': (0, 34, 544, 161),
               'allmap_1': (0, 0, 512, 448), 'allmap_2': (0, 0, 512, 448)}


def bbox(mask):
    y, x = np.nonzero(mask)
    return [int(x.min()), int(y.min()), int(x.max() + 1), int(y.max() + 1)]


def pair(before, after, box, scale, path):
    a, b = [Image.fromarray(p).crop(box) for p in (before, after)]
    w, h = a.size
    canvas = Image.new('RGBA', (w, h * 2 + 4), (90, 90, 90, 255))
    canvas.alpha_composite(a, (0, 0))
    canvas.alpha_composite(b, (0, h + 4))
    canvas.resize((w * scale, (h * 2 + 4) * scale), Image.Resampling.NEAREST).save(path)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--iso', type=Path, default=Path(cmb.SHIPPING_PATH))
    args = ap.parse_args()
    cv2.setNumThreads(1)
    OUT.mkdir(exist_ok=True)
    source = Image.open(SOURCE).convert('RGBA')
    alpha = np.array(source)[..., 3]
    # Alpha=1 speckles reach the canvas edge. Crop only their distant margins,
    # retaining ALL alpha>1 pixels and all original pixels within that crop.
    crop = bbox(alpha > 1)
    assert not (alpha[:crop[1]] > 1).any()
    logo = source.crop(crop)
    report = {'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              'alpha_bboxes': {str(n): bbox(alpha > n) for n in (0, 1, 8, 32, 128)},
              'crop': crop, 'targets': {}}
    iso_stat = args.iso.stat()
    # Read-only live-disc evidence for the dimensions used above.
    guards = {0x36665c: 0x24030022, 0x366668: 0x24040220,
              0x366670: 0x240300a1, 0x2911bc: 0x240a0200,
              0x2911c0: 0x240301c0}
    with args.iso.open('rb') as disc:
        elf_at, _ = cmb.iso_find(disc, 'SLPM_657.50')
        for address, expected in guards.items():
            disc.seek(elf_at + address - 0xfff80)
            assert struct.unpack('<I', disc.read(4))[0] == expected, hex(address)
    report['draw_dimension_guards'] = {hex(a): hex(v) for a, v in guards.items()}
    for key, container, entry, box in TARGETS:
        target = cmb.Target(str(args.iso), container, entry, read_only=True)
        oldlin, original = target.rgba()
        h, w = original.shape[:2]
        x0, y0, x1, y1 = box
        region = cmb.rect_mask([(x0, y0, x1 - x0, y1 - y0)], w, h)
        working = original.copy()
        if key == 'title':
            erase = region & (original[..., 3] > 0)
            working[erase] = original[0, 600]
        else:
            # Same ocean-only patch-copy restoration as the existing renderer,
            # but replace the complete old logo (including its dial).
            erase = ndi.binary_dilation(art.B_logo_mask(original, {'box': box}), iterations=2) & region
            rgb = original[..., :3].astype(np.int32)
            donors = art.rect_mask(original.shape, (0, 0, 280, 100))
            donors &= (rgb[..., 2] > rgb[..., 0] + 30) & ~erase
            working[erase] = 0
            art.rebuild(working, erase, donors | erase, P=4, win=40, seed=2)
            assert np.array_equal(working[~erase], original[~erase])
        fitted = ImageOps.contain(logo, (x1 - x0 - 4, y1 - y0 - 4), Image.Resampling.LANCZOS)
        fw, fh = fitted.size
        # Integer rounding may alter the aspect ratio by at most one pixel.
        assert abs(fh - fw * logo.height / logo.width) <= 1
        at = (x0 + (x1 - x0 - fw) // 2, y0 + (y1 - y0 - fh) // 2)
        layer = Image.new('RGBA', (w, h))
        layer.paste(fitted, at)
        coverage = np.array(layer)[..., 3] > 0
        assert not (coverage & ~region).any()
        composed = np.array(Image.alpha_composite(Image.fromarray(working), layer))
        allow = erase | coverage
        assert np.array_equal(composed[~allow], original[~allow])
        newlin = tex.quantize_to_palette(composed, target.pal, oldlin)
        final = tex.to_rgba(newlin, target.pal, w, h)
        oldidx = np.frombuffer(oldlin, np.uint8).reshape(h, w)
        newidx = np.frombuffer(newlin, np.uint8).reshape(h, w)
        assert np.array_equal(newidx[~allow], oldidx[~allow])
        assert np.array_equal(final[~allow], original[~allow])
        # Exercise the exact on-disc index encoding, without writing the disc.
        packed = tex.encode_indices(newlin, w, h, target.tex['depth'])
        assert len(packed) == len(target.pix)
        assert tex.decode_indices(packed, w, h, target.tex['depth']) == newlin
        assert tex.quantize_to_palette(final, target.pal, newlin) == newlin
        changed = np.any(final != original, axis=2)
        draw = cmb.rect_mask([DRAW_BOUNDS[key]], w, h)
        assert not (changed & ~draw).any()
        Image.fromarray(original).save(OUT / f'{key}-original.png')
        Image.fromarray(final).save(OUT / f'{key}.png')
        Image.fromarray((allow * 255).astype(np.uint8)).save(OUT / f'{key}-allow.png')
        pair(original, final, (0, 0, w, h), 1, OUT / f'{key}-native-before-after.png')
        pair(original, final, box, 3 if key == 'title' else 6, OUT / f'{key}-zoom-before-after.png')
        report['targets'][key] = {
            'texture_size': [w, h], 'target_box': box, 'placement': [*at, fw, fh],
            'verified_draw_rect': DRAW_BOUNDS[key],
            'pixel_sha256': tex.sha(target.pix), 'palette_sha256': tex.sha(target.pal_raw),
            'changed_pixels': int(changed.sum()), 'changed_bbox': bbox(changed),
            'changed_outside_allow': int((changed & ~allow).sum()),
            'encoded_roundtrip': True, 'palette_idempotent': True,
        }
        print(key, report['targets'][key], flush=True)
    assert args.iso.stat().st_mtime_ns == iso_stat.st_mtime_ns
    assert args.iso.stat().st_size == iso_stat.st_size
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
