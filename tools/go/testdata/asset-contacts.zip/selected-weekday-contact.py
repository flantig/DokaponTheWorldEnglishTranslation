contact = Image.new('RGB', (336, 160), '#e8e8e8')
draw = ImageDraw.Draw(contact)
for y, label, image in ((0, 'BEFORE', base), (80, 'AFTER - PREVIEW ONLY', candidate)):
    draw.text((3, y), label, fill='black')
    strip = image.crop((0, 208, 336, 272))
    contact.paste(strip, (0, y + 16), strip)
contact.save(OUT / 'before-after-1x.png')
contact.resize((1008, 480), Image.Resampling.NEAREST).save(OUT / 'before-after-3x.png')
