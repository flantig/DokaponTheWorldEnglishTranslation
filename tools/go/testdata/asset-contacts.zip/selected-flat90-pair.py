def pair(before, after, box, scale, path):
    a, b = [Image.fromarray(p).crop(box) for p in (before, after)]
    w, h = a.size
    canvas = Image.new('RGBA', (w, h * 2 + 4), (90, 90, 90, 255))
    canvas.alpha_composite(a, (0, 0))
    canvas.alpha_composite(b, (0, h + 4))
    canvas.resize((w * scale, (h * 2 + 4) * scale), Image.Resampling.NEAREST).save(path)
