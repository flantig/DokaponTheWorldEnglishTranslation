import ast, contextlib, csv, hashlib, inspect, io, json, os, pathlib, re, shutil
import PIL
from PIL import Image, ImageDraw, ImageFont, features

root=pathlib.Path(__file__).parent
project=pathlib.Path('/home/franklinl/Documents/Dokapon World Mod/tools/go')
tools=project.parent
(root/'inputs').mkdir(exist_ok=True)
(root/'sheets').mkdir(exist_ok=True)
(root/'labels').mkdir(exist_ok=True)
source_pins={}
for relative in ['explainer_scan.py','preview_weekdays_2026_10_01.py','preview_logo_a_2026_10_01.py']:
    data=(tools/relative).read_bytes()
    (root/relative).write_bytes(data)
    source_pins['../'+relative]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

# Compile original selected definitions only. No project module or main executes.
tree=ast.parse((tools/'explainer_scan.py').read_text())
selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['tier','_sheet','cmd_sheets','cmd_csv']]
selected += [n for n in tree.body if isinstance(n,ast.Assign) and any((isinstance(t,ast.Name) and t.id in ['MODEL','ICONS','HINT']) or (isinstance(t,ast.Tuple) and any(isinstance(k,ast.Name) and k.id=='CW' for k in t.elts)) for t in n.targets)]
env={'re':re,'os':os,'json':json,'csv':csv,'Image':Image,'ImageDraw':ImageDraw,'ImageFont':ImageFont,'ROOT':str(root),'SHEETS':str(root/'sheets'),'OUTDIR':str(root),'MANIFEST':str(root/'literal-manifest.json'),'DETJSON':str(root/'literal-det.json')}
exec(compile(ast.Module(body=selected,type_ignores=[]),'original-selected-explainer_scan.py','exec'),env)
(root/'selected-explainer.py').write_text(ast.unparse(ast.Module(body=selected,type_ignores=[]))+'\n')

input_facts=[]
for name,w,h in [('tiny',9,3),('thin16',513,16),('thin17',513,17),('large',1024,512)]:
    rgba=bytes(c for i in range(w*h) for c in [(i*71+17)&255,(i*19+93)&255,(i*37+211)&255,[0,1,128,129,254,255][i%6]])
    im=Image.frombytes('RGBA',(w,h),rgba);im.save(root/'inputs'/(name+'.png'))
    input_facts.append({'name':name,'size':[w,h],'rgba_sha256':hashlib.sha256(rgba).hexdigest(),'literal_rule':'pixel i RGB=(71i+17,19i+93,37i+211) mod256; A=[0,1,128,129,254,255][i%6]'})

rows=[]; det={}
for ordinal,(cmb,idx,entry,tex,src,sha,lines) in enumerate([
    ('SYSTEM',9,'system\\skin_A.txd','skin_A','tiny','same-ui',0),
    ('SYSTEM',1,'system\\skin_B.txd','skin_B','tiny','same-ui',0),
    ('TEXTURES',9,'textures\\win_pl\\portraitA.txd','portrait_A','thin16','same-icon',0),
    ('TEXTURES',1,'textures\\win_pl\\portraitB.txd','portrait_B','thin16','same-icon',0),
    ('TEXTURES',3,'textures\\win_mon\\none.txd','no_sha','tiny',None,0),
    ('TEXTURES',4,'textures\\win_mon\\empty.txd','empty_sha','tiny','',0),
    ('BATTLE',7,'battle\\player\\title_long_filename_abcdefghijklmnopqrstuvwxyz.txd','AVATAR_To_fi_ffi','thin17','model-title',0),
    ('EVENT',8,'event\\bg\\mixed.txd','scene','large','event-same',1),
    ('EVENT',0,'event\\bg\\duplicate.txd','scene_dup','large','event-same',1),
    ('FIELD',2,'field\\map\\unflagged.txd','plain','tiny','same-ui',0),
    ('SYSTEM',12,'system\\without_detection.txd','missing_score','tiny','same-ui',None),
]):
    source=root/'inputs'/(src+'.png'); png=f'inputs/row{ordinal:02d}.png';shutil.copyfile(source,root/png)
    im=Image.open(source)
    if sha: sha=hashlib.sha1(im.tobytes()).hexdigest()[:12]
    row={'cmb':cmb,'idx':idx,'entry':entry,'tex':tex,'w':im.width,'h':im.height,'depth':8,'status':'exported-literal','png':png,'sha':sha}
    rows.append(row)
    if lines is not None: det[png]=[ordinal,0,0,0.25,0,lines]
(root/'literal-manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
(root/'literal-det.json').write_text(json.dumps(det,indent=2)+'\n')
out=io.StringIO()
with contextlib.redirect_stdout(out):
    env['cmd_sheets']()
    env['cmd_csv'](str(root/'literal-inventory.csv'))
(root/'original-stdout.txt').write_text(out.getvalue())
sheetmap=json.loads((root/'sheetmap.json').read_text())
csvrows=list(csv.DictReader(io.StringIO((root/'literal-inventory.csv').read_text())))

# Exact original _sheet page slicing, including the second page with one item.
page_items=[]
for i in range(25):
    png=f'inputs/page{i:02d}.png';shutil.copyfile(root/'inputs/tiny.png',root/png)
    x={'cmb':'SYSTEM','idx':24-i,'entry':f'system\\page{i:02d}.txd','tex':f'page{i:02d}','w':9,'h':3,'png':png}
    page_items.append((x,[i,0,0,0,0,0]))
page_map={}
font=ImageFont.truetype('/usr/share/fonts/dejavu-sans-fonts/DejaVuSans.ttf',11)
assert env['_sheet'](page_items,'boundary',font,page_map)==2
(root/'boundary-sheetmap.json').write_text(json.dumps(page_map,indent=2)+'\n')

# Original weekday contact statements only, independent of its game/codec body.
weekday_tree=ast.parse((tools/'preview_weekdays_2026_10_01.py').read_text())
main=next(n for n in weekday_tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
start=next(i for i,n in enumerate(main.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='contact' for t in n.targets))
contact_nodes=main.body[start:start+5]
assert isinstance(contact_nodes[-1],ast.Expr)
(root/'selected-weekday-contact.py').write_text(ast.unparse(ast.Module(body=contact_nodes,type_ignores=[]))+'\n')
weekday_env={'Image':Image,'ImageDraw':ImageDraw,'OUT':root}
for key,w,h in [('base',9,212),('candidate',5,210)]:
    raw=bytes(c for i in range(w*h) for c in [(i*71+17)&255,(i*19+93)&255,(i*37+211)&255,[0,1,128,129,254,255][i%6]])
    weekday_env[key]=Image.frombytes('RGBA',(w,h),raw)
    weekday_env[key].save(root/(key+'.literal.png'))
exec(compile(ast.Module(body=contact_nodes,type_ignores=[]),'original-selected-weekday-contact.py','exec'),weekday_env)

label_facts=[]; glyph_facts=[]; glyph_bytes=bytearray()
texts=['EVENT:race\\rm_AVATAR_To_fi.txd','AVATAR To fi ffi','skin_A 9x3 #9 s0','BEFORE','AFTER - PREVIEW ONLY','ÅİıſK e\u0301 日本語 العربية']
for fname,font in [('dejavu11',font),('aileron10',ImageFont.load_default())]:
    for j,text in enumerate(texts):
        canvas=Image.new('RGB',(512,32),(110,110,110));ImageDraw.Draw(canvas).text((4,2),text,fill=(255,230,120),font=font)
        canvas.save(root/'labels'/f'{fname}-{j}.png')
        raw=canvas.tobytes();(root/'labels'/f'{fname}-{j}.rgb').write_bytes(raw)
        label_facts.append({'font':fname,'text':text,'position':[4,2],'bbox':list(font.getbbox(text)),'length':font.getlength(text),'sum_individual_lengths':sum(font.getlength(c) for c in text),'without_kerning_length':font.getlength(text,features=['-kern']) if font.layout_engine==ImageFont.Layout.RAQM else None,'rgba_or_rgb_sha256':hashlib.sha256(raw).hexdigest()})
    for ch in sorted(set(''.join(texts)+''.join(chr(i) for i in range(32,127)))):
        mask,offset=font.getmask2(ch,mode='L');raw=bytes(mask);at=len(glyph_bytes);glyph_bytes.extend(raw)
        glyph_facts.append({'font':fname,'character':ch,'size':list(mask.size),'offset':list(offset),'advance':font.getlength(ch),'range':[at,len(glyph_bytes)],'sha256':hashlib.sha256(raw).hexdigest()})
(root/'glyph-masks.raw').write_bytes(glyph_bytes)
(root/'glyph-masks.json').write_text(json.dumps(glyph_facts,indent=2,ensure_ascii=False)+'\n')

thumb_facts=[]
for inp in input_facts:
    src=Image.open(root/'inputs'/(inp['name']+'.png')).convert('RGBA')
    th=src.copy();filt=Image.Resampling.LANCZOS if min(src.size)>16 else Image.Resampling.NEAREST
    th.thumbnail((232,136),filt)
    direct=src.resize(th.size,filt)
    assert direct.tobytes()==th.tobytes()
    th.save(root/(inp['name']+'.thumbnail.png'))
    (root/(inp['name']+'.thumbnail.rgba')).write_bytes(th.tobytes())
    thumb_facts.append({'name':inp['name'],'input_size':list(src.size),'size':list(th.size),'filter':filt.name,'equals_direct_without_reduce':True,'rgba_sha256':hashlib.sha256(th.tobytes()).hexdigest()})

# Masked RGB paste and opaque RGBA Over agree over every source gray/alpha pair
# for the four actual fixed presentation backgrounds.
blend=[]
source=Image.frombytes('RGBA',(256,256),bytes(c for a in range(256) for s in range(256) for c in [s,s,s,a]))
for bg in [90,110,150,232]:
    a=Image.new('RGB',source.size,(bg,)*3);a.paste(source,(0,0),source)
    b=Image.new('RGBA',source.size,(bg,bg,bg,255));b.alpha_composite(source)
    assert a.tobytes()==b.convert('RGB').tobytes()
    model=bytes(c for alpha in range(256) for s in range(256) for c in [((bg*(255-alpha)+s*alpha)+127)//255]*3)
    assert model==a.tobytes()
    (root/f'paste-channel-bg{bg}.rgb').write_bytes(a.tobytes())
    blend.append({'background':bg,'channel_alpha_pairs':65536,'rgb_sha256':hashlib.sha256(a.tobytes()).hexdigest(),'paste_equals_opaque_over':True,'nearest_div255_formula':True})

malformed=[]
for name,change in [('missing_png',{'png':'inputs/not-present.png'}),('invalid_png',{'png':'inputs/invalid.png'}),('missing_entry',{'entry':None}),('nonscalar_texture',{'tex':None})]:
    (root/'inputs/invalid.png').write_bytes(b'not png')
    row=dict(rows[0]);row.update(change)
    if name=='missing_entry':del row['entry']
    try:env['_sheet']([(row,[0,0,0,0,0,0])],name,font,{})
    except Exception as error: malformed.append({'name':name,'exception':type(error).__name__,'message':str(error)})
    else:raise AssertionError(name)

pixel_outputs=[]
for p in sorted(list((root/'sheets').glob('*.png'))+list(root.glob('before-after-*.png'))):
    im=Image.open(p);raw=im.tobytes();relative=p.relative_to(root).as_posix();rp=root/(relative+'.'+im.mode.lower());rp.write_bytes(raw)
    pixel_outputs.append({'path':relative,'mode':im.mode,'size':list(im.size),'raw_path':rp.relative_to(root).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})

runtime=[]
import PIL._imaging, PIL._imagingft, PIL.ImageText
for module in [PIL,PIL.Image,PIL.ImageDraw,PIL.ImageFont,PIL.ImageText,PIL._imaging,PIL._imagingft]:
    p=pathlib.Path(module.__file__);data=p.read_bytes();runtime.append({'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    if p.suffix=='.py':(root/('Pillow-'+p.name)).write_bytes(data)
facts={'original_only':True,'source_pins':source_pins,'versions':{x:features.version(x) for x in ['pil','freetype2','raqm','harfbuzz','fribidi']},'runtime_pins':runtime,'literal_inputs':input_facts,'sheetmap':sheetmap,'csv_sheet_projection':[{'idx':x['idx'],'png':x['png'],'sheet':x['sheet']} for x in csvrows],'boundary_sheetmap':page_map,'labels':label_facts,'thumbnails':thumb_facts,'blend':blend,'malformed_original_exceptions':malformed,'complete_pixel_outputs':pixel_outputs,'notes':['Original main/game/project imports were never executed. Original AST-selected sheet/csv/tier and weekday contact statements only.','Full DejaVu11 and embeddedAileron10 fonts are private source fixtures, not production dependencies or per-label font substitutes.','Literal fixtures permit transparent OOB weekday crops/unequal source dimensions; original fixed crop succeeds and zero-pads.']}
(root/'expected-facts.json').write_text(json.dumps(facts,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'pages':len(pixel_outputs),'sheetmap':sheetmap,'thumbnail_facts':thumb_facts,'original_stdout':out.getvalue(),'malformed':malformed},indent=2))
