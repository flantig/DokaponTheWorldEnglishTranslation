#!/usr/bin/env python3
"""explainer_scan.py - exhaustive texture inventory for the explainer-card / baked-JP-text hunt.

  export  walk EVERY entry of every GRAPHIC/*.CMB (EVENT SYSTEM ETC TEXTURES FIELD BATTLE),
          export every PSMT8 / PSMCT32 texture to PNG, and write a manifest that
          accounts for every CMB entry (exported / unsupported / not-a-texture-archive).
  flag    cheap conservative text detector (glyph-tile clusters + long glyph rows) -> det.json
  sheets  contact sheets (24 thumbnails per sheet, labelled archive:entry) -> sheets/
  csv     generated/history/explainer-manifest-YYYY-MM-DD.csv (one row per texture/entry)
  all     export + flag + sheets + csv

Source = extracted/iso-root/GRAPHIC/*.CMB (original disc content).  Texture layouts:
  std       0x50 GS hdr + pixels + 0x50 hdr + CLUT   (ps2_tex.py path)
  nohdr     pixels + CLUT with no GS headers (1024x512 art cards, same swizzle)
  psmct32   linear RGBA (alpha 0..0x80 doubled), unverified for odd sizes
PSMT4 (74 x 128x32 vlg_plt in SYSTEM.CMB, 1 BATTLE vs_sen) is NOT decoded: recorded as
'unsupported depth 4' (swizzle layout not solved).  Textures with a dimension < 16 are
recorded as unsupported (PSMT8 swizzle needs multiples of 16).
"""
import sys, struct, re, os, json, hashlib, functools, time, csv, glob
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
import ps2_tex as T
import numpy as np
from PIL import Image, ImageDraw, ImageFont

T._psmt8_index = functools.lru_cache(maxsize=64)(T._psmt8_index)
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
OUTDIR = os.path.join(BASE, 'generated', 'explainer-textures')
ROOT = OUTDIR + '/all'
MANIFEST = OUTDIR + '/manifest.json'
DETJSON = OUTDIR + '/det.json'
SHEETS = OUTDIR + '/sheets'
SRC = os.path.join(BASE, 'extracted', 'iso-root', 'GRAPHIC')
ALL_CMBS = ['EVENT', 'SYSTEM', 'ETC', 'TEXTURES', 'FIELD', 'BATTLE']

# folder tiers: model = character skins / terrain / props (13.9k), icons = item/monster portraits
MODEL = re.compile(r'^(battle\\(player|monster|bg|weapon|shield|textures\\(player|monster))|field\\(fp|map)|event\\(npc|evtkao|bg|race\\rm))')
ICONS = re.compile(r'^textures\\win_(pl|wep|mon)\\')
HINT = re.compile(r'help|tut|rule|setumei|guide|illust|title|logo|news|kojityu|mini_|card_|casino|prize|sale|button|panel|ready|start|gameset|survive|wanted|jikai|food_t|f_title|op_p|win_', re.I)


def tier(entry):
    e = entry.lower()
    if MODEL.match(e):
        return 'model'
    if ICONS.match(e):
        return 'icons'
    return 'ui'


def native_info(b,p,end):
    """return dict(name,w,h,depth,layout,...) or None. p = start of TEXTURENATIVE payload"""
    ch=[]
    while p+12<=end:
        t,s,v=struct.unpack_from('<III',b,p); ch.append((t,p+12,s)); p+=12+s
    if len(ch)<4 or ch[0][0]!=1 or ch[1][0]!=2 or ch[3][0]!=1: return dict(err='layout')
    if b[ch[0][1]:ch[0][1]+4]!=b'PS2\0': return dict(err='not-ps2')
    name=b[ch[1][1]:ch[1][1]+ch[1][2]].split(b'\0')[0].decode('latin1')
    q,qs=ch[3][1],ch[3][2]
    t0,s0,_=struct.unpack_from('<III',b,q)
    w,h,d,rf=struct.unpack_from('<IIII',b,q+12)
    d0=q+12+s0
    t1,s1,_=struct.unpack_from('<III',b,d0)
    return dict(name=name,w=w,h=h,depth=d,s1=s1,dstart=d0+12)
def decode(b,i):
    w,h,d,s1,ds=i['w'],i['h'],i['depth'],i['s1'],i['dstart']
    if d==8:
        pl=w*h
        if s1==0x50+pl+0x50+0x400: po=ds+0x50; qo=po+pl+0x50; lay='std'
        elif s1==pl+0x400: po=ds; qo=po+pl; lay='nohdr'
        elif s1>0x50+pl+0x50+0x400: po=ds+0x50; qo=po+pl+0x50; lay='std+extra'
        else: return None,'unsupported PSMT8 layout s1=0x%x w*h=0x%x'%(s1,pl)
        if w%16 or h%16: return None,'unsupported size not x16'
        lin=T.unswizzle8(b[po:po+pl],w,h)
        pal=T.clut_decode(b[qo:qo+0x400])
        return T.to_rgba(lin,pal,w,h),lay
    if d==32:
        pl=w*h*4
        if s1>=0x50+pl: po=ds+0x50
        elif s1>=pl: po=ds
        else: return None,'unsupported PSMCT32 layout'
        a=np.frombuffer(b[po:po+pl],np.uint8).reshape(h,w,4).copy()
        a[...,3]=np.minimum(255,a[...,3].astype(int)*2).astype(np.uint8)
        return a,'psmct32-linear-unverified'
    return None,'unsupported depth %d'%d
def walk_txd(b):
    if len(b)<12: return None
    t,s,v=struct.unpack_from('<III',b,0)
    if t!=0x16 or 12+s>len(b): return None
    out=[];p=12;end=12+s
    while p+12<=end:
        t,s,v=struct.unpack_from('<III',b,p)
        if t==0x15: out.append((p+12,p+12+s))
        p+=12+s
    return out
def safe(s): return re.sub(r'[^A-Za-z0-9_.-]','_',s)
def cmd_export(cmbs=None):
    man = []
    for cmb in cmbs or ALL_CMBS:
        f = open(f'{SRC}/{cmb}.CMB', 'rb')
        base, n = struct.unpack('<II', f.read(8))
        raw = f.read(88 * n)
        os.makedirs(f'{ROOT}/{cmb}', exist_ok=True)
        t0 = time.time()
        for i in range(n):
            name=raw[i*88:i*88+80].split(b'\0')[0].decode('latin1')
            off,size=struct.unpack_from('<II',raw,i*88+80)
            f.seek(base+off); b=f.read(size)
            rec=dict(cmb=cmb,idx=i,entry=name,bytes=size)
            ext=name.rsplit('.',1)[-1].lower()
            if b[:8]==b'\x89PNG\r\n\x1a\n':
                fn=f'{cmb}/{i:05d}__{safe(name)}'
                open(f'{ROOT}/{fn}','wb').write(b)
                man.append({**rec,'tex':'','w':0,'h':0,'depth':0,'status':'exported-raw-png','png':fn});continue
            tx=walk_txd(b)
            if tx is None:
                k=b.count(b'PS2\0')
                man.append({**rec,'tex':'','w':0,'h':0,'depth':0,'status':'not-texture-archive:'+ext+(' (PS2sig x%d)'%k if k else ''),'png':''});continue
            if not tx: man.append({**rec,'tex':'','w':0,'h':0,'depth':0,'status':'txd-empty','png':''});continue
            for j,(p,e) in enumerate(tx):
                try:
                    info=native_info(b,p,e)
                    if 'err' in info: man.append({**rec,'tex':'','w':0,'h':0,'depth':0,'status':'unsupported '+info['err'],'png':''});continue
                    img,lay=decode(b,info)
                except Exception as ex:
                    man.append({**rec,'tex':'','w':0,'h':0,'depth':0,'status':'error '+repr(ex)[:60],'png':''});continue
                r={**rec,'tex':info['name'],'w':info['w'],'h':info['h'],'depth':info['depth']}
                if img is None: man.append({**r,'status':lay,'png':''});continue
                fn=f'{cmb}/{i:05d}_{j}__{safe(name.replace(".txd",""))}__{safe(info["name"])[-40:]}.png'
                T.save_png(img,f'{ROOT}/{fn}')
                man.append({**r,'status':'exported-'+lay,'png':fn,'sha':hashlib.sha1(img.tobytes()).hexdigest()[:12]})
        print(cmb, n, 'entries', round(time.time() - t0, 1), 's', flush=True)
    json.dump(man, open(MANIFEST, 'w'))
    print('manifest rows', len(man))


# ----------------------------------------------------------------- detector
def score(path):
    a=np.array(Image.open(ROOT+"/"+path).convert('RGBA'),dtype=np.int32)
    h,w=a.shape[:2]
    lum=(a[...,0]*299+a[...,1]*587+a[...,2]*114)//1000
    op=a[...,3]>128
    H=h//8*8; W=w//8*8
    if H==0 or W==0: return 0,0,0
    lum=lum[:H,:W];op=op[:H,:W]
    # horizontal strong edges between opaque neighbours
    e=(np.abs(np.diff(lum,axis=1))>90)&op[:,1:]&op[:,:-1]
    e=np.pad(e,((0,0),(0,1)))
    # per 8x8 tile
    et=e.reshape(H//8,8,W//8,8).sum(axis=(1,3))
    ot=op.reshape(H//8,8,W//8,8).mean(axis=(1,3))
    dk=((lum<90)&op).reshape(H//8,8,W//8,8).mean(axis=(1,3))
    lt=((lum>150)&op).reshape(H//8,8,W//8,8).mean(axis=(1,3))
    # glyph-like tile: >=6 strong edges, has both dark (5-70%) and light (>=15%) pixels
    g=(et>=6)&(dk>0.05)&(dk<0.7)&(lt>0.15)&(ot>0.5)
    # require clusters: tile with >=2 glyph neighbours in 3x3
    from numpy.lib.stride_tricks import sliding_window_view
    gp=np.pad(g,1).astype(int)
    nb=sliding_window_view(gp,(3,3)).sum(axis=(2,3))
    cl=g&(nb>=3)
    # text lines: tile rows with a run of >=8 consecutive glyph tiles (g)
    lines=0
    for row in g:
        run=best=0
        for v in row:
            run=run+1 if v else 0
            best=max(best,run)
        if best>=8: lines+=1
    px=a[...,:3][op]
    flat=0.0
    if len(px):
        key=(px[:,0]//8)*1024+(px[:,1]//8)*32+(px[:,2]//8)
        flat=float(np.bincount(key).max()/len(px))
    return int(cl.sum()), float(cl.sum()/max(1,(ot>0.5).sum())), int(g.sum()), flat, float(op.mean()), lines


# ----------------------------------------------------------------- detector
def cmd_flag():
    from multiprocessing import Pool
    man = json.load(open(MANIFEST))
    with Pool(8) as pool:
        r = dict(pool.map(_score_safe, [x['png'] for x in man if x['png'] and x['png'].endswith('.png')], chunksize=50))
    json.dump(r, open(DETJSON, 'w'))
    print('scored', len(r))


def _score_safe(p):
    try:
        return p, score(p)
    except Exception:
        return p, (-1, 0, 0, 0, 0, 0)


# ------------------------------------------------------------------- sheets
CW, CH = 240, 170


def _sheet(items, name, font, sheetmap):
    n = 0
    for k in range(0, len(items), 24):
        chunk = items[k:k + 24]
        im = Image.new('RGB', (CW * 6, CH * 4), (110, 110, 110))
        dr = ImageDraw.Draw(im)
        for i, (x, s) in enumerate(chunk):
            cx, cy = (i % 6) * CW, (i // 6) * CH
            src = Image.open(ROOT + '/' + x['png']).convert('RGBA')
            th = src.copy()
            th.thumbnail((CW - 8, CH - 34), Image.LANCZOS if min(src.size) > 16 else Image.NEAREST)
            bg = Image.new('RGBA', th.size, (150, 150, 150, 255))
            bg.alpha_composite(th)
            im.paste(bg.convert('RGB'), (cx + 4, cy + 4))
            lab = f"{x['cmb']}:{x['entry'].split(chr(92), 1)[-1][-26:]}"
            dr.text((cx + 4, cy + CH - 28), lab, fill=(255, 255, 255), font=font)
            dr.text((cx + 4, cy + CH - 14), f"{x['tex'][-14:]} {x['w']}x{x['h']} #{x['idx']} s{s[0]}", fill=(255, 230, 120), font=font)
            sheetmap[x['png']] = f'{name}_{k // 24 + 1:03d}.png'
        im.save(f"{SHEETS}/{name}_{k // 24 + 1:03d}.png")
        n += 1
    return n


def cmd_sheets():
    man = json.load(open(MANIFEST))
    det = json.load(open(DETJSON))
    os.makedirs(SHEETS, exist_ok=True)
    font = ImageFont.truetype('/usr/share/fonts/dejavu-sans-fonts/DejaVuSans.ttf', 11)
    rows = [(x, det[x['png']]) for x in man if x['png'] in det]
    groups = {
        'A_ui': [r for r in rows if tier(r[0]['entry']) == 'ui'],
        'B_icons': [r for r in rows if tier(r[0]['entry']) == 'icons'],
        # model-tier textures with long runs of glyph-like tiles (>=1 text line), plus name hints
        'C_model-flagged': [r for r in rows if tier(r[0]['entry']) == 'model' and (r[1][5] >= 1 or HINT.search(r[0]['entry'] + ' ' + r[0]['tex']))],
        'D_event-bg-race': [r for r in rows if tier(r[0]['entry']) == 'model' and r[0]['cmb'] == 'EVENT' and re.match(r'event\\(bg|race\\rm)', r[0]['entry'].lower())],
    }
    sheetmap = {}
    for g, items in groups.items():
        if g != 'A_ui':           # dedupe identical pixels (colour variants of skins)
            seen, out = set(), []
            for x, s in items:
                k = x.get('sha')
                if k and k in seen:
                    continue
                seen.add(k)
                out.append((x, s))
            items = out
        items.sort(key=lambda r: (r[0]['cmb'], r[0]['idx']))
        print(g, len(items), _sheet(items, g, font, sheetmap), 'sheets')
    json.dump(sheetmap, open(OUTDIR + '/sheetmap.json', 'w'))


# ---------------------------------------------------------------------- csv
def cmd_csv(path):
    man = json.load(open(MANIFEST))
    det = json.load(open(DETJSON))
    sm = json.load(open(OUTDIR + '/sheetmap.json'))
    # identical-pixel duplicates share the sheet of their first occurrence
    bysha = {}
    for x in man:
        if x['png'] in sm and x.get('sha'):
            bysha.setdefault(x['sha'], sm[x['png']])
    for x in man:
        if x['png'] and x['png'] not in sm and x.get('sha') in bysha:
            sm[x['png']] = bysha[x['sha']] + ' (dup pixels)'
    cols = ['archive', 'idx', 'entry', 'texture', 'w', 'h', 'depth', 'status', 'png', 'tier', 'flagged', 'flag_reason',
            'glyph_clusters', 'text_lines', 'sheet']
    with open(path, 'w', newline='') as fh:
        wr = csv.writer(fh)
        wr.writerow(cols)
        for x in man:
            d = det.get(x['png']) if x['png'] else None
            t = tier(x['entry'])
            reasons = []
            if x['png']:
                if t in ('ui', 'icons'):
                    reasons.append('ui-folder')
                if d and d[5] >= 1 and t == 'model':
                    reasons.append('detector-text-lines')
                if d and d[0] >= 40 and d[3] >= 0.3 and t == 'ui':
                    reasons.append('detector-glyphs')
                if HINT.search(x['entry'] + ' ' + x['tex']):
                    reasons.append('name-hint')
            wr.writerow([x['cmb'], x['idx'], x['entry'], x['tex'], x['w'], x['h'], x['depth'], x['status'], x['png'], t,
                         int(bool(reasons)), '+'.join(reasons), d[0] if d else '', d[5] if d else '', sm.get(x['png'], '')])
    print('wrote', path, len(man), 'rows')


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if cmd in ('export', 'all'):
        cmd_export(sys.argv[2:] if cmd == 'export' and len(sys.argv) > 2 else None)
    if cmd in ('flag', 'all'):
        cmd_flag()
    if cmd in ('sheets', 'all'):
        cmd_sheets()
    if cmd in ('csv', 'all'):
        cmd_csv(os.path.join(BASE, 'generated', 'explainer-manifest-2026-10-01.csv'))
