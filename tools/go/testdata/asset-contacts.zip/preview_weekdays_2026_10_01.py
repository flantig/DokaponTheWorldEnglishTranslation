#!/usr/bin/env python3
"""Preview only: seven English HUD weekdays, existing font and live CLUT.

Run directly for generation plus containment/semantic/codec self-checks.
No ISO writing path. Owner approval is required before any later patch.
Caller 35c6b8..35c71c samples (48*weekday,208,48,64), day 0=Monday.
"""
import hashlib
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

import make_weekday_labels_png as font
from cmb_tex_patch import Target
import ps2_tex as tex

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'generated/work/weekday-english-preview'
DAYS = ('MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN')
EXTRA = {
    'M': '##..##|######|######|##..##|##..##|##..##|##..##|##..##|##..##',
    'N': '##..##|###.##|###.##|######|######|##.###|##.###|##..##|##..##',
    'T': '######|######|..##..|..##..|..##..|..##..|..##..|..##..|..##..',
    'U': '##..##|##..##|##..##|##..##|##..##|##..##|##..##|##..##|.####.',
    'W': '##..##|##..##|##..##|##..##|##..##|##..##|######|######|##..##',
    'F': '######|##....|##....|##....|#####.|##....|##....|##....|##....',
    'I': '######|######|..##..|..##..|..##..|..##..|..##..|######|######',
    'R': '#####.|##..##|##..##|##..##|#####.|####..|##.##.|##..##|##..##',
}


def main():
    if not __debug__:
        raise SystemExit('Run without -O: preview checks use assertions.')
    tg = Target(ROOT / 'iso/modded/modded-sentinel-bypass-fix.iso',
                'GRAPHIC/SYSTEM.CMB', 'win_p.txd', read_only=True)
    assert tex.sha(tg.pix) == '4428c0758b66447e07eb6e064436bc5948df2cc1c0e5e9d3292a4093cdbaf9e6'
    original, rgba = tg.rgba()
    base = Image.fromarray(rgba, 'RGBA')
    candidate = base.copy()
    # Extend the imported dictionary in this preview process only.
    assert not set(EXTRA) & set(font.G)
    font.G.update(EXTRA)
    assert all(len(r.split('|')) == 9 and all(len(x) == 6 for x in r.split('|'))
               for r in font.G.values())
    assert len({font.G[c] for c in set(''.join(DAYS))}) == len(set(''.join(DAYS)))
    opaque = [p for p in tg.pal if p[3] == 255]
    nearest = lambda rgb: min(opaque, key=lambda p: sum((a-b)**2 for a,b in zip(p[:3], rgb)))
    font.BLACK = nearest((0, 0, 0))
    font.CLEAR = next(p for p in tg.pal if p[3] == 0)
    colors = [(nearest((255, 255, 255)), nearest((187, 187, 187)))] * 7
    for day, fill, shade in ((2, (255, 234, 88), (214, 190, 78)),
                             (5, (82, 190, 255), (49, 119, 214)),
                             (6, (239, 83, 82), (201, 67, 66))):
        colors[day] = nearest(fill), nearest(shade)
    for day, word in enumerate(DAYS):
        fill, shade = colors[day]
        cell = font.render(word, 24, 32, fill, shade)
        # Read every glyph's 6x12 interior back against the code-defined letter.
        for letter, ch in enumerate(word):
            for y, row in enumerate(font.glyph(ch)):
                for x, bit in enumerate(row):
                    pixel = cell.getpixel((2 + letter * 7 + x, 10 + y))
                    assert (pixel in (fill, shade)) == (bit == '#'), (word, ch, x, y)
        cell = cell.resize((48, 64), Image.Resampling.NEAREST)
        assert cell.getbbox() == (2, 18, 46, 46), (word, cell.getbbox())
        candidate.paste(cell, (48 * day, 208))
    intended = np.array(candidate)
    assert set(map(tuple, intended.reshape(-1, 4))).issubset(set(tg.pal))
    indices = tex.quantize_to_palette(intended, tg.pal, original)
    mask = np.zeros((512, 512), dtype=bool)
    mask[208:272, :336] = True
    assert np.array_equal(np.frombuffer(indices, np.uint8).reshape(512, 512)[~mask],
                          np.frombuffer(original, np.uint8).reshape(512, 512)[~mask])
    encoded = tex.encode_indices(indices, 512, 512)
    decoded = tex.decode_indices(encoded, 512, 512)
    assert decoded == indices
    assert tex.encode_indices(tex.decode_indices(tg.pix, 512, 512), 512, 512) == tg.pix
    assert np.array_equal(tex.to_rgba(decoded, tg.pal, 512, 512), intended)
    OUT.mkdir(parents=True, exist_ok=True)
    png = OUT / 'win_p-weekdays-english.png'
    candidate.save(png)
    assert np.array_equal(tex.load_png(png), intended)
    contact = Image.new('RGB', (336, 160), '#e8e8e8')
    draw = ImageDraw.Draw(contact)
    for y, label, image in ((0, 'BEFORE', base), (80, 'AFTER - PREVIEW ONLY', candidate)):
        draw.text((3, y), label, fill='black')
        strip = image.crop((0, 208, 336, 272))
        contact.paste(strip, (0, y + 16), strip)
    contact.save(OUT / 'before-after-1x.png')
    contact.resize((1008, 480), Image.Resampling.NEAREST).save(OUT / 'before-after-3x.png')
    print('PASS: 7 semantic letter masks; exact palette; unchanged outside cells;')
    print('source and candidate index roundtrips; RGBA codec and PNG readback.')
    print('Colors:', colors)
    print('PNG SHA256:', hashlib.sha256(png.read_bytes()).hexdigest())
    print('CLUT SHA256:', tex.sha(tg.pal_raw))
    print('Output:', OUT)


if __name__ == '__main__':
    main()
