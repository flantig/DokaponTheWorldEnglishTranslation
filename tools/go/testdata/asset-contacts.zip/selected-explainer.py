def tier(entry):
    e = entry.lower()
    if MODEL.match(e):
        return 'model'
    if ICONS.match(e):
        return 'icons'
    return 'ui'

def _sheet(items, name, font, sheetmap):
    n = 0
    for k in range(0, len(items), 24):
        chunk = items[k:k + 24]
        im = Image.new('RGB', (CW * 6, CH * 4), (110, 110, 110))
        dr = ImageDraw.Draw(im)
        for i, (x, s) in enumerate(chunk):
            cx, cy = (i % 6 * CW, i // 6 * CH)
            src = Image.open(ROOT + '/' + x['png']).convert('RGBA')
            th = src.copy()
            th.thumbnail((CW - 8, CH - 34), Image.LANCZOS if min(src.size) > 16 else Image.NEAREST)
            bg = Image.new('RGBA', th.size, (150, 150, 150, 255))
            bg.alpha_composite(th)
            im.paste(bg.convert('RGB'), (cx + 4, cy + 4))
            lab = f"{x['cmb']}:{x['entry'].split(chr(92), 1)[-1][-26:]}"
            dr.text((cx + 4, cy + CH - 28), lab, fill=(255, 255, 255), font=font)
            dr.text((cx + 4, cy + CH - 14), f"{x['tex'][-14:]} {x['w']}x{x['h']} #{x['idx']} s{s[0]}", fill=(255, 230, 120), font=font)
            sheetmap[x['png']] = f'{name}_{k // 24 + 1:03d}.png'
        im.save(f'{SHEETS}/{name}_{k // 24 + 1:03d}.png')
        n += 1
    return n

def cmd_sheets():
    man = json.load(open(MANIFEST))
    det = json.load(open(DETJSON))
    os.makedirs(SHEETS, exist_ok=True)
    font = ImageFont.truetype('/usr/share/fonts/dejavu-sans-fonts/DejaVuSans.ttf', 11)
    rows = [(x, det[x['png']]) for x in man if x['png'] in det]
    groups = {'A_ui': [r for r in rows if tier(r[0]['entry']) == 'ui'], 'B_icons': [r for r in rows if tier(r[0]['entry']) == 'icons'], 'C_model-flagged': [r for r in rows if tier(r[0]['entry']) == 'model' and (r[1][5] >= 1 or HINT.search(r[0]['entry'] + ' ' + r[0]['tex']))], 'D_event-bg-race': [r for r in rows if tier(r[0]['entry']) == 'model' and r[0]['cmb'] == 'EVENT' and re.match('event\\\\(bg|race\\\\rm)', r[0]['entry'].lower())]}
    sheetmap = {}
    for g, items in groups.items():
        if g != 'A_ui':
            seen, out = (set(), [])
            for x, s in items:
                k = x.get('sha')
                if k and k in seen:
                    continue
                seen.add(k)
                out.append((x, s))
            items = out
        items.sort(key=lambda r: (r[0]['cmb'], r[0]['idx']))
        print(g, len(items), _sheet(items, g, font, sheetmap), 'sheets')
    json.dump(sheetmap, open(OUTDIR + '/sheetmap.json', 'w'))

def cmd_csv(path):
    man = json.load(open(MANIFEST))
    det = json.load(open(DETJSON))
    sm = json.load(open(OUTDIR + '/sheetmap.json'))
    bysha = {}
    for x in man:
        if x['png'] in sm and x.get('sha'):
            bysha.setdefault(x['sha'], sm[x['png']])
    for x in man:
        if x['png'] and x['png'] not in sm and (x.get('sha') in bysha):
            sm[x['png']] = bysha[x['sha']] + ' (dup pixels)'
    cols = ['archive', 'idx', 'entry', 'texture', 'w', 'h', 'depth', 'status', 'png', 'tier', 'flagged', 'flag_reason', 'glyph_clusters', 'text_lines', 'sheet']
    with open(path, 'w', newline='') as fh:
        wr = csv.writer(fh)
        wr.writerow(cols)
        for x in man:
            d = det.get(x['png']) if x['png'] else None
            t = tier(x['entry'])
            reasons = []
            if x['png']:
                if t in ('ui', 'icons'):
                    reasons.append('ui-folder')
                if d and d[5] >= 1 and (t == 'model'):
                    reasons.append('detector-text-lines')
                if d and d[0] >= 40 and (d[3] >= 0.3) and (t == 'ui'):
                    reasons.append('detector-glyphs')
                if HINT.search(x['entry'] + ' ' + x['tex']):
                    reasons.append('name-hint')
            wr.writerow([x['cmb'], x['idx'], x['entry'], x['tex'], x['w'], x['h'], x['depth'], x['status'], x['png'], t, int(bool(reasons)), '+'.join(reasons), d[0] if d else '', d[5] if d else '', sm.get(x['png'], '')])
    print('wrote', path, len(man), 'rows')
MODEL = re.compile('^(battle\\\\(player|monster|bg|weapon|shield|textures\\\\(player|monster))|field\\\\(fp|map)|event\\\\(npc|evtkao|bg|race\\\\rm))')
ICONS = re.compile('^textures\\\\win_(pl|wep|mon)\\\\')
HINT = re.compile('help|tut|rule|setumei|guide|illust|title|logo|news|kojityu|mini_|card_|casino|prize|sale|button|panel|ready|start|gameset|survive|wanted|jikai|food_t|f_title|op_p|win_', re.I)
CW, CH = (240, 170)
