from pathlib import Path
import ast,copy,datetime,hashlib,json,types,zipfile
import numpy as np
from scipy import ndimage as ndi
from PIL import Image,ImageDraw

out=Path(__file__).parent;components=Path('/var/tmp/dokapon-component-permission-source-AHrdkqz2');core=Path('/var/tmp/dokapon-original-permission-source-jdo2V5Rg');raster=Path('/var/tmp/dokapon-raster06-source-vNHIU7Ur')
ancestry=[]
for p,want in [(components,'20d69dc6930d9801a4c128db504322833772f02c96300763ddc6dafe2385d207'),(core,'4c6e945eeb8643ece9597941c0dd20f28bf1947b308cc2b3ad862fbb2ef16222'),(raster,'976326c4deb9193e2e0c5ecdd513fff468bf66571773447257dfe198e535bc14')]:
 assert hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()==want;ancestry.append({'manifest':str(p/'manifest.json'),'sha256':want})
for rel,row in json.loads((components/'manifest.json').read_text()).items():
 data=(components/rel).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
componentfacts=json.loads((components/'source-facts.json').read_text());doc=json.loads((core/'sources/specs/batch_c.json').read_text());frags=doc['fragments'];sourcepins=[]
for p,rel in [(core,'sources/batch_c_card_art.py'),(core,'sources/batch_c_logo_art.py'),(core,'sources/make_batch_c_png.py'),(core,'sources/make_explainer_png.py'),(core,'sources/specs/batch_c.json'),(core,'selected-batch_c_card_art.py'),(core,'selected-batch_c_logo_art.py'),(core,'selected-make_explainer_png.py'),(core,'selected-make_batch_c_png.py'),(core,'library-provenance.json'),(raster,'Pillow-provenance.json')]:
 data=(p/rel).read_bytes();dest=out/rel;dest.parent.mkdir(exist_ok=True,parents=True);dest.write_bytes(data);sourcepins.append({'source':str(p/rel),'copied_as':rel,'sha256':hashlib.sha256(data).hexdigest()})
pv=json.loads((raster/'Pillow-provenance.json').read_text())
for key in ['installed_python_wrapper','installed_core']:
 pin=pv[key];assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
mx={'np':np};exec(compile(ast.parse((core/'selected-make_explainer_png.py').read_text()),'sealed-original-mx','exec'),mx)
mxns=types.SimpleNamespace(**{k:mx[k] for k in ['lum','col','make_mask','grow']})
logo={'np':np,'ndi':ndi,'CREAM':(254,230,154,255),'mx':mxns};exec(compile(ast.parse((core/'selected-batch_c_logo_art.py').read_text()),'sealed-original-logo','exec'),logo)
card={'np':np,'ndi':ndi};exec(compile(ast.parse((core/'selected-batch_c_card_art.py').read_text()),'sealed-original-card','exec'),card)
provider_table={'batch_c_logo_art':types.SimpleNamespace(**{k:logo[k] for k in ['remnants','footprint','logo_allow']}),'batch_c_card_art':types.SimpleNamespace(art_components=card['art_components'])}
batch={'np':np,'ndi':ndi,'Image':Image,'ImageDraw':ImageDraw,'SS':4,'mx':mxns,'importlib':types.SimpleNamespace(import_module=provider_table.__getitem__)}
exec(compile(ast.parse((core/'selected-make_batch_c_png.py').read_text()),'sealed-original-build_allow','exec'),batch)

definitions=[];source_tex={}
for key in ['mini_g02','mini_g08','mini_g12','mini_t2']:
 ti=next(i for i,t in enumerate(doc['textures']) if t['key']==key);tex=doc['textures'][ti];source_tex[key]=tex
 shapes=[{'source_path':'$/textures/'+str(ti)+'/allow/'+str(i),'shape':s} for i,s in enumerate(tex.get('allow',[]))]
 for op in tex['ops']:
  if op.get('op')=='include':shapes.extend({'source_path':'$/fragments/'+op['frag']+'/allow/'+str(i),'shape':s} for i,s in enumerate(frags[op['frag']].get('allow',[])))
 additions=[{'source_path':'$/textures/'+str(ti)+'/allow_add/'+str(i),'shape':s} for i,s in enumerate(tex.get('allow_add',[]))]
 for rec in shapes+additions:
  s=rec['shape'];assert any(k in s for k in ['rect','rrect','flood','maskfn'])
  if 'maskfn' in s:
   module,fn=s['maskfn'].split(':');assert module in provider_table and hasattr(provider_table[module],fn)
 native=batch['all_rects'](tex,frags)
 for x,y,w,h in native:assert x>=0 and y>=0 and x+w<=512 and y+h<=512
 definitions.append({'asset_key':key,'original_texture_record':tex,'expanded_allow_records':shapes,'allow_add_records':additions,'native_rectangles_original_all_rects':native,'all_actual_permission_shapes_retained':True,'omitted_or_unsupported_permission_providers':[],'source_global_permission_semantics_complete_on_supplied_synthetic_inputs':True,'hook_render_text_donor_execution':False})

(out/'blobs').mkdir(exist_ok=True);inputs=[];results={};rrect_rechecks=[]
for fixture in componentfacts['fixtures']:
 data=(components/fixture['raw']).read_bytes();assert hashlib.sha256(data).hexdigest()==fixture['sha256'];(out/fixture['raw']).write_bytes(data);inputs.append(fixture);a=np.frombuffer(data,np.uint8).reshape(512,512,4);before=hashlib.sha256(a.tobytes()).hexdigest();results[fixture['id']]={}
 for definition in definitions:
  key=definition['asset_key'];positive=np.zeros((512,512),bool);negative=np.zeros_like(positive);add=np.zeros_like(positive);native=np.zeros_like(positive);trace=[]
  for stage,records in [('allow',definition['expanded_allow_records']),('allow_add',definition['allow_add_records'])]:
   for rec in records:
    mask=batch['shape_mask']((512,512),rec['shape'],a);raw=(mask.astype(np.uint8)*255).tobytes();sha=hashlib.sha256(raw).hexdigest();rel='blobs/'+sha+'.mask';(out/rel).write_bytes(raw)
    target='allow_add_union' if stage=='allow_add' else ('negative_union' if rec['shape'].get('minus') else 'positive_union')
    if target=='allow_add_union':add|=mask
    elif target=='negative_union':negative|=mask
    else:positive|=mask
    trace.append({'source_path':rec['source_path'],'source_shape':rec['shape'],'operand':target,'mask':rel,'sha256':sha,'selected_pixels':int(mask.sum())})
    if 'rrect' in rec['shape']:
     assert sha=='e20ea6eb649851a641193bdd99d206b71b9899e957222aab9cc86ebdd76d733b';rrect_rechecks.append({'fixture':fixture['id'],'asset_key':key,'sha256':sha})
  for x,y,w,h in definition['native_rectangles_original_all_rects']:native[y:y+h,x:x+w]=True
  after_subtract=positive&~negative;after_add=after_subtract|add;final=after_add&native
  original_allow=batch['build_allow'](source_tex[key],(512,512),a,frags);assert np.array_equal(original_allow,after_add)
  expected={}
  for field,mask in [('positive_union',positive),('negative_union',negative),('after_subtract',after_subtract),('allow_add_union',add),('after_add',after_add),('native_union',native),('final_allow',final)]:
   raw=(mask.astype(np.uint8)*255).tobytes();sha=hashlib.sha256(raw).hexdigest();rel='blobs/'+sha+'.mask';(out/rel).write_bytes(raw);expected[field]={'mask':rel,'sha256':sha,'selected_pixels':int(mask.sum())}
  results[fixture['id']][key]={'shape_trace':trace,'expected_stage_masks':expected,'source_build_allow_equals_explicit_union_minus_add':True,'add_last_resurrected_pixels':int((add&~after_subtract).sum()),'native_intersection_removed_pixels':int((after_add&~native).sum()),'all_original_RGBA_unchanged':True}
  assert hashlib.sha256(a.tobytes()).hexdigest()==before

bykey={r['asset_key']:r for r in definitions};left=bykey['mini_g02'];right=bykey['mini_g12'];comparison={}
for key in ['expanded_allow_records','allow_add_records','native_rectangles_original_all_rects']:
 l=[r['shape'] for r in left[key]] if key!='native_rectangles_original_all_rects' else left[key]
 r=[r['shape'] for r in right[key]] if key!='native_rectangles_original_all_rects' else right[key]
 lb=json.dumps(l,sort_keys=True,separators=(',',':')).encode();rb=json.dumps(r,sort_keys=True,separators=(',',':')).encode();comparison[key]={'equal_values_and_order':l==r,'g02_canonical_sha256':hashlib.sha256(lb).hexdigest(),'g12_canonical_sha256':hashlib.sha256(rb).hexdigest()}
comparison['same_output_by_fixture']={name:{field:r['mini_g02']['expected_stage_masks'][field]['sha256']==r['mini_g12']['expected_stage_masks'][field]['sha256'] for field in r['mini_g02']['expected_stage_masks']} for name,r in results.items()}
comparison['asset_keys_stay_distinct']=['mini_g02','mini_g12'];comparison['sharing_candidate']='Identical purpose-grouped permission operands may be shared onlywhere values/order match; preserve separate stableassetjoinkeys and any differingnative/text/artfacts. This is source/data evidence, no runtime schema/approval.'
facts={'status':'Independent original-only full globalpermission stages BEFOREfuturecomponentGo changes. No candidate source/output read, inputprojection/schema or implementation.','ancestry':ancestry,'source_pins':sourcepins,'fixtures':inputs,'definitions':definitions,'expected_by_fixture':results,'g02_g12_data_comparison':comparison,'frozen_Pillow_rrect_sha_rechecks':rrect_rechecks,'counts':{'contexts':4,'fixtures':2,'full_source_global_permission_replays':8,'stage_fields':56,'mask_trace_records':sum(len(r['shape_trace']) for v in results.values() for r in v.values()),'unsupported_permission_provider_omissions':0},'completeness_boundary':'Allactualoriginalpermission shapes, includingflood additions, are retained for these4contexts and sourcebuild_allow matches explicitstageequations on bothfrozen512RGBAfixtures. Nativeintersection exactlyreusesoriginalall_rects. No sourcehook/render/text/donor/quantization/artwork execution or fulltexture/patchauthority claim.','operation_order':'Positiveunion ANDNOTnegativeunion ->allow_add last ->source nativefootprintintersection. Eachshape callback gets immutable ORIGINALRGBA. Rect/rrect/foregroundcomponent/remnants/footprint/flood masks remain distinct traced source operands.','safe_original_execution':'Only priorAST-selected purehelpers executed with fixedmodule-to-providerobjecttable; original importlib.import_module redirectedtodictionarylookup. No operationaldynamicimports, originalmains or constructors/state readers.','all_owned_jobs_terminal':True}
(out/'source-stage-facts.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps({'counts':facts['counts'],'g02_g12':comparison,'final_pixels':{name:{key:r['expected_stage_masks']['final_allow']['selected_pixels'] for key,r in rs.items()} for name,rs in results.items()},'resurrection_pixels':{name:{key:r['add_last_resurrected_pixels'] for key,r in rs.items()} for name,rs in results.items()}},indent=2))
