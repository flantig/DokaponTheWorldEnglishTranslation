x, y, w, h = s['in']
sub = orig[y:y + h, x:x + w]
light = mx.lum(sub) > s.get('lum_gt', 120)
dark_lab, _ = ndi.label(~light)
border = set(np.unique(np.concatenate([dark_lab[0], dark_lab[-1], dark_lab[:, 0], dark_lab[:, -1]])))
letters = ~light & ~np.isin(dark_lab, list(border - {0}))
ok = light | letters
