from pathlib import Path
import ast,datetime,hashlib,json,types,zipfile
import numpy as np
from scipy import ndimage as ndi
from PIL import Image,ImageDraw

out=Path(__file__).parent;core=Path('/var/tmp/dokapon-original-permission-source-jdo2V5Rg');components=Path('/var/tmp/dokapon-component-permission-source-AHrdkqz2');globalpack=Path('/var/tmp/dokapon-component-global-stages-aKJmlrhz');raster=Path('/var/tmp/dokapon-raster06-source-vNHIU7Ur')
ancestry=[]
for p,want in [(core,'4c6e945eeb8643ece9597941c0dd20f28bf1947b308cc2b3ad862fbb2ef16222'),(components,'20d69dc6930d9801a4c128db504322833772f02c96300763ddc6dafe2385d207'),(globalpack,'bae488bad73d006b0a7ab6c7d0010f95acc0cee5646c93321db8be7a0634a6ee'),(raster,'976326c4deb9193e2e0c5ecdd513fff468bf66571773447257dfe198e535bc14')]:
 assert hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()==want;ancestry.append({'manifest':str(p/'manifest.json'),'sha256':want})
census=json.loads((core/'resolved-provider-census.json').read_text());records=census['flood_records'];assert len(records)==6 and len({json.dumps(r['shape'],sort_keys=True) for r in records})==3
sourcepins=[]
for p,rel in [(core,'sources/make_batch_c_png.py'),(core,'sources/make_explainer_png.py'),(core,'sources/specs/batch_c.json'),(core,'selected-make_batch_c_png.py'),(core,'selected-make_explainer_png.py'),(core,'library-provenance.json'),(raster,'Pillow-provenance.json')]:
 data=(p/rel).read_bytes();dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);sourcepins.append({'source':str(p/rel),'copied_as':rel,'sha256':hashlib.sha256(data).hexdigest()})
for key in ['installed_python_wrapper','installed_core']:
 pin=json.loads((raster/'Pillow-provenance.json').read_text())[key];assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
mx={'np':np};exec(compile(ast.parse((core/'selected-make_explainer_png.py').read_text()),'sealed-original-mx','exec'),mx)
env={'np':np,'ndi':ndi,'Image':Image,'ImageDraw':ImageDraw,'SS':4,'mx':types.SimpleNamespace(**{k:mx[k] for k in ['lum','col','make_mask','grow']})}
exec(compile(ast.parse((core/'selected-make_batch_c_png.py').read_text()),'sealed-original-shape-mask','exec'),env)
# This source branch returns before any drawing method or dynamicmaskfn import.
fn=next(n for n in ast.parse((core/'sources/make_batch_c_png.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='shape_mask')
flood_branch=next(n for n in ast.walk(fn) if isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Constant) and n.test.left.value=='flood')
assert isinstance(flood_branch.body[6],ast.Assign) and flood_branch.body[6].targets[0].id=='ok'
assert isinstance(flood_branch.body[9],ast.Assign) and flood_branch.body[9].targets[0].id=='reg'
prefix=ast.Module(body=flood_branch.body[:10],type_ignores=[]);holeprefix=ast.Module(body=flood_branch.body[:7],type_ignores=[])
(out/'exact-original-flood-prefix.py').write_text(ast.unparse(prefix)+'\n');(out/'exact-original-letters-prefix.py').write_text(ast.unparse(holeprefix)+'\n')
prefix_code=compile(prefix,'exact-original-flood-prefix','exec');hole_code=compile(holeprefix,'exact-original-letters-prefix','exec')
(out/'blobs').mkdir(exist_ok=True);(out/'inputs').mkdir(exist_ok=True)
inputs=[];actual={};oldglobal=json.loads((globalpack/'source-stage-facts.json').read_text())
componentfacts=json.loads((components/'source-facts.json').read_text())
for fixture in componentfacts['fixtures']:
 raw=(components/fixture['raw']).read_bytes();assert hashlib.sha256(raw).hexdigest()==fixture['sha256'];(out/fixture['raw']).write_bytes(raw);inputs.append(fixture);a=np.frombuffer(raw,np.uint8).reshape(512,512,4);actual[fixture['id']]={}
 for i,r in enumerate(records):
  before=hashlib.sha256(a.tobytes()).hexdigest();mask=env['shape_mask']((512,512),r['shape'],a);data=(mask.astype(np.uint8)*255).tobytes();sha=hashlib.sha256(data).hexdigest();rel='blobs/'+sha+'.mask';(out/rel).write_bytes(data)
  traceenv={'np':np,'ndi':ndi,'mx':env['mx'],'orig':a,'s':r['shape']};exec(prefix_code,traceenv);sx,sy=r['shape']['flood'];x,y,w,h=r['shape']['in'];label=int(traceenv['lab'][sy-y,sx-x])
  old=next(t for t in oldglobal['expected_by_fixture'][fixture['id']][r['texture']]['shape_trace'] if t['source_shape']==r['shape']);assert old['sha256']==sha
  assert hashlib.sha256(a.tobytes()).hexdigest()==before
  actual[fixture['id']]['actual/%02d'%i]={'source_record':r,'expected_mask':rel,'sha256':sha,'selected_pixels':int(mask.sum()),'source_seed_label':label,'matches_immutable53pack_shape_trace':True,'original_RGBA_unchanged':True}

cases=[]
light=np.zeros((7,7),bool);light[1:6,1:6]=True;light[3,3]=False
for name,erode,ones in [('enclosed-text-no-erosion',None,[[x,y] for y in range(1,6) for x in range(1,6)]),('enclosed-text-erode1',1,[[x,y] for y in range(2,5) for x in range(2,5)])]:
 spec={'in':[0,0,7,7],'flood':[3,3]}
 if erode is not None:spec['erode']=erode
 cases.append({'id':name,'light':light,'spec':spec,'manual_ones':ones})
light=np.zeros((7,7),bool);light[1:6,1:6]=True;light[0:4,3]=False
cases.append({'id':'open-text-foreground-seed','light':light,'spec':{'in':[0,0,7,7],'flood':[1,1],'erode':0},'manual_ones':[[x,y] for y in range(1,6) for x in range(1,6) if not(x==3 and y<=3)]})
cases.append({'id':'open-text-background-seed','light':light,'spec':{'in':[0,0,7,7],'flood':[3,3],'erode':0},'manual_ones':[[x,y] for y in range(7) for x in range(7) if x in (0,6) or y in (0,6) or (x==3 and y<=3)]})
light=np.ones((3,3),bool);light[0,0]=False;light[1,1]=False
cases.append({'id':'diagonal-dark-hole-fills-four-not-eight','light':light,'spec':{'in':[0,0,3,3],'flood':[1,1]},'manual_ones':[[x,y] for y in range(3) for x in range(3) if (x,y)!=(0,0)]})
light=np.zeros((7,9),bool);light[:,3:6]=True
for name,erosion,ones in [('two-disjoint-background-labelzero',None,[[x,y] for y in range(7) for x in [0,1,2,6,7,8]]),('background-labelzero-erode0',0,[[x,y] for y in range(7) for x in [0,1,2,6,7,8]]),('background-labelzero-erode1',1,[[x,y] for y in range(1,6) for x in [1,7]]),('background-labelzero-negative-erosion',-1,[])]:
 spec={'in':[0,0,9,7],'flood':[1,3]}
 if erosion is not None:spec['erode']=erosion
 cases.append({'id':name,'light':light,'spec':spec,'manual_ones':ones})
for name,alllight,erosion,ones in [('empty-light-labelzero-allbackground',False,None,[[x,y] for y in range(5) for x in range(5)]),('full-light-no-erosion',True,None,[[x,y] for y in range(5) for x in range(5)]),('full-light-erode2',True,2,[[2,2]]),('full-light-negative-erosion',True,-1,[])]:
 spec={'in':[0,0,5,5],'flood':[2,2]}
 if erosion is not None:spec['erode']=erosion
 cases.append({'id':name,'light':np.full((5,5),alllight,bool),'spec':spec,'manual_ones':ones})
gray=np.tile(np.array([0,1,120,121],np.uint8),(3,1))
for threshold,name,ones in [(None,'lum-default120-strict',[[3,y] for y in range(3)]),(0,'lum-explicitzero-not-default',[[x,y] for y in range(3) for x in range(1,4)]),(-1,'lum-negative-alllight',[[x,y] for y in range(3) for x in range(4)]),(255,'lum255-emptylight-labelzero',[[x,y] for y in range(3) for x in range(4)])]:
 spec={'in':[0,0,4,3],'flood':[3,1]}
 if threshold is not None:spec['lum_gt']=threshold
 cases.append({'id':name,'gray':gray,'spec':spec,'manual_ones':ones})
light=np.zeros((9,9),bool);light[3:6,3:6]=True
cases.append({'id':'crop-erosion-before-paste','light':light,'spec':{'in':[2,2,5,5],'flood':[4,4],'erode':1},'manual_ones':[[4,4]]})
light=np.zeros((5,5),bool);light[:,2]=True
cases.append({'id':'negative-global-seed-wraps-to-labelzero','light':light,'spec':{'in':[0,0,5,5],'flood':[-1,2]},'manual_ones':[[x,y] for y in range(5) for x in [0,1,3,4]]})
light=np.zeros((9,9),bool);light[2:7,2:7]=True
cases.append({'id':'left-of-crop-seed-wraps-to-foreground','light':light,'spec':{'in':[2,2,5,5],'flood':[1,4]},'manual_ones':[[x,y] for y in range(2,7) for x in range(2,7)]})

small=[]
for case in cases:
 spec=case['spec'];gray=case.pop('gray') if 'gray' in case else np.where(case.pop('light'),121,120).astype(np.uint8);h,w=gray.shape;a=np.zeros((h,w,4),np.uint8);a[:,:,:3]=gray[:,:,None] # alpha0 remains deliberate
 before=hashlib.sha256(a.tobytes()).hexdigest();mask=env['shape_mask']((h,w),spec,a);manual=np.zeros((h,w),bool)
 for x,y in case['manual_ones']:manual[y,x]=True
 assert np.array_equal(mask,manual),case['id'];assert hashlib.sha256(a.tobytes()).hexdigest()==before
 inputrel='inputs/'+before+'.rgba';(out/inputrel).write_bytes(a.tobytes());trace={'np':np,'ndi':ndi,'mx':env['mx'],'orig':a,'s':spec};exec(prefix_code,trace);selected_label=int(trace['lab'][spec['flood'][1]-spec['in'][1],spec['flood'][0]-spec['in'][0]])
 stages={}
 for name,m in [('source_light',trace['light']),('source_letters',trace['letters']),('source_ok',trace['ok']),('source_selected_before_erosion',trace['reg']),('final_wholecanvas_mask',mask)]:
  data=(m.astype(np.uint8)*255).tobytes();sha=hashlib.sha256(data).hexdigest();rel='blobs/'+sha+'.mask';(out/rel).write_bytes(data);stages[name]={'shape':list(m.shape),'mask':rel,'sha256':sha,'selected_pixels':int(m.sum())}
 assert np.array_equal(trace['ok'],ndi.binary_fill_holes(trace['light']))
 case.update({'shape':[h,w,4],'original_raw':inputrel,'original_sha256':before,'expected_mask':stages['final_wholecanvas_mask']['mask'],'mask_sha256':stages['final_wholecanvas_mask']['sha256'],'selected_pixels':int(mask.sum()),'source_seed_label':selected_label,'source_border_labels':sorted(int(n) for n in trace['border']),'source_stages':stages,'manual_fullmask_equals_original_wrapper':True,'source_ok_equals_default_four_fillholes':True});small.append(case)

# Exhaustive tiny equivalence uses EXACT AST-sliced original statements, not a replacement algorithm.
equivalence=[]
for bits in range(512):
 light=np.array([(bits>>i)&1 for i in range(9)],bool).reshape(3,3);a=np.zeros((3,3,4),np.uint8);a[:,:,:3]=np.where(light,121,120)[:,:,None];trace={'np':np,'ndi':ndi,'mx':env['mx'],'orig':a,'s':{'in':[0,0,3,3]}};exec(hole_code,trace);filled=ndi.binary_fill_holes(light);assert np.array_equal(trace['ok'],filled)
 equivalence.append({'bits':bits,'source_ok_byte_hex':trace['ok'].astype(np.uint8).tobytes().hex()})
diagonal=np.ones((3,3),bool);diagonal[0,0]=False;diagonal[1,1]=False;four=ndi.binary_fill_holes(diagonal);eight=ndi.binary_fill_holes(diagonal,structure=np.ones((3,3),bool));assert four[1,1] and not eight[1,1]
equivalence_fact={'cases':512,'input_shape':[3,3],'source_ok_equals_SciPy_default_four_fillholes_all_cases':True,'source_method':'ExactASTslice x/y/w/h->sub->light->darklabel4->cropborderlabels->letters->ok','rows':equivalence,'eight_neighbor_counterexample':{'input_light_01':diagonal.astype(int).tolist(),'four_result_01':four.astype(int).tolist(),'eight_result_01':eight.astype(int).tolist()},'qualification':'Finiteindependentlibraryequivalence onall3x3patterns pluslargerexplicitcases; not a claim candidateGo was executed or arbitraryfuturephaseordering is equivalent.'}
(out/'fillholes-equivalence.json').write_text(json.dumps(equivalence_fact,indent=2)+'\n')

a=np.zeros((5,5,4),np.uint8);a[:,:,:3]=121;refusals=[]
for name,spec in [('seed-right-of-crop',{'in':[1,1,3,3],'flood':[4,2]}),('seed-too-negative-local',{'in':[1,1,3,3],'flood':[-3,2]}),('seed-fractional',{'in':[0,0,5,5],'flood':[1.5,2]}),('seed-bad-arity',{'in':[0,0,5,5],'flood':[2]}),('seed-none',{'in':[0,0,5,5],'flood':None}),('erosion-fractional',{'in':[0,0,5,5],'flood':[2,2],'erode':1.5}),('empty-crop-height',{'in':[0,0,5,0],'flood':[2,0]}),('threshold-none',{'in':[0,0,5,5],'flood':[2,2],'lum_gt':None})]:
 before=hashlib.sha256(a.tobytes()).hexdigest()
 try:r=env['shape_mask']((5,5),spec,a);result={'outcome':'success','selected_pixels':int(r.sum())}
 except (SystemExit,ValueError,IndexError,KeyError,TypeError) as exc:result={'outcome':type(exc).__name__,'message':str(exc)}
 assert result['outcome']!='success';assert hashlib.sha256(a.tobytes()).hexdigest()==before;refusals.append({'id':name,'source_spec':spec,'input_shape':[5,5,4],'original_rgba_hex':a.tobytes().hex(),**result,'original_RGBA_unchanged':True,'qualification':'Originalhelper exception observation only, no typedAPI/schema or futureerrorwording chosen.'})

facts={'status':'ORIGINAL_ONLY precodefloodpermissioncontract/oracles. No candidateGo, schema or implementation chosen.','ancestry':ancestry,'source_pins':sourcepins,'actual_records':records,'fixture_inputs':inputs,'expected_actual':actual,'small_source_cases':small,'source_refusal_observations':refusals,'counts':{'expanded_flood_allow_add_calls':6,'unique_literal_records':3,'textures':['mini_g02','mini_g12'],'actual_fixture_inputs':2,'actual_masks':12,'small_manual_fullmask_cases':len(small),'source_exception_observations':len(refusals),'exhaustive3x3_fillholes_equivalence_cases':512},'exact_source_order':['Strict integerluma>source lum_gt default120 (explicit0honored), alphaignored','Labeldark4; collectcropborderlabels; enclosed darkcomponents becomeletters','ok=lightORletters, exactlydefault4fillholes(light)','Labelok4; lookupseed-croporigin usingNumPyindexing','reg=(lab==seedlabel), INCLUDINGlabel0selectingALLbackgroundpixels even disconnected','Ifsourceerode truthy: defaultcross erosionofreg withinCROP; zero/absent skips, negativeiteratesuntilstable','PastecroppedregintootherwiseFalsewholecanvas'], 'source_boundaries':'Backgroundseed isnot refused. Emptylightcanproducefullcrop via label0; full lightalsofullcrop via label1. Boundednegativeindiceswrap; positive/outofrange/fractional/malformedseedscauseoriginalexceptions. No originalvalidatedwork/seed/crop/iterationcaps. Sourceerosionnegativeuntilstable eventuallyemptiesfiniteboundedregion withoutsidefalse; this differs from dilation and currentgrow0skip.','shared_responsibility_direction':'Parent-describedexistingselectRaster canconstruct originalcrop lightpredicate; existingfourconnectedfill topology reproducesenclosedletterconstruction. Existingcomponentphaseforeground-seedcontractcannotrepresentlabel0asALLbackground bymerelyselectingonebackgroundcomponent orrefusingit; retainthatsemanticduty explicitly. ExistingtransformRasterMask topology owner iscandidateforpost-selection4erosion; it mustoccurafterselectionwithcrop-exteriorfalse, cannotbeapproximatedbyclosing ornegativegrowth. No newfunctions/handlers/framework/APIchosen.','global53_boundary':{'manifest':str(globalpack/'manifest.json'),'sha256':'bae488bad73d006b0a7ab6c7d0010f95acc0cee5646c93321db8be7a0634a6ee','complete_source_global_contexts':4,'fixture_replays':8,'stage_fields':56,'immutable_unchanged':True,'no_omissions_or_replacement_facts':'Newactualfloodhashes matcheach correspondingimmutable53packshape trace. Originalglobalfactsremaincompleteonsyntheticinputs; noGo/fullart/texture/familycredit.'},'safe_execution':'Exact priorASTselectedpurehelpers only. Originalshape_mask createsblankpinnedPillowImage/Draw context beforebranch but floodreturnsbeforeanydrawingmethod/dynamicmoduleimport/art hook. No originalmoduleimports/main/constructorsreadingstate. NumPy/SciPypins reused frompriorcore.','all_owned_jobs_terminal':True}
(out/'source-facts.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps({'counts':facts['counts'],'actual_pixels':{n:[q['selected_pixels'] for q in rs.values()] for n,rs in actual.items()},'small_cases':[(q['id'],q['source_seed_label'],q['selected_pixels']) for q in small],'refusals':[(q['id'],q['outcome'],q['message']) for q in refusals]},indent=2))
