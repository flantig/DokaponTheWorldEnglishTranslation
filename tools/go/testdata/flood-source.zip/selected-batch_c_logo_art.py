def rect_mask(shape, r):
    m = np.zeros(shape[:2], bool)
    x, y, w, h = r
    m[max(0, y):y + h, max(0, x):x + w] = True
    return m

def lumi(a):
    return mx.lum(a)

def footprint(orig, s):
    """old lettering footprint inside s['in']: pixels matching any of s['letter']
    colour tests, closed/filled and grown by s['grow'] px (outline + AA)."""
    x, y, w, h = s['in']
    sub = orig[y:y + h, x:x + w].astype(np.int32)
    m = _tests(sub, s['letter'])
    if s.get('close'):
        m = ndi.binary_closing(m, iterations=s['close'])
    if s.get('fill', True) == 'core':
        m |= ndi.binary_fill_holes(_tests(sub, s['core']))
    elif s.get('fill', True):
        m = ndi.binary_fill_holes(m)
    if 'core' in s:
        m &= ndi.binary_dilation(_tests(sub, s['core']), iterations=s.get('core_grow', 4))
    if s.get('min_size'):
        lab, n = ndi.label(m)
        sizes = ndi.sum(m, lab, range(1, n + 1))
        m = np.isin(lab, [i + 1 for i, z in enumerate(sizes) if z >= s['min_size']])
    m = ndi.binary_dilation(m, iterations=s.get('grow', 1)) if s.get('grow', 1) else m
    out = np.zeros(orig.shape[:2], bool)
    out[y:y + h, x:x + w] = m
    if 'clip' in s:
        out &= rect_mask(orig.shape, s['clip'])
    for r in s.get('exclude', []):
        out &= ~rect_mask(orig.shape, r)
    return out

def _tests(sub, tests):
    h, w = sub.shape[:2]
    r, g, b, al = (sub[..., 0], sub[..., 1], sub[..., 2], sub[..., 3])
    L = lumi(sub)
    m = np.zeros((h, w), bool)
    for t in tests:
        mm = np.ones((h, w), bool)
        for k, v in t.items():
            if k == 'lum_lt':
                mm &= L < v
            elif k == 'lum_gt':
                mm &= L > v
            elif k == 'rb_gt':
                mm &= r - b > v
            elif k == 'br_gt':
                mm &= b - r > v
            elif k == 'rg_gt':
                mm &= r - g > v
            elif k == 'r_gt':
                mm &= r > v
            elif k == 'r_lt':
                mm &= r < v
            elif k == 'b_gt':
                mm &= b > v
            elif k == 'b_lt':
                mm &= b < v
            elif k == 'g_gt':
                mm &= g > v
            elif k == 'g_lt':
                mm &= g < v
            elif k == 'alpha_gt':
                mm &= al > v
            elif k == 'alpha_lt':
                mm &= al < v
            elif k == 'sat_gt':
                mm &= sub[..., :3].max(axis=2) - sub[..., :3].min(axis=2) > v
            elif k == 'sat_lt':
                mm &= sub[..., :3].max(axis=2) - sub[..., :3].min(axis=2) < v
            elif k == 'near':
                c = np.array(v[:3])
                mm &= np.abs(sub[..., :3] - c).max(axis=2) <= t.get('tol', 0)
            elif k == 'far':
                c = np.array(v[:3])
                mm &= np.abs(sub[..., :3] - c).max(axis=2) > t.get('ftol', 0)
            elif k in ('tol', 'ftol'):
                pass
            else:
                raise SystemExit('footprint: unknown key %r' % k)
        m |= mm
    return m

def logo_allow(orig, s):
    """allow part = zone AND (background-like pixels OR old-lettering footprint).
    s = {"zone": R, "fp": footprint spec, "bg": [tests] (pixels new art may cover,
    e.g. transparent or flat cream)}.  Art that is neither (bubble, card, grid)
    stays outside the allow mask unless the old letters covered it."""
    zone = rect_mask(orig.shape, s['zone'])
    fp = footprint(orig, s['fp']) if 'fp' in s else np.zeros(orig.shape[:2], bool)
    bgm = np.zeros(orig.shape[:2], bool)
    if s.get('bg'):
        bgm = footprint(orig, {'in': s['zone'], 'letter': s['bg'], 'grow': 0, 'fill': False})
    return zone & (bgm | fp)

def remnants(orig, s):
    """opaque connected pieces inside s['in'] that contain no white pixel (= bits of
    old letters poking out below the erase zone, not the white thought bubbles)."""
    x, y, w, h = s['in']
    sub = orig[y:y + h, x:x + w]
    if s.get('bg') == 'cream':
        op = np.abs(sub[..., :3].astype(np.int32) - np.array(CREAM[:3])).max(axis=2) > s.get('tol', 12)
    else:
        op = sub[..., 3] > s.get('alpha_gt', 8)
    white = (sub[..., :3].min(axis=2) > 225) & op
    lab, n = ndi.label(op, np.ones((3, 3), bool))
    keep = set(np.unique(lab[white])) - {0}
    m = op & ~np.isin(lab, list(keep))
    out = np.zeros(orig.shape[:2], bool)
    out[y:y + h, x:x + w] = m
    return out
