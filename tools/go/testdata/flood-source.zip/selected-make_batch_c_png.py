def shape_mask(shape, s, orig):
    H, W = shape
    if 'rect' in s:
        x, y, w, h = s['rect']
        m = np.zeros((H, W), bool)
        m[max(0, y):y + h, max(0, x):x + w] = True
        return m
    img = Image.new('L', (W * SS, H * SS), 0)
    d = ImageDraw.Draw(img)
    if 'rrect' in s:
        x, y, w, h = s['rrect']
        d.rounded_rectangle([x * SS, y * SS, (x + w) * SS - 1, (y + h) * SS - 1], radius=s.get('radius', 8) * SS, fill=255)
    elif 'ellipse' in s:
        cx, cy, rx, ry = s['ellipse']
        d.ellipse([(cx - rx) * SS, (cy - ry) * SS, (cx + rx) * SS, (cy + ry) * SS], fill=255)
    elif 'poly' in s:
        d.polygon([(x * SS, y * SS) for x, y in s['poly']], fill=255)
    elif 'alpha_gt' in s:
        x, y, w, h = s['in']
        m = np.zeros((H, W), bool)
        m[y:y + h, x:x + w] = orig[y:y + h, x:x + w, 3] > s['alpha_gt']
        return m
    elif 'maskfn' in s:
        mod, fn = s['maskfn'].split(':')
        return np.asarray(getattr(importlib.import_module(mod), fn)(orig, s), bool)
    elif 'mask' in s:
        x, y, w, h = s['in']
        m = np.zeros((H, W), bool)
        m[y:y + h, x:x + w] = mx.make_mask(orig[y:y + h, x:x + w], s['mask'], {})
        return mx.grow(m, s.get('grow', 0))
    elif 'flood' in s:
        x, y, w, h = s['in']
        sub = orig[y:y + h, x:x + w]
        light = mx.lum(sub) > s.get('lum_gt', 120)
        dark_lab, _ = ndi.label(~light)
        border = set(np.unique(np.concatenate([dark_lab[0], dark_lab[-1], dark_lab[:, 0], dark_lab[:, -1]])))
        letters = ~light & ~np.isin(dark_lab, list(border - {0}))
        ok = light | letters
        lab, _ = ndi.label(ok)
        sx, sy = s['flood']
        reg = lab == lab[sy - y, sx - x]
        if s.get('erode'):
            reg = ndi.binary_erosion(reg, iterations=s['erode'])
        m = np.zeros((H, W), bool)
        m[y:y + h, x:x + w] = reg
        return m
    else:
        raise SystemExit('unknown allow shape %r' % s)
    a = np.array(img).reshape(H, SS, W, SS).min(axis=(1, 3))
    return a > 0

def build_allow(tex, shape, orig, frags):
    shapes = list(tex.get('allow', []))
    for o in tex['ops']:
        if o.get('op') == 'include':
            shapes += frags[o['frag']].get('allow', [])
    if not shapes:
        shapes = [{'rect': r} for r in all_rects(tex, frags)]
    pos = np.zeros(shape, bool)
    neg = np.zeros(shape, bool)
    for s in shapes:
        m = shape_mask(shape, s, orig)
        if s.get('minus'):
            neg |= m
        else:
            pos |= m
    res = pos & ~neg
    for s in tex.get('allow_add', []):
        res |= shape_mask(shape, s, orig)
    return res

def all_rects(tex, frags):
    r = [list(x) for x in tex.get('rects', [])]
    for o in tex['ops']:
        if o.get('op') == 'include':
            r += [list(x) for x in frags[o['frag']].get('rects', [])]
    return r

def op_erase(a, orig, o, colors, allow):
    H, W = allow.shape
    x, y, w, h = o['rect']
    R = np.zeros((H, W), bool)
    R[y:y + h, x:x + w] = True
    lim = R & allow
    sub = a[y:y + h, x:x + w]
    m = np.zeros((H, W), bool)
    m[y:y + h, x:x + w] = mx.make_mask(sub, o.get('mask', 'all'), colors)
    m &= lim
    if o.get('fill_holes'):
        m = ndi.binary_fill_holes(m) & lim
    hole = mx.grow(m, o.get('grow', 0)) & lim
    if not hole.any():
        return
    meth = o.get('method', 'flat')
    if meth == 'flat':
        a[hole] = mx.col(o['color'], colors)
    elif meth == 'clear':
        a[hole] = (0, 0, 0, 0)
    elif meth in ('rows', 'cols', 'telea'):
        sx = dict(o, op='inpaint', mask='all')
        tmp = a.copy()
        sub = tmp[y:y + h, x:x + w]
        hm = hole[y:y + h, x:x + w]
        if meth in ('rows', 'cols'):
            s = sub.astype(float)
            mm = hm
            if meth == 'cols':
                s, mm = (s.transpose(1, 0, 2), hm.T)
            for j in range(s.shape[0]):
                if not mm[j].any():
                    continue
                good = np.nonzero(~mm[j])[0]
                if len(good) == 0:
                    continue
                for c in range(4):
                    s[j, :, c] = np.interp(np.arange(s.shape[1]), good, s[j, good, c])
            if meth == 'cols':
                s = s.transpose(1, 0, 2)
            sub[:] = np.rint(s).astype(np.uint8)
        else:
            import cv2
            c = o.get('context', 8)
            X0, Y0, X1, Y1 = (max(0, x - c), max(0, y - c), min(W, x + w + c), min(H, y + h + c))
            big = tmp[Y0:Y1, X0:X1].copy()
            mk = hole[Y0:Y1, X0:X1].astype(np.uint8) * 255
            rgb = cv2.inpaint(np.ascontiguousarray(big[..., :3]), mk, o.get('radius', 3), cv2.INPAINT_TELEA)
            big[..., :3] = rgb
            tmp[Y0:Y1, X0:X1] = big
        del sx
        a[hole] = tmp[hole]
    elif meth == 'exemplar':
        dx, dy, dw, dh = o.get('donor_rect', [x - 16, y - 16, w + 32, h + 32])
        region = np.zeros((H, W), bool)
        region[max(0, dy):dy + dh, max(0, dx):dx + dw] = True
        region &= allow
        region |= hole
        if 'donor' in o:
            dm = np.zeros((H, W), bool)
            dm[max(0, dy):dy + dh, max(0, dx):dx + dw] = mx.make_mask(a[max(0, dy):dy + dh, max(0, dx):dx + dw], o['donor'], colors)
        else:
            dm = ~m
        out = exemplar_inpaint(a, hole, region, P=o.get('P', 4), seed=o.get('seed', 1), core=o.get('core', 1), donor=dm)
        a[hole] = out[hole]
    else:
        raise SystemExit('unknown erase method %r' % meth)
