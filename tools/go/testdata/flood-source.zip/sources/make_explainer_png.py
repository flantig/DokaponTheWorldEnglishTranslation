#!/usr/bin/env python3
r"""make_explainer_png.py - data-driven English re-lettering of baked-Japanese
textures (explainer cards, banners, HUD sheets) for the Dokapon Kingdom mod.

One JSON spec describes any number of textures.  For each texture the script
reads the exported ORIGINAL texture PNG (cmb_tex_patch.py export), applies the
spec's ops in order (erase / inpaint / copy / text), snaps every edited pixel
to a colour that already occurs in the original texture (so only existing
palette colours are used), forces every pixel OUTSIDE the declared `rects`
back to the original, and writes the edited full-size PNG.  The `rects` are
exactly the `--rect` arguments to pass to cmb_tex_patch.py.

Lettering: Noto Sans Condensed (SIL OFL 1.1, /usr/share/fonts/google-noto/)
by default; "Game" uses the extracted Latin glyph atlas and native spacing.
"GameOptical" keeps those glyphs but tightens excess side space.
Both render with Pillow at 4x supersampling; strokes/shadows use dilation.

usage:
  make_explainer_png.py SPEC.json --src-dir DIR --out-dir DIR [--only KEY ...]
      reads DIR/<key>.png, writes OUT/<key>.png, prints the --rect list.

Spec format (JSON):
{
  "colors": {"black": [0,0,0,255], ...},          # named colours (optional)
  "textures": [
    {"key": "area_0", "cmb": "GRAPHIC/FIELD.CMB", "entry": "field/area/area_0.txd",
     "jp": "...", "en": "...",                       # for the index page
     "rects": [[x,y,w,h], ...],                      # the ONLY pixels that may change
     "snap": true,                                   # snap edits to original colours (default)
     "ops": [ ... ]}
  ]
}
Ops (all coordinates in texture pixels):
  {"op":"fill",  "rect":[x,y,w,h], "color":C}             solid fill (C = name or [r,g,b,a])
  {"op":"clear", "rect":[x,y,w,h]}                        fully transparent
  {"op":"inpaint","rect":R, "mask":M, "method":"telea"|"ns"|"rows"|"cols"|"flat",
        "radius":3, "grow":1, "fill_holes":false, "color":C, "context":8}
        (telea/ns see `context` px around the rect; only the rect is written)
        M = "all" | {"lum_lt":L} | {"lum_gt":L} | {"near":C,"tol":T} | {"alpha_gt":A}
            | {"not_near":C,"tol":T} | {"sat_gt":S} | {"sat_lt":S} (max-min of RGB);
            several keys in M are AND-ed; a LIST of such dicts is AND-ed too.
        "flat" paints `color`.  telea/ns use OpenCV inpainting (RGB and alpha).
  {"op":"rrect", "rect":[x,y,w,h], "radius":8, "color":C, "clip":[x,y,w,h]}  AA rounded rect
  {"op":"copy",  "src":[x,y,w,h], "dst":[x,y] | [x,y,w,h] (tiles src), "from":"orig"|"work"}
  {"op":"text",  "text":"plain or {key:coloured} markup", "color":C,
        "font":"ExtraBold", "px":14, "at":[x,y], "align":"center"|"left"|"right",
        "valign":"cap"|"baseline", "max_w":W, "min_px":8, "sx":1.0, "sy":1.0,
        "skew":0.0, "tracking":0.0, "rotate":deg (ccw, about the text centre),
        "fill":{"grad":[C,...]} (vertical gradient over the cap height, overrides run colours),
        "strokes":[[radius_px, C], ...]  (outermost first; drawn under the fill),
        "shadow":{"dx":2,"dy":2,"radius":r,"color":C}  (offset dilated copy, under strokes),
        "extrude":{"dx":1.5,"dy":2,"color":C}  (solid 3-D extrusion, over strokes, under fill),
        "fill":{"from_orig":{"rect":R,"mask":M,"erode":0,"offset":[dx,dy]}}
            (letter surface = nearest ORIGINAL pixel matching M inside R: reuses the old
             letters' flame/grunge texture)}
  {"op":"lines", "box":[x,y,w,h], "lines":["markup", ...], "font":..., "px":P,
        "leading":L (px, default 1.25*P), "align":"center", "color":C, "min_px":8,
        "valign":"middle"|"top", + any text style key}
        auto-shrinks P (and L proportionally) until every line fits w and the block fits h.
Markup: "Spin the {g:roulette}!" draws 'roulette' in colours["g"]; "{{" / "}}" are literal;
"{@dpad}" reserves room for the texture's icon "dpad" (texture field "icons":
{"dpad":[x,y,w,h]}) and pastes the ORIGINAL pixels of that rect there, centred
on the line (use it to keep button/item icons inline with the English).
Fonts: "Game" and "GameOptical" use extracted/glyph_tiles/font0_bgra.png and
the original executable's font metrics. Other short names map to NotoSans-Condensed<Name>.ttf
(ExtraBold, Bold, Black, BlackItalic, ExtraBoldItalic, SemiBold, Medium, ...).
"""
import argparse
import json
import os
import re
import struct
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFont

try:
    import cv2
except ImportError:  # inpaint telea/ns need it; other ops do not
    cv2 = None

SS = 4
FONT_DIR = "/usr/share/fonts/google-noto/"
_font_cache = {}
_game_font_data = None


def game_font_data():
    """Read the extracted glyph sheet and the game's own spacing table."""
    global _game_font_data
    if _game_font_data is None:
        root = Path(__file__).resolve().parent.parent
        atlas = Image.open(root / "extracted/glyph_tiles/font0_bgra.png").convert("RGBA").getchannel("A")
        atlas = atlas.point(lambda alpha: min(255, alpha * 2))  # PS2 alpha 128 means opaque.
        mapping = json.loads((root / "extracted/glyphmap.json").read_text(encoding="utf-8"))
        chars = {}
        for index, char in mapping.items():
            if int(index) < 95 and char:
                chars.setdefault(char, int(index))
        elf = (root / "extracted/iso-root/SLPM_657.50").read_bytes()
        delta = 0xFFF80
        base = struct.unpack_from("<I", elf, 0x534700 - delta)[0] - delta
        metrics = {index: tuple(elf[base + index * 3:base + index * 3 + 3]) for index in range(95)}
        _game_font_data = atlas, chars, metrics
    return _game_font_data


class GameBitmapFont:
    """Pillow-sized view of Dokapon's extracted Latin bitmap glyphs."""

    def __init__(self, size, optical=False):
        self.atlas, self.chars, self.metrics = game_font_data()
        self.scale = size / 24
        self.optical = optical

    def index(self, char):
        if char == " ":
            return 0
        if char == "'":
            return self.chars[","]
        if char not in self.chars:
            raise ValueError("game font has no glyph for %r" % char)
        return self.chars[char]

    def advance(self, char):
        if char == " ":
            return 14 * self.scale
        left, ink, _ = self.metrics[self.index(char)]
        native = max(22, left + ink + 3) - left
        gap = min(native - ink, 4) if self.optical else native - ink
        return (ink + gap) * self.scale

    def getlength(self, text):
        return sum(self.advance(char) for char in text)

    def getmetrics(self):
        return round(22 * self.scale), round(2 * self.scale)

    def getbbox(self, _text, anchor=None):
        return (0, round(-17 * self.scale), 0, 0)

    def draw(self, text, x, baseline, mask, colors, color):
        y = round(baseline - 22 * self.scale)
        cell = max(1, round(24 * self.scale))
        for char in text:
            index = self.index(char)
            if index:
                left = self.metrics[index][0]
                tile = self.atlas.crop(((index % 21) * 24, (index // 21) * 24,
                                        (index % 21 + 1) * 24, (index // 21 + 1) * 24))
                if char == "'":
                    raised = Image.new("L", (24, 24))
                    raised.paste(tile.crop((0, 14, 24, 24)), (0, 0))
                    tile = raised
                tile = tile.resize((cell, cell), Image.Resampling.LANCZOS)
                pos = (round(x - left * self.scale), y)
                previous = mask.crop((pos[0], pos[1], pos[0] + cell, pos[1] + cell))
                mask.paste(ImageChops.lighter(previous, tile), pos)
                ink = Image.new("RGBA", tile.size, color)
                ink.putalpha(tile)
                colors.alpha_composite(ink, dest=pos)
            x += self.advance(char)


# ------------------------------------------------------------------ helpers
def font_path(name):
    if name.endswith(".ttf"):
        return name
    p = FONT_DIR + "NotoSans-Condensed%s.ttf" % ("" if name in ("", "Regular") else name)
    if not os.path.exists(p):
        raise SystemExit("font not found: %s" % p)
    return p


def get_font(name, px):
    k = (name, round(px * SS))
    if k not in _font_cache:
        if name in ("Game", "GameOptical"):
            _font_cache[k] = GameBitmapFont(k[1], name == "GameOptical")
        else:
            _font_cache[k] = ImageFont.truetype(font_path(name), k[1])
    return _font_cache[k]


def col(c, colors):
    if isinstance(c, str):
        if c not in colors:
            raise SystemExit("unknown colour %r" % c)
        c = colors[c]
    c = list(c)
    if len(c) == 3:
        c.append(255)
    return tuple(int(v) for v in c)


MARK = re.compile(r"\{\{|\}\}|\{(\w+):([^{}]*)\}|\{@(\w+)\}")
ICON = "\ufffc"  # run text of an inline icon; its colour slot holds ("icon", name)


def parse_runs(text, default, colors):
    """'a {r:b} c' -> [('a ', default), ('b', colors['r']), (' c', default)]"""
    runs, pos = [], 0
    for m in MARK.finditer(text):
        if m.start() > pos:
            runs.append((text[pos:m.start()], default))
        if m.group(0) == "{{":
            runs.append(("{", default))
        elif m.group(0) == "}}":
            runs.append(("}", default))
        elif m.group(3):
            runs.append((ICON, ("icon", m.group(3))))
        else:
            runs.append((m.group(2), col(m.group(1), colors)))
        pos = m.end()
    if pos < len(text):
        runs.append((text[pos:], default))
    return [r for r in runs if r[0]]


def lum(a):
    return (a[..., 0].astype(np.int32) * 299 + a[..., 1].astype(np.int32) * 587 +
            a[..., 2].astype(np.int32) * 114) // 1000


def make_mask(sub, m, colors):
    h, w = sub.shape[:2]
    if m == "all":
        return np.ones((h, w), bool)
    if isinstance(m, list):  # AND of several mask dicts
        out = np.ones((h, w), bool)
        for mm in m:
            out &= make_mask(sub, mm, colors)
        return out
    out = np.ones((h, w), bool)
    L = lum(sub)
    for k, v in m.items():
        if k == "lum_lt":
            out &= L < v
        elif k == "lum_gt":
            out &= L > v
        elif k == "alpha_gt":
            out &= sub[..., 3] > v
        elif k in ("sat_gt", "sat_lt"):
            c = sub[..., :3].astype(np.int32)
            sat = c.max(axis=2) - c.min(axis=2)
            out &= (sat > v) if k == "sat_gt" else (sat < v)
        elif k in ("near", "not_near"):
            c = np.array(col(v, colors)[:3], np.int32)
            d = np.abs(sub[..., :3].astype(np.int32) - c).max(axis=2) <= m.get("tol", 0)
            out &= d if k == "near" else ~d
        elif k in ("tol",):
            pass
        else:
            raise SystemExit("unknown mask key %r" % k)
    return out


def grow(mask, n):
    if n <= 0:
        return mask
    m = mask.copy()
    for _ in range(n):
        g = m.copy()
        g[1:] |= m[:-1]
        g[:-1] |= m[1:]
        g[:, 1:] |= m[:, :-1]
        g[:, :-1] |= m[:, 1:]
        m = g
    return m


def fill_holes(mask):
    from scipy.ndimage import binary_fill_holes
    return binary_fill_holes(mask)


def disk(r):
    r = max(0, int(round(r)))
    y, x = np.mgrid[-r:r + 1, -r:r + 1]
    return ((x * x + y * y) <= r * r + r).astype(np.uint8)


def dilate(mask_u8, r):
    """grey-level dilation of an 0..255 mask by a disc of radius r (supersampled px)."""
    if r <= 0:
        return mask_u8
    if cv2 is not None:
        return cv2.dilate(mask_u8, disk(r))
    from scipy.ndimage import grey_dilation
    return grey_dilation(mask_u8, footprint=disk(r).astype(bool))


# ------------------------------------------------------------------- ops
def op_inpaint(a, o, colors):
    x, y, w, h = o["rect"]
    sub = a[y:y + h, x:x + w].copy()
    m = make_mask(sub, o.get("mask", "all"), colors)
    if o.get("fill_holes"):
        m = fill_holes(m)
    m = grow(m, o.get("grow", 0))
    meth = o.get("method", "telea")
    if not m.any():
        return
    if meth == "flat":
        sub[m] = col(o["color"], colors)
    elif meth in ("rows", "cols"):
        s = sub.astype(float)
        if meth == "cols":
            s = s.transpose(1, 0, 2)
            mm = m.T
        else:
            mm = m
        for j in range(s.shape[0]):
            row = mm[j]
            if not row.any():
                continue
            good = np.nonzero(~row)[0]
            if len(good) == 0:
                continue
            for c in range(4):
                s[j, :, c] = np.interp(np.arange(s.shape[1]), good, s[j, good, c])
        if meth == "cols":
            s = s.transpose(1, 0, 2)
        sub = np.rint(s).astype(np.uint8)
    elif meth in ("telea", "ns"):
        if cv2 is None:
            raise SystemExit("OpenCV needed for inpaint method %s" % meth)
        flag = cv2.INPAINT_TELEA if meth == "telea" else cv2.INPAINT_NS
        rad = o.get("radius", 3)
        # work on the rect padded by `context` px so the inpainting sees the
        # surroundings (a mask covering the whole rect needs them); only pixels
        # inside the rect are written back
        c = o.get("context", 8)
        H, W = a.shape[:2]
        X0, Y0, X1, Y1 = max(0, x - c), max(0, y - c), min(W, x + w + c), min(H, y + h + c)
        big = a[Y0:Y1, X0:X1].copy()
        mk = np.zeros(big.shape[:2], np.uint8)
        mk[y - Y0:y - Y0 + h, x - X0:x - X0 + w] = m.astype(np.uint8) * 255
        rgb = cv2.inpaint(np.ascontiguousarray(big[..., :3]), mk, rad, flag)
        al = cv2.inpaint(np.ascontiguousarray(big[..., 3]), mk, rad, flag)
        sub[..., :3] = rgb[y - Y0:y - Y0 + h, x - X0:x - X0 + w]
        sub[..., 3] = al[y - Y0:y - Y0 + h, x - X0:x - X0 + w]
    else:
        raise SystemExit("unknown inpaint method %r" % meth)
    a[y:y + h, x:x + w] = sub


def text_layer(shape, runs, style, colors):
    """Render runs as an RGBA float layer (h,w,4 premultiplied-free) at 1x.
    Returns (layer uint8 RGBA, width_px)."""
    H, W = shape[:2]
    f = get_font(style.get("font", "ExtraBold"), style["px"])
    sx, sy = style.get("sx", 1.0), style.get("sy", 1.0)
    skew = style.get("skew", 0.0)
    trk = style.get("tracking", 0.0) * SS
    icons = style.get("_icons", {})
    gap = style.get("icon_gap", 2)

    def run_adv(t, c):
        if t == ICON:
            return (icons[c[1]][2] + 2 * gap) * SS / sx
        return f.getlength(t) + trk * max(0, len(t))
    # glyph masks per run on a tight canvas
    adv = [run_adv(t, c) for t, c in runs]
    tw = sum(adv) - trk
    asc, desc = f.getmetrics()
    capbb = f.getbbox("H", anchor="ls")
    cap = -capbb[1]
    pad = int(SS * (6 + max([r for r, _ in style.get("strokes", [])] + [0]) +
                    abs(style.get("shadow", {}).get("dx", 0)) + abs(style.get("shadow", {}).get("dy", 0)) +
                    style.get("shadow", {}).get("radius", 0))) + int(abs(skew) * (asc + desc)) + 4
    cw, ch = int(tw + 2 * pad), int(asc + desc + 2 * pad)
    base = pad + asc
    glyph = Image.new("L", (cw, ch), 0)
    colimg = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    dg, dc = ImageDraw.Draw(glyph), ImageDraw.Draw(colimg)
    xx = pad
    icon_at = []
    for (t, c), ad in zip(runs, adv):
        if t == ICON:
            icon_at.append((c[1], xx + gap * SS / sx))
            xx += ad
            continue
        if trk:
            for chh in t:
                if isinstance(f, GameBitmapFont):
                    f.draw(chh, xx, base, glyph, colimg, c)
                else:
                    dg.text((xx, base), chh, font=f, fill=255, anchor="ls")
                    dc.text((xx, base), chh, font=f, fill=c, anchor="ls")
                xx += f.getlength(chh) + trk
        else:
            if isinstance(f, GameBitmapFont):
                f.draw(t, xx, base, glyph, colimg, c)
            else:
                dg.text((xx, base), t, font=f, fill=255, anchor="ls")
                dc.text((xx, base), t, font=f, fill=c, anchor="ls")
            xx += ad
    gm = np.array(glyph)
    cm = np.array(colimg)
    # per-pixel run colour: spread run colours into AA fringe using nearest coloured pixel
    rgb = cm[..., :3].astype(np.float32)
    al = cm[..., 3:4].astype(np.float32) / 255.0
    with np.errstate(invalid="ignore", divide="ignore"):
        rgb = np.where(al > 0, rgb, 0)
    fillc = np.dstack([rgb, np.full(gm.shape, 255, np.float32)])
    if "fill" in style and "grad" in style["fill"]:
        g = [np.array(col(c, colors), np.float32) for c in style["fill"]["grad"]]
        top, bot = base - cap, base
        ys = np.clip((np.arange(ch) - top) / max(1, bot - top), 0, 1) * (len(g) - 1)
        i0 = np.floor(ys).astype(int)
        i1 = np.minimum(i0 + 1, len(g) - 1)
        t = (ys - i0)[:, None]
        G = np.array(g)
        rows = G[i0] * (1 - t) + G[i1] * t
        fillc = np.repeat(rows[:, None, :], cw, axis=1).astype(np.float32)
    # composite: shadow, strokes (outer first), extrusion, fill
    out = np.zeros((ch, cw, 4), np.float32)

    def over(dst, rgba_col, alpha):
        a1 = alpha[..., None]
        src = np.broadcast_to(np.asarray(rgba_col, np.float32)[..., :3], dst[..., :3].shape)
        dst[..., :3] = src * a1 + dst[..., :3] * (1 - a1)
        dst[..., 3:4] = 255 * a1 + dst[..., 3:4] * (1 - a1)

    def shift(m, dx, dy):
        r = np.zeros_like(m)
        dx, dy = int(round(dx)), int(round(dy))
        hh, ww = m.shape
        r[max(0, dy):hh + min(0, dy), max(0, dx):ww + min(0, dx)] = \
            m[max(0, -dy):hh - max(0, dy), max(0, -dx):ww - max(0, dx)]
        return r

    sh = style.get("shadow")
    strokes = style.get("strokes", [])
    glyph_stroke = any(color == "glyph" for _, color in strokes)
    if glyph_stroke:
        from scipy.ndimage import binary_fill_holes, distance_transform_edt
        counters = binary_fill_holes(gm > 127) & (gm <= 127)
        _, (iy, ix) = distance_transform_edt(gm == 0, return_indices=True)
        # Keep the outside bold without filling the small openings inside letters.
        inner_rim = (counters & (dilate((gm > 127).astype(np.uint8) * 255, 1.875 * SS) > 127)
                     if any(color == "black" for _, color in strokes) else np.zeros_like(counters))
    if sh:
        r0 = sh.get("radius", strokes[0][0] if strokes else 0)
        m = dilate(gm, r0 * SS).astype(np.float32) / 255
        over(out, col(sh["color"], colors), shift(m, sh.get("dx", 0) * SS, sh.get("dy", 0) * SS))
    for r, c in strokes:
        source = (gm >= 128).astype(np.uint8) * 255 if c == "black" and glyph_stroke else gm
        m = dilate(source, r * SS).astype(np.float32) / 255
        if c == "black" and glyph_stroke:
            m[counters] = inner_rim[counters]
            over(out, col(c, colors), m)
        elif c == "glyph":
            m[counters] = 0
            over(out, cm[iy, ix], m)
        else:
            over(out, col(c, colors), m)
    ex = style.get("extrude")
    if ex:  # solid extrusion of the glyph towards (dx, dy) in colour, under the fill
        dx, dy = ex["dx"] * SS, ex["dy"] * SS
        n = int(max(abs(dx), abs(dy))) or 1
        m = gm.astype(np.float32) / 255
        acc = np.zeros_like(m)
        for k in range(1, n + 1):
            acc = np.maximum(acc, shift(m, dx * k / n, dy * k / n))
        over(out, col(ex["color"], colors), acc)
    from_orig = "fill" in style and "from_orig" in style["fill"]
    m = gm.astype(np.float32) / 255
    if not from_orig:
        a1 = m[..., None]
        out[..., :3] = fillc[..., :3] * a1 + out[..., :3] * (1 - a1)
        out[..., 3:4] = 255 * a1 + out[..., 3:4] * (1 - a1)
    if glyph_stroke:
        out[counters & ~inner_rim] = 0
    geo = dict(cw=cw, ch=ch, base=base, pad=pad, tw=tw, cap=cap, sx=sx, sy=sy, skew=skew)
    layer = place(out, geo, style, shape)
    fa = None
    if from_orig:
        gl = np.zeros((ch, cw, 4), np.float32)
        gl[..., :3] = 255
        gl[..., 3] = gm
        fa = place(gl, geo, style, shape)[..., 3]
    # inline icons: (name, left x, vertical centre) in texture pixels
    ic = [(nm, geo["ox"] + xc * sx / SS, geo["oy"] + (base * sy - cap * sy / 2) / SS) for nm, xc in icon_at]
    return layer, tw * sx / SS, fa, ic


def place(arr, g, style, shape):
    """scale/skew a supersampled RGBA float canvas, area-downsample to 1x and
    position it in a full-size (H,W,4) float layer according to style at/align."""
    H, W = shape[:2]
    lay = Image.fromarray(np.clip(np.rint(arr), 0, 255).astype(np.uint8), "RGBA")
    cw, ch, sx, sy, skew = g["cw"], g["ch"], g["sx"], g["sy"], g["skew"]
    if sx != 1.0 or sy != 1.0:
        lay = lay.resize((max(1, int(round(cw * sx))), max(1, int(round(ch * sy)))), Image.LANCZOS)
    base_s, left_s, tw_s, cap = g["base"] * sy, g["pad"] * sx, g["tw"] * sx, g["cap"]
    if skew:
        lw, lh = lay.size
        extra = int(abs(skew) * lh) + 2
        # output (x', y) samples input x = x' - skew*(base - y): letters lean right for skew > 0
        lay = lay.transform((lw + extra, lh), Image.AFFINE,
                            (1, skew, -skew * base_s, 0, 1, 0), resample=Image.BICUBIC)
    rot = style.get("rotate", 0.0)
    if rot:
        # rotate (degrees, counter-clockwise) about the text centre; pad first so
        # nothing is clipped
        lw0, lh0 = lay.size
        cx, cy = left_s + tw_s / 2, base_s - cap * sy / 2
        padr = int(abs(np.sin(np.radians(rot))) * tw_s / 2) + 8
        big0 = Image.new("RGBA", (lw0 + 2 * padr, lh0 + 2 * padr), (0, 0, 0, 0))
        big0.paste(lay, (padr, padr))
        lay = big0.rotate(rot, resample=Image.BICUBIC, center=(cx + padr, cy + padr))
        left_s += padr
        base_s += padr
    a = np.array(lay).astype(np.float32)
    lh, lw = a.shape[:2]
    pw, ph = (lw + SS - 1) // SS * SS, (lh + SS - 1) // SS * SS
    big = np.zeros((ph, pw, 4), np.float32)
    big[:lh, :lw] = a
    pre = big[..., :3] * (big[..., 3:4] / 255)
    pre = pre.reshape(ph // SS, SS, pw // SS, SS, 3).mean(axis=(1, 3))
    alp = big[..., 3].reshape(ph // SS, SS, pw // SS, SS).mean(axis=(1, 3))
    with np.errstate(invalid="ignore", divide="ignore"):
        rgb1 = np.where(alp[..., None] > 0, pre / (alp[..., None] / 255), 0)
    small = np.dstack([rgb1, alp])
    ax, ay = style["at"]
    align = style.get("align", "center")
    if align == "center":
        ox = ax - (left_s + tw_s / 2) / SS
    elif align == "left":
        ox = ax - left_s / SS
    else:
        ox = ax - (left_s + tw_s) / SS
    if style.get("valign", "cap") == "cap":
        oy = ay - (base_s - cap * sy / 2) / SS
    else:
        oy = ay - base_s / SS
    ox, oy = int(round(ox)), int(round(oy))
    g["ox"], g["oy"] = ox, oy
    layer = np.zeros((H, W, 4), np.float32)
    sh_, sw_ = small.shape[:2]
    x0, y0 = max(0, ox), max(0, oy)
    x1, y1 = min(W, ox + sw_), min(H, oy + sh_)
    if x1 > x0 and y1 > y0:
        layer[y0:y1, x0:x1] = small[y0 - oy:y1 - oy, x0 - ox:x1 - ox]
    return layer


def measure(runs, style):
    f = get_font(style.get("font", "ExtraBold"), style["px"])
    trk = style.get("tracking", 0.0) * SS
    sx = style.get("sx", 1.0)
    icons = style.get("_icons", {})
    gap = style.get("icon_gap", 2)
    w = 0.0
    for t, c in runs:
        if t == ICON:
            w += (icons[c[1]][2] + 2 * gap) * SS / sx
        else:
            w += f.getlength(t) + trk * len(t)
    n = sum(len(t) for t, _ in runs if t != ICON)
    return (w - (trk if n else 0)) / SS * sx


def paste_icons(a, ic, o):
    """copy each inline icon's ORIGINAL pixels (spec 'icons' rect) to its slot."""
    orig = o["_orig"]
    for nm, x, yc in ic:
        sx_, sy_, w, h = o["_icons"][nm]
        dx, dy = int(round(x)), int(round(yc - h / 2))
        a[dy:dy + h, dx:dx + w] = orig[sy_:sy_ + h, sx_:sx_ + w]


def composite(a, layer, alpha_mode="over"):
    """alpha-composite a float RGBA layer over uint8 image a (in place)."""
    al = layer[..., 3:4] / 255
    base = a.astype(np.float32)
    ba = base[..., 3:4] / 255
    oa = al + ba * (1 - al)
    with np.errstate(invalid="ignore", divide="ignore"):
        rgb = np.where(oa > 0, (layer[..., :3] * al + base[..., :3] * ba * (1 - al)) / oa, base[..., :3])
    out = np.dstack([rgb, oa * 255])
    m = al[..., 0] > 0
    a[m] = np.clip(np.rint(out[m]), 0, 255).astype(np.uint8)


def op_text(a, o, colors, report):
    style = dict(o)
    default = col(o.get("color", [0, 0, 0, 255]), colors)
    runs = parse_runs(o["text"], default, colors)
    px = o["px"]
    if "max_w" in o:
        while measure(runs, dict(style, px=px)) > o["max_w"] and px > o.get("min_px", 6):
            px -= 0.25
    style["px"] = px
    layer, w, fa, ic = text_layer(a.shape, runs, style, colors)
    composite(a, layer)
    if fa is not None:
        texture_fill(a, fa, o["fill"]["from_orig"], colors, o.get("_orig"))
    paste_icons(a, ic, o)
    report.append("text %-40r px=%.2f w=%.1f%s" % (o["text"][:40], px, w,
                  "" if "max_w" not in o or w <= o["max_w"] + 0.01 else "  OVER max_w %d" % o["max_w"]))


def op_lines(a, o, colors, report):
    x, y, w, h = o["box"]
    px = o["px"]
    lead_ratio = o.get("leading", 1.25 * o["px"]) / o["px"]
    default = col(o.get("color", [0, 0, 0, 255]), colors)
    allruns = [parse_runs(t, default, colors) for t in o["lines"]]
    style = {k: v for k, v in o.items() if k not in ("box", "lines", "op", "leading")}
    while px > o.get("min_px", 6):
        st = dict(style, px=px)
        if max(measure(r, st) for r in allruns) <= w and lead_ratio * px * len(allruns) <= h + 0.01:
            break
        px -= 0.25
    lead = lead_ratio * px
    n = len(allruns)
    if o.get("valign", "middle") == "middle":
        cy0 = y + h / 2 - lead * (n - 1) / 2
    else:
        cy0 = y + lead / 2
    align = o.get("align", "center")
    ax = {"center": x + w / 2, "left": x, "right": x + w}[align]
    for i, runs in enumerate(allruns):
        st = dict(style, px=px, at=[ax, cy0 + i * lead], align=align, valign="cap")
        layer, lw, fa, ic = text_layer(a.shape, runs, st, colors)
        composite(a, layer)
        if fa is not None:
            texture_fill(a, fa, o["fill"]["from_orig"], colors, o.get("_orig"))
        paste_icons(a, ic, o)
    report.append("lines box=%r n=%d px=%.2f (asked %s)%s" % (o["box"], n, px, o["px"],
                  "  SHRUNK" if px < o["px"] else ""))
    return px


def texture_fill(a, alpha, spec, colors, orig):
    """paint glyph coverage `alpha` (H,W 0..255) with the ORIGINAL texture's own
    fill pixels: each pixel takes the colour of the nearest original pixel inside
    spec['rect'] that matches spec['mask'] (e.g. the flame/grunge interior of
    the old Japanese letters), so the new letters keep the old surface texture."""
    from scipy.ndimage import distance_transform_edt
    x, y, w, h = spec["rect"]
    H, W = alpha.shape
    src = np.zeros((H, W), bool)
    src[y:y + h, x:x + w] = make_mask(orig[y:y + h, x:x + w], spec["mask"], colors)
    if spec.get("erode"):
        from scipy.ndimage import binary_erosion
        src = binary_erosion(src, iterations=spec["erode"])
    if not src.any():
        raise SystemExit("from_orig: empty source mask")
    sxo, syo = spec.get("offset", [0, 0])
    _, (iy, ix) = distance_transform_edt(~src, return_indices=True)
    yy, xx = np.mgrid[0:H, 0:W]
    qy = np.clip(yy + syo, 0, H - 1)
    qx = np.clip(xx + sxo, 0, W - 1)
    tex = orig[iy[qy, qx], ix[qy, qx]].astype(np.float32)
    lay = np.zeros((H, W, 4), np.float32)
    lay[..., :3] = tex[..., :3]
    lay[..., 3] = alpha
    composite(a, lay)


def op_rrect(a, o, colors):
    """anti-aliased filled rounded rectangle, composited, optionally clipped."""
    x, y, w, h = o["rect"]
    r = o.get("radius", 8)
    H, W = a.shape[:2]
    m = Image.new("L", (W * SS, H * SS), 0)
    ImageDraw.Draw(m).rounded_rectangle([x * SS, y * SS, (x + w) * SS - 1, (y + h) * SS - 1],
                                        radius=r * SS, fill=255)
    al = np.array(m, np.float32).reshape(H, SS, W, SS).mean(axis=(1, 3))
    if "clip" in o:
        cx, cy, cw, ch = o["clip"]
        c = np.zeros((H, W), bool)
        c[cy:cy + ch, cx:cx + cw] = True
        al[~c] = 0
    lay = np.zeros((H, W, 4), np.float32)
    lay[..., :3] = col(o["color"], colors)[:3]
    lay[..., 3] = al
    composite(a, lay)


def snap(a, orig, mask):
    """map edited pixels (mask) to the nearest colour present in orig."""
    cols = np.unique(orig.reshape(-1, 4), axis=0).astype(np.int64)
    ys, xs = np.nonzero(mask)
    px = a[ys, xs].astype(np.int64)
    uq, inv = np.unique(px, axis=0, return_inverse=True)
    best = np.zeros((len(uq), 4), np.uint8)
    for i, c in enumerate(uq):
        amin = np.minimum(cols[:, 3], c[3])
        d = ((cols[:, :3] - c[:3]) ** 2).sum(axis=1) * amin // 255 + 3 * (cols[:, 3] - c[3]) ** 2
        best[i] = cols[int(np.argmin(d))]
    a[ys, xs] = best[inv.reshape(-1)]


def render(tex, src_png, colors):
    orig = np.array(Image.open(src_png).convert("RGBA"))
    a = orig.copy()
    report = []
    for o in tex["ops"]:
        o = dict(o, _orig=orig, _icons=tex.get("icons", {}))
        k = o["op"]
        if k == "fill":
            x, y, w, h = o["rect"]
            a[y:y + h, x:x + w] = col(o["color"], colors)
        elif k == "clear":
            x, y, w, h = o["rect"]
            a[y:y + h, x:x + w] = col(o.get("color", [0, 0, 0, 0]), colors)
        elif k == "inpaint":
            op_inpaint(a, o, colors)
        elif k == "copy":
            sx_, sy_, w, h = o["src"]
            srcimg = orig if o.get("from", "work") == "orig" else a.copy()
            patch = srcimg[sy_:sy_ + h, sx_:sx_ + w]
            if len(o["dst"]) == 4:  # tile the source over the dst rect
                dx, dy, dw, dh = o["dst"]
                reps = (-(-dh // h), -(-dw // w), 1)
                a[dy:dy + dh, dx:dx + dw] = np.tile(patch, reps)[:dh, :dw]
            else:
                dx, dy = o["dst"]
                a[dy:dy + h, dx:dx + w] = patch
        elif k == "rrect":
            op_rrect(a, o, colors)
        elif k == "text":
            op_text(a, o, colors, report)
        elif k == "lines":
            op_lines(a, o, colors, report)
        else:
            raise SystemExit("unknown op %r" % k)
    H, W = a.shape[:2]
    m = np.zeros((H, W), bool)
    for x, y, w, h in tex["rects"]:
        if x < 0 or y < 0 or w <= 0 or h <= 0 or x + w > W or y + h > H:
            raise SystemExit("%s: rect %r outside texture" % (tex["key"], (x, y, w, h)))
        m[y:y + h, x:x + w] = True
    a[~m] = orig[~m]
    if tex.get("snap", True):
        snap(a, orig, m & (a != orig).any(axis=2))
    a[~m] = orig[~m]
    return orig, a, report


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("spec")
    ap.add_argument("--src-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--only", nargs="*")
    a = ap.parse_args()
    spec = json.load(open(a.spec))
    colors = {k: tuple(v) for k, v in spec.get("colors", {}).items()}
    os.makedirs(a.out_dir, exist_ok=True)
    for tex in spec["textures"]:
        if a.only and tex["key"] not in a.only:
            continue
        cl = dict(colors)
        cl.update({k: tuple(v) for k, v in tex.get("colors", {}).items()})
        src = os.path.join(a.src_dir, tex["key"] + ".png")
        orig, out, rep = render(tex, src, cl)
        dst = os.path.join(a.out_dir, tex["key"] + ".png")
        Image.fromarray(out, "RGBA").save(dst)
        changed = int((out != orig).any(axis=2).sum())
        print("%s: %d px changed -> %s" % (tex["key"], changed, dst))
        for r in rep:
            print("   ", r)
        print("    rects:", " ".join("--rect %d,%d,%d,%d" % tuple(r) for r in tex["rects"]))


if __name__ == "__main__":
    sys.exit(main())
