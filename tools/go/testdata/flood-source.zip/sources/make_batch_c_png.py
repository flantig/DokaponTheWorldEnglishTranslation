#!/usr/bin/env python3
r"""make_batch_c_png.py - explainer batch C renderer (mini-game rules cards, title
logos, award scrolls) with MASK containment, on top of make_explainer_png.py.

Owner rules (2026-10-01): every edit stays strictly inside the card's / pill's /
scroll's inner border (frame byte-identical); no flat or dark boxes behind new
text: the art's own background is rebuilt (flat panels repainted with their own
colour, textured areas by patch-copy); original colours and outline style;
never clip neighbouring glyphs.

Spec = make_explainer_png spec plus, per texture:
  "allow": [shape, ...]   pixels that MAY change (default: the union of "rects");
            shape = {"rect":[x,y,w,h]} | {"rrect":[x,y,w,h],"radius":r}
                  | {"ellipse":[cx,cy,rx,ry]} | {"poly":[[x,y],...]}
                  | {"alpha_gt":A,"in":[x,y,w,h]}   (opaque art inside a rect)
                  | {"maskfn":"module:function", ...}  (fn(orig, shape) -> bool mask; logos)
                  | {"flood":[sx,sy],"in":[x,y,w,h],"lum_gt":L,"erode":n}  (pill interior: region of
                    non-outline pixels around the seed, enclosed letters included)
                  | {"mask":M,"in":[x,y,w,h],"grow":g}  (ORIGINAL pixels matching mx mask M)
            any shape with "minus": true is subtracted (applied after the unions).
  "allow_add": [shape, ...]  added after the subtraction (pill interiors inside art areas).
  "src":    source PNG basename in --src-dir (default: the key; batch E '~B' variants)
  "rects":  [[x,y,w,h], ...]  cmb_tex_patch --rect list (bounding boxes); the final
            changed set must lie inside  allow AND union(rects).
Extra ops:
  {"op":"erase","rect":R,"mask":M,"grow":g,"method":"flat"|"exemplar"|"rows"|"cols"|"telea"|"clear",
   "color":C, "donor":M2, "donor_rect":R2, "P":4, "core":1, "seed":1}
        hole = R AND allow AND M (mx mask syntax), grown g px, clipped to R AND allow.
        exemplar = patch-copy from donor_rect (default R grown 16) AND allow AND
        NOT hole AND M2 (default: NOT M).  "clear" -> fully transparent.
  {"op":"include","frag":"name"}   ops + allow + rects of a named fragment
        (fragments: top-level "fragments": {name: {"ops":[], "allow":[], "rects":[]}}
         of any spec passed with --spec).
  {"op":"hook","fn":"module:function", ...}  fn(a, orig, op, colors, allow) edits a in place
        (module imported from tools/); used for hand-built logo art.
Text ops (text/lines) are STRICT: any drawn pixel outside allow aborts the build.

usage: make_batch_c_png.py --spec batch_c.json [--spec more.json] --src-dir D --out-dir O [--only K..]
writes O/<key>.png and O/<key>.allow.png (the allow mask, white = may change).
"""
import argparse
import importlib
import json
import os
import sys

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_explainer_png as mx  # noqa: E402
from make_vs_set_icons import exemplar_inpaint  # noqa: E402
from scipy import ndimage as ndi  # noqa: E402

SS = 4


def shape_mask(shape, s, orig):
    H, W = shape
    if "rect" in s:
        x, y, w, h = s["rect"]
        m = np.zeros((H, W), bool)
        m[max(0, y):y + h, max(0, x):x + w] = True
        return m
    img = Image.new("L", (W * SS, H * SS), 0)
    d = ImageDraw.Draw(img)
    if "rrect" in s:
        x, y, w, h = s["rrect"]
        d.rounded_rectangle([x * SS, y * SS, (x + w) * SS - 1, (y + h) * SS - 1],
                            radius=s.get("radius", 8) * SS, fill=255)
    elif "ellipse" in s:
        cx, cy, rx, ry = s["ellipse"]
        d.ellipse([(cx - rx) * SS, (cy - ry) * SS, (cx + rx) * SS, (cy + ry) * SS], fill=255)
    elif "poly" in s:
        d.polygon([(x * SS, y * SS) for x, y in s["poly"]], fill=255)
    elif "alpha_gt" in s:
        x, y, w, h = s["in"]
        m = np.zeros((H, W), bool)
        m[y:y + h, x:x + w] = orig[y:y + h, x:x + w, 3] > s["alpha_gt"]
        return m
    elif "maskfn" in s:
        # {"maskfn":"module:function", ...}: fn(orig, s) -> (H,W) bool, computed from
        # the ORIGINAL pixels (e.g. old lettering footprint, art to protect)
        mod, fn = s["maskfn"].split(":")
        return np.asarray(getattr(importlib.import_module(mod), fn)(orig, s), bool)
    elif "mask" in s:
        # colour-selected ORIGINAL pixels inside "in" (mx mask syntax), grown "grow" px
        # (typically "minus": art that touches the old letters, e.g. pink bursts)
        x, y, w, h = s["in"]
        m = np.zeros((H, W), bool)
        m[y:y + h, x:x + w] = mx.make_mask(orig[y:y + h, x:x + w], s["mask"], {})
        return mx.grow(m, s.get("grow", 0))
    elif "flood" in s:
        # connected region of NOT-outline pixels (lum > lum_gt, after filling the
        # letters: pixels darker than that inside the rect but not touching the
        # rect border are letters, not outline) containing the seed, inside "in",
        # eroded by "erode" px so the outline's AA ring is never touched
        x, y, w, h = s["in"]
        sub = orig[y:y + h, x:x + w]
        light = mx.lum(sub) > s.get("lum_gt", 120)
        dark_lab, _ = ndi.label(~light)
        border = set(np.unique(np.concatenate([dark_lab[0], dark_lab[-1], dark_lab[:, 0], dark_lab[:, -1]])))
        letters = (~light) & ~np.isin(dark_lab, list(border - {0}))
        ok = light | letters
        lab, _ = ndi.label(ok)
        sx, sy = s["flood"]
        reg = lab == lab[sy - y, sx - x]
        if s.get("erode"):
            reg = ndi.binary_erosion(reg, iterations=s["erode"])
        m = np.zeros((H, W), bool)
        m[y:y + h, x:x + w] = reg
        return m
    else:
        raise SystemExit("unknown allow shape %r" % s)
    # a pixel is allowed only when its whole area is inside the shape
    a = np.array(img).reshape(H, SS, W, SS).min(axis=(1, 3))
    return a > 0


def build_allow(tex, shape, orig, frags):
    shapes = list(tex.get("allow", []))
    for o in tex["ops"]:
        if o.get("op") == "include":
            shapes += frags[o["frag"]].get("allow", [])
    if not shapes:
        shapes = [{"rect": r} for r in all_rects(tex, frags)]
    pos = np.zeros(shape, bool)
    neg = np.zeros(shape, bool)
    for s in shapes:
        m = shape_mask(shape, s, orig)
        if s.get("minus"):
            neg |= m
        else:
            pos |= m
    res = pos & ~neg
    # "allow_add": shapes added AFTER the subtraction (e.g. a pill interior inside
    # an art area that was subtracted from the panel)
    for s in tex.get("allow_add", []):
        res |= shape_mask(shape, s, orig)
    return res


def all_rects(tex, frags):
    r = [list(x) for x in tex.get("rects", [])]
    for o in tex["ops"]:
        if o.get("op") == "include":
            r += [list(x) for x in frags[o["frag"]].get("rects", [])]
    return r


def op_erase(a, orig, o, colors, allow):
    H, W = allow.shape
    x, y, w, h = o["rect"]
    R = np.zeros((H, W), bool)
    R[y:y + h, x:x + w] = True
    lim = R & allow
    sub = a[y:y + h, x:x + w]
    m = np.zeros((H, W), bool)
    m[y:y + h, x:x + w] = mx.make_mask(sub, o.get("mask", "all"), colors)
    m &= lim
    if o.get("fill_holes"):
        m = ndi.binary_fill_holes(m) & lim
    hole = mx.grow(m, o.get("grow", 0)) & lim
    if not hole.any():
        return
    meth = o.get("method", "flat")
    if meth == "flat":
        a[hole] = mx.col(o["color"], colors)
    elif meth == "clear":
        a[hole] = (0, 0, 0, 0)
    elif meth in ("rows", "cols", "telea"):
        sx = dict(o, op="inpaint", mask="all")
        tmp = a.copy()
        # run the generic inpaint on the rect but with OUR hole as the mask
        sub = tmp[y:y + h, x:x + w]
        hm = hole[y:y + h, x:x + w]
        if meth in ("rows", "cols"):
            s = sub.astype(float)
            mm = hm
            if meth == "cols":
                s, mm = s.transpose(1, 0, 2), hm.T
            for j in range(s.shape[0]):
                if not mm[j].any():
                    continue
                good = np.nonzero(~mm[j])[0]
                if len(good) == 0:
                    continue
                for c in range(4):
                    s[j, :, c] = np.interp(np.arange(s.shape[1]), good, s[j, good, c])
            if meth == "cols":
                s = s.transpose(1, 0, 2)
            sub[:] = np.rint(s).astype(np.uint8)
        else:
            import cv2
            c = o.get("context", 8)
            X0, Y0, X1, Y1 = max(0, x - c), max(0, y - c), min(W, x + w + c), min(H, y + h + c)
            big = tmp[Y0:Y1, X0:X1].copy()
            mk = (hole[Y0:Y1, X0:X1]).astype(np.uint8) * 255
            rgb = cv2.inpaint(np.ascontiguousarray(big[..., :3]), mk, o.get("radius", 3), cv2.INPAINT_TELEA)
            big[..., :3] = rgb
            tmp[Y0:Y1, X0:X1] = big
        del sx
        a[hole] = tmp[hole]
    elif meth == "exemplar":
        dx, dy, dw, dh = o.get("donor_rect", [x - 16, y - 16, w + 32, h + 32])
        region = np.zeros((H, W), bool)
        region[max(0, dy):dy + dh, max(0, dx):dx + dw] = True
        region &= allow
        region |= hole
        if "donor" in o:
            dm = np.zeros((H, W), bool)
            dm[max(0, dy):dy + dh, max(0, dx):dx + dw] = mx.make_mask(
                a[max(0, dy):dy + dh, max(0, dx):dx + dw], o["donor"], colors)
        else:
            dm = ~m
        out = exemplar_inpaint(a, hole, region, P=o.get("P", 4), seed=o.get("seed", 1),
                               core=o.get("core", 1), donor=dm)
        a[hole] = out[hole]
    else:
        raise SystemExit("unknown erase method %r" % meth)


def run_ops(a, orig, ops, colors, allow, icons, frags, report, key):
    for o in ops:
        k = o["op"]
        if k == "include":
            run_ops(a, orig, frags[o["frag"]]["ops"], colors, allow, icons, frags, report, key)
            continue
        if k == "erase":
            op_erase(a, orig, o, colors, allow)
            continue
        if k == "hook":
            mod, fn = o["fn"].split(":")
            getattr(importlib.import_module(mod), fn)(a, orig, o, colors, allow)
            continue
        before = a.copy()
        oo = dict(o, _orig=orig, _icons=icons)
        if k == "text":
            mx.op_text(a, oo, colors, report)
        elif k == "lines":
            mx.op_lines(a, oo, colors, report)
        else:  # fill / clear / inpaint / copy / rrect via a 1-op generic render
            tex1 = {"key": key, "ops": [o], "rects": [[0, 0, a.shape[1], a.shape[0]]], "snap": False,
                    "icons": icons}
            tmp = "/dev/shm/_bc_%d.png" % os.getpid()
            Image.fromarray(a, "RGBA").save(tmp)
            _, out, rep = mx.render(tex1, tmp, colors)
            os.unlink(tmp)
            a[:] = out
            report += rep
        if k in ("text", "lines"):
            leak = (a != before).any(axis=2) & ~allow
            if leak.any():
                ys, xs = np.nonzero(leak)
                raise SystemExit("%s: %s %r leaks %d px outside allow, e.g. %s" % (
                    key, k, (o.get("text") or o.get("lines"))[:1], len(xs),
                    list(zip(xs.tolist(), ys.tolist()))[:6]))


def render(tex, src, colors, frags):
    orig = np.array(Image.open(src).convert("RGBA"))
    a = orig.copy()
    H, W = orig.shape[:2]
    allow = build_allow(tex, (H, W), orig, frags)
    rects = all_rects(tex, frags)
    R = np.zeros((H, W), bool)
    for x, y, w, h in rects:
        if x < 0 or y < 0 or x + w > W or y + h > H:
            raise SystemExit("%s: rect %r outside texture" % (tex["key"], (x, y, w, h)))
        R[y:y + h, x:x + w] = True
    allow &= R
    report = []
    run_ops(a, orig, tex["ops"], colors, allow, tex.get("icons", {}), frags, report, tex["key"])
    a[~allow] = orig[~allow]
    if tex.get("snap", True):
        mx.snap(a, orig, allow & (a != orig).any(axis=2))
    a[~allow] = orig[~allow]
    changed = (a != orig).any(axis=2)
    assert not (changed & ~allow).any()
    return orig, a, allow, rects, report


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--spec", action="append", required=True)
    ap.add_argument("--src-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--only", nargs="*")
    o = ap.parse_args()
    specs = [json.load(open(p)) for p in o.spec]
    frags, colors, texs = {}, {}, []
    for s in specs:
        frags.update(s.get("fragments", {}))
        colors.update({k: tuple(v) for k, v in s.get("colors", {}).items()})
        texs += s.get("textures", [])
    os.makedirs(o.out_dir, exist_ok=True)
    for tex in texs:
        if o.only and tex["key"] not in o.only:
            continue
        cl = dict(colors)
        cl.update({k: tuple(v) for k, v in tex.get("colors", {}).items()})
        orig, out, allow, rects, rep = render(tex, os.path.join(o.src_dir, tex.get("src", tex["key"]) + ".png"), cl, frags)
        Image.fromarray(out, "RGBA").save(os.path.join(o.out_dir, tex["key"] + ".png"))
        Image.fromarray((allow * 255).astype(np.uint8), "L").save(os.path.join(o.out_dir, tex["key"] + ".allow.png"))
        print("%s: %d px changed (allow %d px), 0 outside allow" % (
            tex["key"], int((out != orig).any(axis=2).sum()), int(allow.sum())))
        for r in rep:
            print("   ", r)
        print("    rects:", " ".join("--rect %d,%d,%d,%d" % tuple(r) for r in rects))


if __name__ == "__main__":
    sys.exit(main())
