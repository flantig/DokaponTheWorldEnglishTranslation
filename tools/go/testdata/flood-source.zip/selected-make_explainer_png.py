def col(c, colors):
    if isinstance(c, str):
        if c not in colors:
            raise SystemExit('unknown colour %r' % c)
        c = colors[c]
    c = list(c)
    if len(c) == 3:
        c.append(255)
    return tuple((int(v) for v in c))

def lum(a):
    return (a[..., 0].astype(np.int32) * 299 + a[..., 1].astype(np.int32) * 587 + a[..., 2].astype(np.int32) * 114) // 1000

def make_mask(sub, m, colors):
    h, w = sub.shape[:2]
    if m == 'all':
        return np.ones((h, w), bool)
    if isinstance(m, list):
        out = np.ones((h, w), bool)
        for mm in m:
            out &= make_mask(sub, mm, colors)
        return out
    out = np.ones((h, w), bool)
    L = lum(sub)
    for k, v in m.items():
        if k == 'lum_lt':
            out &= L < v
        elif k == 'lum_gt':
            out &= L > v
        elif k == 'alpha_gt':
            out &= sub[..., 3] > v
        elif k in ('sat_gt', 'sat_lt'):
            c = sub[..., :3].astype(np.int32)
            sat = c.max(axis=2) - c.min(axis=2)
            out &= sat > v if k == 'sat_gt' else sat < v
        elif k in ('near', 'not_near'):
            c = np.array(col(v, colors)[:3], np.int32)
            d = np.abs(sub[..., :3].astype(np.int32) - c).max(axis=2) <= m.get('tol', 0)
            out &= d if k == 'near' else ~d
        elif k in ('tol',):
            pass
        else:
            raise SystemExit('unknown mask key %r' % k)
    return out

def grow(mask, n):
    if n <= 0:
        return mask
    m = mask.copy()
    for _ in range(n):
        g = m.copy()
        g[1:] |= m[:-1]
        g[:-1] |= m[1:]
        g[:, 1:] |= m[:, :-1]
        g[:, :-1] |= m[:, 1:]
        m = g
    return m
