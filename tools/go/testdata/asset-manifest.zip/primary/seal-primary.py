from pathlib import Path
import ast, hashlib, json, re, sys
import numpy as np
import PIL
from PIL import Image

w = Path('/var/tmp/dokapon-asset-manifest-contract-9ycx5wzu')
imgs = w / 'pixels'
src = Path('../explainer_scan.py').read_text()
tree = ast.parse(src)
selected = [node for node in tree.body if
    isinstance(node, ast.FunctionDef) and node.name in ('tier', 'score', '_score_safe') or
    isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in ('MODEL', 'ICONS', 'HINT') for t in node.targets)]
module = ast.Module(body=selected, type_ignores=[])
canonical = ast.unparse(module) + '\n'
assert canonical == (w / 'primary-selected.py').read_text()
env = {'np': np, 'Image': Image, 're': re, 'ROOT': str(imgs)}
exec(compile(module, '<original-selected-AST>', 'exec'), env)

# Alternating colors give >=6 edges independently of the opacity threshold.
for name, num in [('opaque-half32', 32), ('opaque-half33', 33)]:
    a = np.zeros((16, 16, 4), np.uint8)
    for y in range(16):
        for x in range(16):
            rx, ry = x % 8, y % 8
            v = 0 if rx % 2 == 0 else 255
            opaque = ry < 4 or num == 33 and ry == 4 and rx == 0
            a[y, x] = [v, v, v, 255 if opaque else 0]
    (imgs / (name + '.rgba')).write_bytes(a.tobytes())
    Image.fromarray(a).save(imgs / (name + '.png'))

manual = {
    'uniform': [0, 0, 0, 1, 1, 0],
    'transparent-hidden': [0, 0, 0, 0, 0, 0],
    'alpha128': [0, 0, 0, 0, 0, 0], 'alpha129': [4, 1, 4, .5, 1, 0],
    'opaque-half32': [0, 0, 0, .5, .5, 0],
    'opaque-half33': [4, 1, 4, 17 / 33, 33 / 64, 0],
    'edge90': [0, 0, 0, .5, 1, 0], 'edge91': [4, 1, 4, .5, 1, 0],
    'dark90': [0, 0, 0, .5, 1, 0], 'dark89': [4, 1, 4, .5, 1, 0],
    'light150': [0, 0, 0, .5, 1, 0], 'light151': [4, 1, 4, .5, 1, 0],
    'dark3': [0, 0, 0, 61 / 64, 1, 0], 'dark4': [4, 1, 4, 60 / 64, 1, 0],
    'dark44': [4, 1, 4, 44 / 64, 1, 0], 'dark45': [0, 0, 0, 45 / 64, 1, 0],
    'light9': [0, 0, 0, 39 / 64, 1, 0], 'light10': [4, 1, 4, 38 / 64, 1, 0],
    'neighbors1': [0, 0, 1, .5, 1, 0], 'neighbors2': [0, 0, 2, .5, 1, 0],
    'neighbors3-linear': [1, 1 / 3, 3, .5, 1, 0],
    'neighbors3-L-opaque-denominator': [3, .75, 3, .375, 1, 0],
    'consecutive7': [5, 5 / 8, 7, 7 / 16, 1, 0],
    'consecutive8': [6, .75, 8, .5, 1, 1],
    'eight-with-gap': [4, 4 / 9, 8, 4 / 9, 1, 0],
    'clusters40': [40, 1, 40, .5, 1, 5],
    'flat-same-bucket': [0, 0, 0, 1, 1, 0],
    'flat-other-bucket': [0, 0, 0, .5, 1, 0],
}
cases = []
for p in sorted(imgs.glob('*.rgba')):
    name = p.stem
    a = np.array(Image.open(p.with_suffix('.png')))
    height, width = a.shape[:2]
    assert a.tobytes() == p.read_bytes()
    c = {'name': name, 'size': [width, height],
         'rgba_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
         'png_sha256': hashlib.sha256(p.with_suffix('.png').read_bytes()).hexdigest()}
    try:
        c['original_score'] = list(env['score'](name + '.png'))
        c['original_error'] = None
    except Exception as e:
        c['original_score'] = None
        c['original_error'] = {'type': type(e).__name__, 'message': str(e)}
    c['original_safe'] = list(env['_score_safe'](name + '.png')[1])
    c['new_contract_status'] = 'unavailable' if width < 8 or height < 8 or width % 8 or height % 8 else 'measured'
    c['new_contract_scores'] = c['original_score'] if c['new_contract_status'] == 'measured' else None
    if name in manual:
        assert c['original_score'] == manual[name], (name, c['original_score'], manual[name])
        c['independent_hand_derived_score'] = manual[name]
    if name.startswith('odd'):
        assert c['original_error']['type'] == 'IndexError' and c['original_safe'] == [-1, 0, 0, 0, 0, 0]
    if name.startswith('small'):
        assert c['original_score'] == [0, 0, 0]
    cases.append(c)
(imgs / 'invalid.png').write_bytes(b'not PNG')
invalid = {'name': 'invalid.png', 'original_safe': list(env['_score_safe']('invalid.png')[1]),
           'new_contract_status': 'decode_error', 'new_contract_scores': None}
(w / 'score-oracles.json').write_text(json.dumps({
    'method': 'Original AST-selected score/tier/_score_safe/regex only, no project import/main. All28 successful six-counter cases independently hand-derived. Opacity32/33 uses alternating dark/light columns to isolate opacity threshold.',
    'versions': {'Python': sys.version, 'Pillow': PIL.__version__, 'NumPy': np.__version__},
    'source_sha256': hashlib.sha256(src.encode()).hexdigest(),
    'selected_AST_sha256': hashlib.sha256(canonical.encode()).hexdigest(),
    'cases': cases, 'invalid_png': invalid}, indent=2) + '\n')

cmd = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'cmd_csv')
loop = next(node for node in ast.walk(cmd) if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == 'x' and isinstance(node.iter, ast.Name) and node.iter.id == 'man' and any(isinstance(stmt, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'reasons' for target in stmt.targets) for stmt in node.body))
flagif = next(node for node in loop.body if isinstance(node, ast.If) and isinstance(node.test, ast.Subscript))
flagcode = compile(ast.Module(body=[flagif], type_ignores=[]), '<original-flag-conditions>', 'exec')
(w / 'primary-flag-conditions.py').write_text(ast.unparse(flagif) + '\n')
vectors = [
    (r'BATTLE\PLAYER\body.txd', 'plain', True, [0, 0, 0, .5, 1, 0]),
    (r'battle\player\help.txd', 'plain', True, [6, .75, 8, .5, 1, 1]),
    (r'event\npc\body.txd', 'TITLE', True, [-1, 0, 0, 0, 0, 0]),
    (r'event\npc\body.txd', 'plain', True, [0, 0, 0, .5, 1, 1]),
    (r'textures\win_mon\wm_001.txd', 'plain', True, [0, 0, 0, .5, 1, 0]),
    (r'etc\textures\plain.txd', 'plain', True, [40, 1, 40, .3, 1, 0]),
    (r'etc\textures\help.txd', 'TITLE', True, [40, 1, 40, .3, 1, 1]),
    (r'etc\textures\plain.txd', 'plain', True, [39, 1, 40, .3, 1, 1]),
    (r'etc\textures\plain.txd', 'plain', True, [40, 1, 40, .299999, 1, 1]),
    (r'etc\textures\help.txd', 'plain', False, [40, 1, 40, .5, 1, 1]),
    (r'field\map\land.txd', 'plain', True, None),
    (r'event\bg\plain.txd', 'plain', True, None),
    (r'battle\textures\monster\x.txd', 'plain', True, [0, 0, 0, 0, 0, 0]),
    (r'battle/player/x.txd', 'plain', True, None),
    (r'textures\WİN_MON\x.txd', 'plain', True, None),
    (r'textures\wın_mon\x.txd', 'plain', True, None),
    (r'event\NPC\x.txd', 'plain', True, None),
    (r'event\İnpc\x.txd', 'plain', True, None),
    ('plain', 'TİTLE', True, None), ('plain', 'tıtle', True, None),
    ('plain', 'ſale', True, None), ('plain', 'Kojityu', True, None),
    ('plain', 'prıze', True, None), ('plain', 'TİTLE', False, None),
]
flags = []
for entry, tex, png, d in vectors:
    x = {'entry': entry, 'tex': tex, 'png': 'selected.png' if png else ''}
    t = env['tier'](entry)
    local = dict(env, x=x, t=t, d=d, reasons=[])
    exec(flagcode, local)
    flags.append({'entry': entry, 'texture': tex, 'decoded_png': png, 'score_input': d,
                  'lowercase_entry': entry.lower(), 'tier': t,
                  'hint': bool(env['HINT'].search(entry + ' ' + tex)),
                  'reasons': local['reasons'], 'flagged': int(bool(local['reasons']))})
(w / 'flag-tier-oracles.json').write_text(json.dumps({
    'method': 'Original tier and cmd_csv nested flag IF AST without writer/loader. Nullable scores represent deliberate new unavailable domain, not original six-counter success. No pixels means no reasons.',
    'cases': flags}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'work': str(w), 'score_cases': len(cases), 'hand_checked': len(manual),
                  'flags': len(flags), 'scores_SHA': hashlib.sha256((w / 'score-oracles.json').read_bytes()).hexdigest(),
                  'flags_SHA': hashlib.sha256((w / 'flag-tier-oracles.json').read_bytes()).hexdigest()}, indent=2))
