MODEL = re.compile('^(battle\\\\(player|monster|bg|weapon|shield|textures\\\\(player|monster))|field\\\\(fp|map)|event\\\\(npc|evtkao|bg|race\\\\rm))')
ICONS = re.compile('^textures\\\\win_(pl|wep|mon)\\\\')
HINT = re.compile('help|tut|rule|setumei|guide|illust|title|logo|news|kojityu|mini_|card_|casino|prize|sale|button|panel|ready|start|gameset|survive|wanted|jikai|food_t|f_title|op_p|win_', re.I)

def tier(entry):
    e = entry.lower()
    if MODEL.match(e):
        return 'model'
    if ICONS.match(e):
        return 'icons'
    return 'ui'

def score(path):
    a = np.array(Image.open(ROOT + '/' + path).convert('RGBA'), dtype=np.int32)
    h, w = a.shape[:2]
    lum = (a[..., 0] * 299 + a[..., 1] * 587 + a[..., 2] * 114) // 1000
    op = a[..., 3] > 128
    H = h // 8 * 8
    W = w // 8 * 8
    if H == 0 or W == 0:
        return (0, 0, 0)
    lum = lum[:H, :W]
    op = op[:H, :W]
    e = (np.abs(np.diff(lum, axis=1)) > 90) & op[:, 1:] & op[:, :-1]
    e = np.pad(e, ((0, 0), (0, 1)))
    et = e.reshape(H // 8, 8, W // 8, 8).sum(axis=(1, 3))
    ot = op.reshape(H // 8, 8, W // 8, 8).mean(axis=(1, 3))
    dk = ((lum < 90) & op).reshape(H // 8, 8, W // 8, 8).mean(axis=(1, 3))
    lt = ((lum > 150) & op).reshape(H // 8, 8, W // 8, 8).mean(axis=(1, 3))
    g = (et >= 6) & (dk > 0.05) & (dk < 0.7) & (lt > 0.15) & (ot > 0.5)
    from numpy.lib.stride_tricks import sliding_window_view
    gp = np.pad(g, 1).astype(int)
    nb = sliding_window_view(gp, (3, 3)).sum(axis=(2, 3))
    cl = g & (nb >= 3)
    lines = 0
    for row in g:
        run = best = 0
        for v in row:
            run = run + 1 if v else 0
            best = max(best, run)
        if best >= 8:
            lines += 1
    px = a[..., :3][op]
    flat = 0.0
    if len(px):
        key = px[:, 0] // 8 * 1024 + px[:, 1] // 8 * 32 + px[:, 2] // 8
        flat = float(np.bincount(key).max() / len(px))
    return (int(cl.sum()), float(cl.sum() / max(1, (ot > 0.5).sum())), int(g.sum()), flat, float(op.mean()), lines)

def _score_safe(p):
    try:
        return (p, score(p))
    except Exception:
        return (p, (-1, 0, 0, 0, 0, 0))
