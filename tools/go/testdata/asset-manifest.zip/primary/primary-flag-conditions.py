if x['png']:
    if t in ('ui', 'icons'):
        reasons.append('ui-folder')
    if d and d[5] >= 1 and (t == 'model'):
        reasons.append('detector-text-lines')
    if d and d[0] >= 40 and (d[3] >= 0.3) and (t == 'ui'):
        reasons.append('detector-glyphs')
    if HINT.search(x['entry'] + ' ' + x['tex']):
        reasons.append('name-hint')
