import pathlib,json,hashlib,sys,gzip
sys.setrecursionlimit(10000);r=pathlib.Path(__file__).parent
p=r/'syntax-literals.json';j=json.loads(p.read_text())
for c in j['cases']:
 c.pop('manual_initial_check',None)
 if c['id']=='scalar':c['refuse_at_bound_minus_one']=None;c['zero_budget_semantics']='0 may mean optional budget disabled; no scalar budget0 refusal asserted'
for id,raw,pretty in [('raw-escaped-unicode-slash','{"a":"\\u0041\\/"}','{\n  "a": "\\u0041\\/"\n}'),('raw-number-spelling','{"a":1e+000}','{\n  "a": 1e+000\n}')]:
 j['cases'].append({'id':id,'raw_utf8':raw,'raw_bytes':len(raw.encode()),'upper_bound_bytes':len(raw.encode())+5,'actual_pretty_utf8':pretty,'actual_pretty_bytes':len(pretty.encode()),'accept_at_bound':len(raw.encode())+5,'refuse_at_bound_minus_one':len(raw.encode())+4,'manual_equation':'One object open3+colon1+close1; preserved raw scalar spelling, no parse/re-encode normalization.'})
j['malformed_refusals']=[{'raw_utf8':x,'expected':'invalid JSON before accepted budget result'} for x in ['[','{"a":}','{"a":"\\q"}','{"a":"unterminated}','[0,]']]
p.write_text(json.dumps(j,indent=2)+'\n')
base=json.loads((r/'rows-34/source.json').read_text());rows=json.loads((r/'rows-34/batch.json').read_text());plain=dict(rows[0]);plain.pop('opaque');plain['id']='0x1000'
cases=[]
for id,source_doc,batch,disposition in [('inherited-34-deep-plus-new',dict(base,entries=rows),[plain],'refuse_before_indent_no_report_no_output'),('inherited-34-deep-all-present',dict(base,entries=rows),rows,'accept_exact_source_byte_noop')]:
 d=r/id;d.mkdir();source=(json.dumps(source_doc,ensure_ascii=False,separators=(',',':'))+'\n').encode();raw=json.dumps(batch,ensure_ascii=False,separators=(',',':')).encode();glyph=(r/'rows-1/glyph.json').read_bytes()
 for n,b in [('source.json',source),('batch.json',raw),('glyph.json',glyph)]: (d/n).write_bytes(b)
 profile=json.loads((r/'rows-1/profile.json').read_text());profile['source_size']=len(source);profile['source_sha256']=hashlib.sha256(source).hexdigest();profile['registry_inputs']['batch'].update(size=len(raw),sha256=hashlib.sha256(raw).hexdigest());(d/'profile.json').write_text(json.dumps(profile,indent=2)+'\n')
 result={'id':id,'source_bytes':len(source),'source_sha256':hashlib.sha256(source).hexdigest(),'batch_bytes':len(raw),'source_has_inherited_deep_opaque_metadata':True,'expected_new_budget_disposition':disposition}
 if 'noop' in disposition:result.update(expected_output_bytes=len(source),expected_output_sha256=hashlib.sha256(source).hexdigest(),whole_expected_output_blob=id+'/source.json',qualification='All rows still undergo admission. Since no additions occur, no indentation/allocation or new budget rejection; source bytes/date retained.')
 else:
  final=dict(source_doc);final['entries']=rows+[plain];final['last_updated']='2026-11-05'
  # Independent standard-library formatting, not candidate. Hash in small per-row fragments.
  h=hashlib.sha256();size=0
  frags=[b'{\n  "entries": [\n']
  for i,row in enumerate(final['entries']):
   if i:frags.append(b',\n')
   frags.append(b'\n'.join(b'    '+line for line in json.dumps(row,sort_keys=True,ensure_ascii=False,indent=2).encode().split(b'\n')))
  frags.append(b'\n  ],\n  "last_updated": "2026-11-05",\n  "schema_version": 1\n}\n')
  for f in frags:h.update(f);size+=len(f)
  result.update(actual_pretty_bytes_without_guard=size,actual_pretty_sha256_without_guard=h.hexdigest(),qualification='The34deep records are inherited source entries, not new batch metadata. Final document budgeting must include them.')
 cases.append(result)
(r/'inherited-boundaries.json').write_text(json.dumps({'cases':cases,'old_modes':'Absent registry_import retains prior behavior; no global serializer/refusal change asserted.'},indent=2)+'\n')
print(json.dumps(cases,indent=2))
