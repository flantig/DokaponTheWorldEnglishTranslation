import pathlib,json,hashlib,sys,gzip
sys.setrecursionlimit(10000)
r=pathlib.Path(__file__).parent
cap=64<<20
row0={'id':'0x20','jp':'A','en':'A','chapter':'sample','character':'narrator','tier':'draft','status':'drafted','source_pool':'synthetic','ref_type':'unknown','discovered_by':'registry-import-example'}
node=0
for i in range(1000):node=[node]
row0['opaque']=node
source=b'{\n  "schema_version": 1,\n  "last_updated": "2026-11-05",\n  "entries": []\n}\n'
glyph=b'{"1":"A"}'
syntax=[('scalar',b'0',1),('empty-array',b'[]',6),('empty-object',b'{}',6),('singleton',b'[0]',7),('nested-empty',b'{"a":[]}',21),('colon-comma',b'{"a":1,"b":2}',24),('quoted-punctuation',b'{"a":"[{},:]"}',18),('escaped-quote-backslash',b'{"a":"\\\"[\\\\]"}',None)]
# Bound defined by the frozen proposal, independent of any candidate code.
# Strings contribute raw bytes only, including escape spelling. Structural opens
# use depth after opening, closes after closing; commas current depth, colons1.
results=[]
for id,raw,manual in syntax:
 json.loads(raw);depth=0;inside=False;escape=False;bound=len(raw);events=[]
 for ch in raw:
  if inside:
   if escape:escape=False
   elif ch==92:escape=True
   elif ch==34:inside=False
   continue
  if ch==34:inside=True;continue
  if ch in (123,91):depth+=1;extra=1+2*depth
  elif ch in (125,93):depth-=1;extra=1+2*depth
  elif ch==44:extra=1+2*depth
  elif ch==58:extra=1
  else:continue
  bound+=extra;events.append([chr(ch),depth,extra])
 pretty=json.dumps(json.loads(raw),ensure_ascii=False,indent=2,separators=(',',': ')).encode()
 results.append({'id':id,'raw_utf8':raw.decode(),'raw_bytes':len(raw),'upper_bound_bytes':bound,'actual_pretty_bytes':len(pretty),'actual_pretty_utf8':pretty.decode(),'structural_events':events,'accept_at_bound':bound,'refuse_at_bound_minus_one':bound-1,'manual_initial_check':manual})
(r/'syntax-literals.json').write_text(json.dumps({'definition':'raw bytes plus (1+2*depth) per structural open after increment/close after decrement/comma, plus1 per colon; strings ignored; empty-container overcount deliberate','without_encoder_terminal_newline':True,'cases':results},indent=2)+'\n')
vectors=[]
for count in (1,33,34):
 d=r/('rows-%d'%count);d.mkdir();rows=[]
 for i in range(count):
  row=dict(row0);row['id']=hex(0x20+i);rows.append(row)
 batch=json.dumps(rows,separators=(',',':'),ensure_ascii=False).encode();(d/'batch.json').write_bytes(batch);(d/'source.json').write_bytes(source);(d/'glyph.json').write_bytes(glyph)
 profile={'operation':'registry_add','source_size':len(source),'source_sha256':hashlib.sha256(source).hexdigest(),'evidence':'Independent pre-edit JSON indentation amplification cutset','updated':'2026-11-05','registry_import':{'policy':'json_kinds','batches':['batch'],'glyphmap':'glyph'},'registry_inputs':{'batch':{'path':'batch.json','size':len(batch),'sha256':hashlib.sha256(batch).hexdigest()},'glyph':{'path':'glyph.json','size':len(glyph),'sha256':hashlib.sha256(glyph).hexdigest()}}}
 (d/'profile.json').write_text(json.dumps(profile,indent=2)+'\n')
 compact=json.dumps({'entries':rows,'last_updated':'2026-11-05','schema_version':1},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()+b'\n'
 depth=0;inside=False;escape=False;bound=len(compact)
 for ch in compact:
  if inside:
   if escape:escape=False
   elif ch==92:escape=True
   elif ch==34:inside=False
   continue
  if ch==34:inside=True
  elif ch in (123,91):depth+=1;bound+=1+2*depth
  elif ch in (125,93):depth-=1;bound+=1+2*depth
  elif ch==44:bound+=1+2*depth
  elif ch==58:bound+=1
 h=hashlib.sha256();size=0;one=bytearray()
 fragments=[b'{\n  "entries": [\n']
 for i,row in enumerate(rows):
  if i:fragments.append(b',\n')
  fragments.append(b'\n'.join(b'    '+line for line in json.dumps(row,sort_keys=True,ensure_ascii=False,indent=2).encode().split(b'\n')))
 fragments.append(b'\n  ],\n  "last_updated": "2026-11-05",\n  "schema_version": 1\n}\n')
 for fragment in fragments:
  size+=len(fragment);h.update(fragment)
  if count==1:one.extend(fragment)
 if count==1:(d/'expected-output.json.gz').write_bytes(gzip.compress(one,mtime=0))
 vectors.append({'id':'rows-%d'%count,'records':count,'depth_per_opaque_array':1000,'batch_bytes':len(batch),'compact_final_document_bytes':len(compact),'proposed_upper_bound_final_bytes':bound,'actual_expected_pretty_output_bytes':size,'expected_pretty_output_sha256':h.hexdigest(),'expected_new_budget_disposition':'accept' if bound<=cap else 'refuse_before_indent_no_report_no_output','whole_expected_output_blob':'rows-1/expected-output.json.gz' if count==1 else None,'formula':'Stream standard two-space pretty row templates with4-space row prefix into sorted outer entries,last_updated,schema_version; SHA computed without candidate output.'})
 del fragments
(r/'deep-vectors.json').write_text(json.dumps({'cap':cap,'expectations_frozen_before_candidate_guard':True,'vectors':vectors},indent=2)+'\n')
print(json.dumps(vectors,indent=2))
