import ast, pathlib, json, struct, re, types, hashlib, datetime, collections, sys
out=pathlib.Path(__file__).parent;root=pathlib.Path('/home/franklinl/Documents/Dokapon World Mod/tools/go');(out/'sources').mkdir(exist_ok=True);(out/'extracted').mkdir(exist_ok=True);(out/'cases').mkdir(exist_ok=True)
gm={'0':' ','1':'A','2':'B','3':'C','4':'J'};(out/'extracted/glyphmap.json').write_text(json.dumps(gm,indent=2)+'\n')
ns={'json':json,'struct':struct,'re':re,'Path':pathlib.Path,'sys':sys,'ROOT':out};ds=ns.copy();selected={}
for rel,space in [('../dialog_codec.py',ds),('../text_encoder.py',ns)]:
 text=(root/rel).read_text();(out/'sources'/pathlib.Path(rel).name).write_text(text);tree=ast.parse(text);nodes=[];lines=text.splitlines(keepends=True)
 for n in tree.body:
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
   assert not n.decorator_list;nodes.append(n);selected[rel+'::'+n.name]={'lines':[n.lineno,n.end_lineno],'sha256':hashlib.sha256(''.join(lines[n.lineno-1:n.end_lineno]).encode()).hexdigest()}
  elif isinstance(n,ast.Assign):
   try:ast.literal_eval(n.value);nodes.append(n)
   except (ValueError,TypeError):
    if isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='re' and n.value.func.attr=='compile':nodes.append(n)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),rel,'exec'),space);space['ROOT']=out
 if space is ds:ns['dc']=types.SimpleNamespace(**ds)
rev={v:int(k) for k,v in gm.items()};H=0x2800;S=0x3998;P=0x1000;E=0xf800

import copy,csv,io
base=pathlib.Path('/var/tmp/dokapon-reconciliation-audit-packaging-rthu09zx');original=base/'examples/reconciliation-audit';data=out/'inputs';data.mkdir()
profile=json.loads((original/'profile.json').read_text());registry=json.loads((original/'registry.json').read_text());oldoracle=json.loads((base/'testdata/reconciliation-audit.json').read_text());oracle={'rows':copy.deepcopy(oldoracle['rows']),'bindings':copy.deepcopy(oldoracle['bindings']),'refusals':[]};reference=bytearray((original/'reference.elf').read_bytes());observed=bytearray((original/'observed.elf').read_bytes());delta=0xfff00
# Three source page pointers may share one literal metrics array; no native art/font claim.
assert not any(observed[0xa00:0x1000]);assert not any(observed[0x600:0x680]);assert not any(reference[0x600:0x680]);assert not any(observed[0x240:0x248])
for i in range(3):struct.pack_into('<I',observed,0xf40+4*i,delta+0xa00)
observed[0xa03:0xa06]=bytes([9,1,0]);observed[0xa06:0xa09]=bytes([0,25,0]);struct.pack_into('<H',observed,0xf50,27)
spaces={}
for off in range(0xf60,0xf80,4):struct.pack_into('<I',observed,off,0x3c024160);spaces[hex(delta+off)]='0x3c024160'
font={'font_table_vma':hex(delta+0xf40),'unfloored_glyph_vma':hex(delta+0xf50),'unfloored_glyph':'0x1b','space_words':spaces}
# Original page projection is executed unchanged and remains distinct from fit pen lines.
textsource=(root/'../rework/new_tool/reports/text.py').read_text();tree=ast.parse(textsource);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='rendered_pages');pagespace={};exec(compile(ast.Module(body=[node],type_ignores=[]),'selected-original-rendered_pages','exec'),pagespace);(out/'sources/reports-text.py').write_text(textsource)
newfacts=[]
for i,(rid,name,en) in enumerate([('0x100500','missing-END','A'),('0x100540','HDR-five-lines','A|A|A|A|A')]):
 start=0x600+0x40*i;siteoff=0x240+4*i;target=delta+start;source=struct.pack('<3H',0x2800,4,0xf800);canonical=ns['encode_entry_from_elf'](en,0xfff80,source,rev,max_chars=1000,max_lines=16);actual=struct.pack('<2H',0x2800,1) if i==0 else canonical
 reference[start:start+len(source)]=source;observed[start:start+len(actual)]=actual;struct.pack_into('<I',observed,siteoff,target)
 review={'action':'allow','reason':'Independent declared workflow fixture; no native fit or mutation authority'}
 registry['entries'].append({'id':rid,'jp':'J','en':en,'status':'drafted','patch_ref':profile['observed_family'],'ref_type':'pointer_array','ref_sites':[{'pointer_vma':hex(delta+siteoff)}],'note':'Literal workflow; human wording preserved'})
 profile['entries'][rid]={'reference':{'start':hex(start),'end':hex(start+len(source))},'observed':{'start':hex(start),'end':hex(start+len(actual))},'decoder':'narrative','canonical':{'wrap':'none'},'review':review}
 sides={};raws={};decoder_error=None
 for label,raw,begin in [('reference',source,start),('observed',actual,start),('canonical',canonical,0)]:
  raws[label]=raw;side={'span':{'start':hex(begin),'end':hex(begin+len(raw))},'span_sha256':hashlib.sha256(raw).hexdigest(),'consumed_bytes':None,'trailing_bytes':None}
  try:ts=ds['decode_structured'](raw,0,require_hdr=False)
  except Exception as ex:
   assert label=='observed' and i==0;side['error']='unsupported';decoder_error=str(ex)
  else:
   n=ts[-1]['off']+2;wt=[{'Kind':t['kind'],'Word':t['word'],'Offset':t['off'],'Payload':None} for t in ts];gw=[t['word'] for t in ts if t['kind']=='glyph'];side.update({'consumed_bytes':n,'trailing_bytes':len(raw)-n,'tokens':wt,'stream_sha256':hashlib.sha256(raw[:n]).hexdigest(),'glyph_words':gw,'glyph_text':''.join(' ' if t['kind']=='space' else gm[str(t['word'])] for t in ts if t['kind'] in ['glyph','space']),'argument_words':[t['word'] for t in ts if t['kind'] in ['icon','param8','rawarg']],'opaque_payloads':[]})
  sides[label]=side
 comparisons={}
 for label,left in [('comparison',sides['reference']),('canonical_comparison',sides['canonical'])]:
  right=sides['observed']
  if 'error' in right:comparisons[label]=None;continue
  lc=[t for t in left['tokens'] if t['Kind'] not in ['glyph','space']];rc=[t for t in right['tokens'] if t['Kind'] not in ['glyph','space']]
  comparisons[label]={'stream_bytes_equal':left['stream_sha256']==right['stream_sha256'],'glyph_words_equal':left['glyph_words']==right['glyph_words'],'glyph_text_equal':left['glyph_text']==right['glyph_text'],'control_tokens_equal':lc==rc,'control_sequence_equal':[(t['Kind'],t['Word']) for t in lc]==[(t['Kind'],t['Word']) for t in rc],'argument_words_equal':left['argument_words']==right['argument_words'],'opaque_payloads_equal':True}
 recon={'current_status':'drafted','review':review,'status':'held' if i==0 else 'proposed','reasons':['canonical_unknown','trailing_bytes'] if i==0 else []}
 if i==1:recon['proposed_machine_fields']={'status':'patched','landing_vma':hex(target)}
 first=next((j for j in range(max(len(source),len(actual))) if j>=len(source) or j>=len(actual) or source[j]!=actual[j]),None)
 row={'registry_id':rid,'decoder':'narrative','status':'decode_failed' if i==0 else 'compared','span_bytes_equal':source==actual,'first_span_byte_difference':first,**comparisons,**sides,'reconciliation':recon};oracle['rows'].append(row)
 oracle['bindings'].append({'id':rid,'target':target,'site_words':[[delta+siteoff,target]],'site_count':1,'distinct_targets_source_order':[target],'all_sites_valid':True,'divergent':False,'observed_mapping':[{'storage':'file_backed','program_header':0,'file_range':[start,start+len(actual)],'vma_range':[target,target+len(actual)]}]})
 pagefacts=None
 if i==1:
  pages=pagespace['rendered_pages'](ds['decode_structured'](actual,0,require_hdr=False));assert pages==[[1,1,1,1,1]];pagefacts={'original_rendered_pages':pages,'has_HDR':True,'declared_max_lines':2,'over_capacity':True,'headerless_advisory':False}
 newfacts.append({'id':rid,'case':name,'source_hex':source.hex(),'canonical_hex':canonical.hex(),'actual_hex':actual.hex(),'original_decoder_error':decoder_error,'structural':pagefacts,'source_helper_execution':'Original selected encode_entry_from_elf/decode_structured/rendered_pages; no original main or module import'})
registry['entries'].append({'id':'0x100580','jp':'J','en':'','status':'zone_pending','patch_ref':'outside-selected-workflow','source_pool':'unselected','chapter':'outside','tier':'2','character':'','event':''})
registry['entries'].sort(key=lambda r:int(r['id'],16));oracle['rows'].sort(key=lambda r:int(r['registry_id'],16));oracle['bindings'].sort(key=lambda r:int(r['id'],16))
for name,raw in [('reference.elf',reference),('observed.elf',observed),('glyphmap.json',(original/'glyphmap.json').read_bytes())]:(data/name).write_bytes(raw)
(data/'registry.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n')
for role in profile['sources']:
 raw=(data/profile['sources'][role]['path']).read_bytes();profile['sources'][role]['size']=len(raw);profile['sources'][role]['sha256']=hashlib.sha256(raw).hexdigest()
profile['evidence']='Independent same-identity composed audit/fit/export/status input pilot; synthetic font pen advances and declared limits only. No native geometry, source mutation, registry publication, liveness or credit claim.'
(data/'audit-profile.json').write_text(json.dumps(profile,indent=2)+'\n')
fit={'source_sha256':profile['sources']['observed']['sha256'],'source_size':4096,'glyphmap_sha256':profile['sources']['glyphmap']['sha256'],'elf_vma_delta':hex(delta),'font':font,'boxes':{'literal-two-line':{'max_width':50,'max_lines':2,'allow_pages':False,'evidence':'Synthetic penbudget50/tworows. Not native calibrated menu/dialog geometry; authored EN only, not installed source-context stream.'}},'entries':{id:{'box':'literal-two-line'} for id in profile['entries']}}
(data/'fit-profile.json').write_text(json.dumps(fit,indent=2)+'\n')
columns=['id','status','en','landing_vma'];export={'operation':'registry_export','source_size':profile['sources']['registry']['size'],'source_sha256':profile['sources']['registry']['sha256'],'evidence':'Same pinned registry plan projection; no installed success count.','registry_columns':columns};(data/'csv-profile.json').write_text(json.dumps(export,indent=2)+'\n')
output=io.StringIO(newline='');writer=csv.writer(output,lineterminator='\r\n');writer.writerow(columns)
for r in registry['entries']:writer.writerow([r.get(c) or '' for c in columns])
(out/'expected.csv').write_bytes(output.getvalue().encode())
glossary={'schema_version':1,'entries':[{'en':'A','provenance':'official'},{'en':'B','provenance':'authored'}],'todos':['Resolve literal workflow attention']};flow=[{'vma':'0x100300'},{'vma':'0X00100300'},{'vma':'0x100300'}]
(data/'glossary.json').write_text(json.dumps(glossary,indent=2)+'\n');(data/'flow.json').write_text(json.dumps(flow,indent=2)+'\n');(data/'status.md.tmpl').write_bytes((root/'recipes/reports/registry-status.md.tmpl').read_bytes());status={'operation':'registry_status','source_size':profile['sources']['registry']['size'],'source_sha256':profile['sources']['registry']['sha256'],'evidence':'Same registry plan with separately pinned glossary/flow/template; no installed status inference.','updated':'2026-10-21','registry_columns':['status','source_pool','chapter','tier'],'registry_inputs':{}}
for role,name in [('glossary','glossary.json'),('flow','flow.json'),('template','status.md.tmpl')]:
 raw=(data/name).read_bytes();status['registry_inputs'][role]={'path':name,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(data/'status-profile.json').write_text(json.dumps(status,indent=2)+'\n')
fitfacts=[]
for r in registry['entries']:
 if r['id'] not in fit['entries']:continue
 en=r['en']
 if '{{' in en:raw=struct.pack('<4H',1,0x7000,2,0xf800);result={'status':'unsupported','bytes':8,'encoded_hex':raw.hex(),'encoded_sha256':hashlib.sha256(raw).hexdigest(),'max_line_width':0,'max_lines_per_page':0,'reason_fact':'unbounded numeric substitution requires explicit NumericBounds; no width proof'}
 else:
  words=[]
  for c in en:words.append(0x800 if c=='|' else rev[c])
  words.append(0xf800);raw=struct.pack('<'+'H'*len(words),*words);linewords=en.split('|');widths=[sum({0:14,1:13,2:28,3:22,4:22}[rev[c]] for c in line) for line in linewords];result={'status':'overflow' if len(widths)>2 else 'within_profile','bytes':len(raw),'encoded_hex':raw.hex(),'encoded_sha256':hashlib.sha256(raw).hexdigest(),'max_line_width':max(widths),'max_lines_per_page':len(widths),'line_widths_by_page':[widths]}
 auditrow=next(x for x in oracle['rows'] if x['registry_id']==r['id']);result.update({'registry_id':r['id'],'english':en,'canonical_encoded_SHA_equal':result['encoded_sha256']==auditrow['canonical']['stream_sha256'],'qualification':'Manual literal encoder/metric equations for authored EN; exact audit bytehash differs due HDR. Not installed stream fit.'});fitfacts.append(result)
# Strictly preserve every old eight row/token/factor/binding expectation.
for oldrow in oldoracle['rows']:assert next(r for r in oracle['rows'] if r['registry_id']==oldrow['registry_id'])==oldrow
for oldbinding in oldoracle['bindings']:assert next(r for r in oracle['bindings'] if r['id']==oldbinding['id'])==oldbinding
counts=collections.Counter(r['reconciliation']['status'] for r in oracle['rows']);assert dict(counts)=={'proposed':3,'held':6,'unchanged':1};assert len(registry['entries'])==11 and len(profile['entries'])==10
facts={'chronology':'Independent source/data expectations frozen BEFORE any root CLI on these NEW combined inputs; pointer/inline implementations already exist. No Go or candidate output accessed.','source_identity_links':{'audit_observed_equal_fit_source':profile['sources']['observed'],'audit_registry_equal_fit_registry_equal_status_and_csv_source':profile['sources']['registry'],'audit_glyph_equal_fit_glyph':profile['sources']['glyphmap'],'reference_separate':profile['sources']['reference']},'coverage':{'registry_entries':11,'selected_IDs':10,'unselected_IDs':['0x100580'],'processed_rows':10,'observed_decode_known':9,'observed_decode_unknown':1,'canonical_generation_known':10,'canonical_observed_comparison_known':9,'proposed':3,'held':6,'unchanged':1,'all_declared_sites':11,'all_selected_windows_bound':10,'fit_within_profile':8,'fit_overflow':1,'fit_unsupported':1,'status_plan_counts':{'drafted':8,'zone_pending':1,'patched':1,'null':1},'recorded_patched_not_installed_success':True},'font_facts':{'unused_metrics_file_range':[2560,3883],'page_pointer_table_file':3904,'page_pointers':[delta+2560]*3,'exception_file':3920,'exception_glyph':27,'space_word_files':list(range(3936,3968,4)),'space_word':'0x3c024160','advances':{'0':14,'1':13,'2':28,'3':22,'4':22},'equations':'advance=max(22,left+ink+3)-left except glyph27; SPACE observed eightLUI14. Threepages share literal metric table. No real fontmask/native geometry.'},'new_original_helper_cases':newfacts,'fit_rows':fitfacts,'status_expected_facts':{'registry_entries':11,'status_order':['drafted','zone_pending','patched',None],'status_counts':[8,1,1,1],'unknown_statuses':[{'value':None,'count':1,'display':'*null*'}],'source_pool':[{'value':'unknown','count':10},{'value':'unselected','count':1}],'chapter':[{'value':'outside','count':1},{'value':'unknown','count':10}],'tier':[{'value':'2','count':1},{'value':'unknown','count':10}],'empty_en_ids':['0x100580'],'missing_tag_ids':[r['id'] for r in registry['entries']],'flow_steps':3,'flow_unique_exact_VMA_spellings':2,'glossary_schema':1,'glossary_entries':2,'glossary_provenance':{'official':1,'authored':1},'glossary_open_todos':1,'generated':'2026-10-21'},'attention':{'missing_END':'original/reference valid, canonical generated, observed semanticunknown; rawspanhash/equality remain known.','HDR_5lines':'exact canonical content can legitimately propose bookkeeping while declared two-row fit overflows; not approval.','ICON':'authored PARAMnotation retained; fit unknown without numeric bounds.','patched':'unchanged only status promotion; landing metadata not reconciled.','fit_hashes':'Every authored-fit hash differs from canonical source-aware bytes because HDR retained by audit; no installed fit claim.'},'join_refusal_equations':[{'name':'registry-drift','actual_registry_SHA':profile['sources']['registry']['sha256'],'foreign_registry_SHA':'0'*64,'join_allowed':False},{'name':'same_ID_not_complete_coverage','selected':10,'registry':11,'unselected':1,'claim_all_installed_success_allowed':False}], 'limits':'Independent scalar/literal/source equations and original selected helpers only; no native GUI/rendering/gameplay/canonicalregistry authority. No production join/schema/function created.'}
(out/'expected-workflow.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n');(out/'expected-audit.json').write_text(json.dumps(oracle,ensure_ascii=False,indent=2)+'\n')
for role,pin in profile['sources'].items():assert hashlib.sha256((data/pin['path']).read_bytes()).hexdigest()==pin['sha256']
assert all(not r['canonical_encoded_SHA_equal'] for r in fitfacts);assert len(fitfacts)==10
(out/'verification.json').write_text(json.dumps({'outcome':'PASS','original8rows_and_bindings_unchanged':True,'sourcepins_verified':True,'source_metrics_disjoint_windows_sites':True,'row_counts':dict(counts),'Go_execution':False},indent=2)+'\n')
report={'schema_version':1,'status':'SOURCE_DATA_ONLY_COMPOSED_WORKFLOW_INPUTS_NO_APPROVAL_OR_CREDIT','directory':str(out),'chronology':facts['chronology'],'finding':'Existing four tools can share source/registry/glyph identities and explicit coverage while retaining separate authored fit versus installed byte facts. Inputs and independent expectations ready for root CLI verification. No new function, generic join or handler needed.','coverage':facts['coverage'],'required_composition_checks':['Run audit profile on four pinned sources; compare exact rows/bindings with expected-audit.json.','Run fit with source=inputs/observed.elf registry=inputs/registry.json glyphmap=inputs/glyphmap.json; compare expected-workflow fit rows, especially unsupportedICON/HDRfive authored lines.','Run CSV projection on same registry with csv-profile; compare complete expected.csv bytes.','Run status on same registry with status-profile; compare scalar facts and pinned template output scope.','Verify all identities agree and report selected10/unselected1; source-less or registry-drift join must not claim installed success.'],'scope_limits':facts['limits'],'original_source_definitions':selected,'pack_manifest':'manifest.json'}
(out/'contract.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');live=root/'analysis/joined-workflow-input-contract.json';assert not live.exists();live.write_bytes((out/'contract.json').read_bytes())
rows=[]
for f in sorted(out.rglob('*')):
 if f.is_file():
  b=f.read_bytes();rows.append({'path':str(f.relative_to(out)),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m={'schema_version':1,'members':rows,'member_count':len(rows),'total_member_bytes':sum(r['size'] for r in rows),'qualification':facts['chronology']};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for r in rows:
 b=(out/r['path']).read_bytes();assert len(b)==r['size'] and hashlib.sha256(b).hexdigest()==r['sha256']
print(json.dumps({'directory':str(out),'manifest_SHA':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),'members':len(rows),'bytes':m['total_member_bytes'],'report_SHA':hashlib.sha256(live.read_bytes()).hexdigest(),'counts':facts['coverage']},indent=2))
