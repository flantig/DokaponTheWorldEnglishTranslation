"""Run offline reports on text stored in the game files.

The reports check argument order, rendered line limits, and markup shapes. They share paths and address helpers while keeping their decoding methods separate.
"""

import argparse
from collections import Counter
import csv
from functools import partial
import json
from pathlib import Path
import struct
import sys

from ..iso_build import addresses

ROOT = Path(__file__).resolve().parents[4]
ISO_OFF = 0x9F800
SENT_LO, SENT_HI = 0x04000000, 0x04100000
BLOB_OFF = 2483 * 2048
MAXW = 4096
APPEND_HELPER = 0x2f37c0
CODE_LO, CODE_HI, DATA_HI = 0x100000, 0x3a0000, 0x539680
ON_DISC_STATUSES = ("patched", "decode_verified", "emulator_confirmed")

PEN0_WRAP_LO, PEN0_WRAP_HI = 0xE800, 0xEFFF


def is_arg(w):
    """Return whether a stream word is an argument token."""
    return 0x5000 <= w < 0xa800 or w in (0x4800, 0xb000, 0xd800, 0xe000)


def kind(w):
    """Classify an argument word as a string, numeric, or other token."""
    if 0xa000 <= w < 0xa800:
        return "S"
    if 0x6800 <= w < 0x9800:
        return "N"
    return "X"


def argtoks(context, ws):
    """Keep only argument tokens from a list of stream words."""
    return [w for w in ws if context["is_arg"](w)]


def iso_off(context, vma):
    """Convert a game address to its location in the selected ISO data."""
    if context["SENT_LO"] <= vma < context["SENT_HI"]:
        return context["BLOB_OFF"] + vma - context["SENT_LO"]
    return context["ISO_OFF"] + context["addr"].vma_to_file_off(vma)


def read_words(context, f, vma):
    """Read stream words at an address through the end marker or read limit."""
    f.seek(context["iso_off"](vma))
    raw = f.read(context["MAXW"] * 2)
    ws = []
    for (w,) in struct.iter_unpack("<H", raw[: len(raw) // 2 * 2]):
        if w == 0xF800:
            return ws
        ws.append(w)
    return None


def u32(context, f, vma):
    """Read one little-endian 32-bit value at a game address."""
    f.seek(context["iso_off"](vma))
    return struct.unpack("<I", f.read(4))[0]


def lui_addiu_target(lui, addiu):
    """Combine a LUI and ADDIU pair into its target address."""
    lo = addiu & 0xFFFF
    return ((lui & 0xFFFF) << 16) + (lo - 0x10000 if lo & 0x8000 else lo)


def live_targets(context, f, e):
    """Find the live address for each reference site in a registry entry.

If none can be read, use the entry ID as an in-place address.
"""
    out = []
    for s in e.get("ref_sites") or []:
        try:
            if "lui_vma" in s and "addiu_vma" in s:
                lv, av = int(s["lui_vma"], 16), int(s["addiu_vma"], 16)
                lui, addiu = context["u32"](f, lv), context["u32"](f, av)
                if lui >> 26 != 0x0F:
                    continue
                out.append((f"lui@{lv:#x}", context["lui_addiu_target"](lui, addiu)))
            elif "pointer_vma" in s:
                pv = int(s["pointer_vma"], 16)
                out.append((f"ptr@{pv:#x}", context["u32"](f, pv)))
        except (ValueError, struct.error):
            continue
    seen, uniq = set(), []
    for lab, v in out:
        if v not in seen:
            seen.add(v)
            uniq.append((lab, v))
    if not uniq:
        context["SKIPPED"]["fallback_to_id"] += 1
    return uniq or [("id", int(e["id"], 16))]


def classify(context, jp, en):
    """Describe how the Japanese and English argument sequences differ."""
    if jp == en:
        return "OK"
    if len(jp) != len(en):
        n = min(len(jp), len(en))
        if any(context["kind"](en[i]) == "S" and context["kind"](jp[i]) != "S" for i in range(n)) or (
                len(en) > len(jp) and any(context["kind"](w) == "S" for w in en[len(jp):])):
            return "FAULT+SHIFT"
        return "SHIFT"
    if any(context["kind"](a) != "S" and context["kind"](b) == "S" for a, b in zip(jp, en)):
        return "FAULT"
    if [context["kind"](w) for w in jp] != [context["kind"](w) for w in en]:
        return "GARBLE"
    return "SWAP"


def hx(ws):
    """Format stream words as space-separated four-digit hexadecimal values."""
    return " ".join(f"{w:04x}" for w in ws)


def audit(context, iso, ids=None, statuses=("patched", "emulator_confirmed", "decode_verified", "drafted")):
    """Compare selected registry entries' Japanese and on-disc argument tokens."""
    reg = read_registry(context["REGISTRY"])
    rows = []
    with open(iso, "rb") as f, open(context["VANILLA"], "rb") as v:
        for e in reg["entries"]:
            if ids and e["id"] not in ids:
                continue
            if e.get("status") not in statuses:
                continue
            rid = int(e["id"], 16)
            try:
                jpw = context["read_words"](v, rid)
            except ValueError:
                jpw = None
            if jpw is None:
                context["SKIPPED"]["jp_unreadable"] += 1
                continue
            jpa = context["argtoks"](jpw)
            for lab, tgt in context["live_targets"](f, e):
                try:
                    enw = context["read_words"](f, tgt)
                except ValueError:
                    rows.append(dict(id=e["id"], site=lab, live=hex(tgt), verdict="UNREADABLE", jp_args=context["hx"](jpa),
                                     en_args="", chapter=e.get("chapter") or "", en=(e.get("en") or "")[:120]))
                    continue
                if enw is None:
                    continue
                if enw == jpw:
                    continue  # unpatched site, identical to JP
                ena = context["argtoks"](enw)
                verdict = context["classify"](jpa, ena)
                if verdict == "OK":
                    continue
                rows.append(dict(id=e["id"], site=lab, live=hex(tgt), verdict=verdict, jp_args=context["hx"](jpa),
                                 en_args=context["hx"](ena), chapter=e.get("chapter") or "", en=(e.get("en") or "")[:120]))
    return rows


def _text_ok(context, ws):
    """Check whether a decoded stream looks like text suitable for comparison."""
    if ws is None:
        return False
    glyphs = sum(1 for w in ws if w < 0x800)
    return len(ws) <= 1500 and len(context["argtoks"](ws)) <= 8 and glyphs >= max(1, len(ws) // 2)


def _is_ptr_table(context, f, vma):
    """Check whether nearby words look like entries in a pointer table."""
    f.seek(context["iso_off"](vma))
    raw = f.read(32)
    vals = struct.unpack("<8I", raw)
    return sum(1 for x in vals if context["CODE_LO"] <= x < context["DATA_HI"] or context["SENT_LO"] <= x < context["SENT_HI"]) >= 2


def _ptr_at_first_diff(context, f, vma, jp, en):
    """Check for a pointer near the first differing stream word."""
    i = next((k for k, (x, y) in enumerate(zip(jp, en)) if x != y), min(len(jp), len(en)))
    base = (vma + 2 * i) & ~3
    f.seek(context["iso_off"](base - 4))
    vals = struct.unpack("<3I", f.read(12))
    return any(context["CODE_LO"] <= x < context["DATA_HI"] or context["SENT_LO"] <= x < context["SENT_HI"] for x in vals)


def _read_seg(context, path):
    """Read the configured game code and data address range from a file."""
    with open(path, "rb") as f:
        f.seek(context["iso_off"](context["CODE_LO"]))
        return f.read(context["DATA_HI"] - context["CODE_LO"])


def site_audit(context, iso):
    """Compare argument tokens at code and data references found in the game image.

It scans reference sites without relying on registry entries and reports changes between the original and selected image.
"""
    V, M = context["_read_seg"](context["VANILLA"]), context["_read_seg"](iso)
    w32 = lambda b, va: struct.unpack_from("<I", b, va - context["CODE_LO"])[0]  # noqa: E731
    cands = []
    for a in range(context["CODE_LO"], context["CODE_HI"], 4):
        w = w32(V, a)
        if w >> 26 != 0x0F:
            continue
        rt = (w >> 16) & 31
        for k in range(1, 16):
            b = a + 4 * k
            x = w32(V, b)
            op = x >> 26
            if op in (0x09, 0x0D) and ((x >> 21) & 31) == rt:
                sx = lambda v: (v - 0x10000 if (op == 0x09 and v & 0x8000) else v)  # noqa: E731
                tv = ((w & 0xFFFF) << 16) + sx(x & 0xFFFF)
                mw, mx = w32(M, a), w32(M, b)
                if mw >> 26 == 0x0F and mx >> 26 == op:
                    cands.append(("site:lui", a, tv, ((mw & 0xFFFF) << 16) + sx(mx & 0xFFFF)))
                break
            if ((x >> 16) & 31) == rt and op not in (0x2B, 0x29, 0x28, 0x3F, 0x04, 0x05):
                break
    for a in range(context["CODE_HI"], context["DATA_HI"], 4):
        tv = w32(V, a)
        if context["CODE_HI"] <= tv < context["DATA_HI"] and tv % 2 == 0:
            cands.append(("site:ptr", a, tv, w32(M, a)))
    rows, seen = [], set()
    with open(context["VANILLA"], "rb") as fv, open(iso, "rb") as fm:
        for chk, a, tv, tm in cands:
            if not (context["CODE_HI"] <= tv < context["DATA_HI"]) or not (context["CODE_HI"] <= tm < context["DATA_HI"] or context["SENT_LO"] <= tm < context["SENT_HI"]):
                continue
            try:
                jp, en = context["read_words"](fv, tv), context["read_words"](fm, tm)
            except ValueError:
                continue
            if not context["_text_ok"](jp) or en is None or en == jp:
                continue
            if tm == tv and (context["_is_ptr_table"](fm, tm) or context["_is_ptr_table"](fv, tv) or context["_ptr_at_first_diff"](fm, tm, jp, en)):
                continue  # binary data / a neighbouring pointer table repointed in place, not a format edit
            ja, ea = context["argtoks"](jp), context["argtoks"](en)
            verdict = context["classify"](ja, ea)
            if verdict == "OK" or (tv, tm) in seen:
                continue
            seen.add((tv, tm))
            rows.append(dict(check=chk, id=hex(tv), site=hex(a), live=hex(tm), verdict=verdict, jp_args=context["hx"](ja),
                             en_args=context["hx"](ea), chapter="", en=""))
    return rows


def append_audit(context, iso):
    """Compare each appended format's argument-token count with the caller's a3 count."""
    M = context["_read_seg"](iso)
    w32 = lambda va: struct.unpack_from("<I", M, va - context["CODE_LO"])[0]  # noqa: E731
    jal = (3 << 26) | (context["APPEND_HELPER"] >> 2)
    rows = []
    with open(iso, "rb") as fm:
        for site in range(context["CODE_LO"], context["CODE_HI"], 4):
            if w32(site) != jal:
                continue
            lo = site - 4
            while lo > site - 160 and not (w32(lo) >> 26 == 3 or w32(lo) == 0x03E00008):
                lo -= 4
            n_args, his, fmts = None, {}, []
            for a in range(lo + 4, site + 8, 4):
                x = w32(a)
                if x >> 16 == 0x2407:                         # addiu $a3,$zero,imm
                    n_args = x & 0xFFFF
                if x >> 26 == 0x0F and (x >> 16) & 31 == 5:   # lui $a1
                    his[5] = x & 0xFFFF
                if x >> 26 == 0x09 and (x >> 21) & 31 == 5 and (x >> 16) & 31 == 5 and 5 in his:
                    lo16 = x & 0xFFFF
                    fmts.append((his[5] << 16) + (lo16 - 0x10000 if lo16 & 0x8000 else lo16))
            for tm in fmts:
                en = context["read_words"](fm, tm)
                ea = context["argtoks"](en or [])
                bad = n_args is not None and len(ea) != n_args
                rows.append(dict(check="append:0x2f37c0", id="", site=hex(site), live=hex(tm),
                                 verdict=("SHIFT" if bad else "OK"), jp_args=f"a3={n_args}", en_args=context["hx"](ea),
                                 chapter="", en=""))
    return [r for r in rows if r["verdict"] != "OK"], rows


def argument_main(context, argv=None, *, explicit=False):
    """Run the argument-order audit and optionally write its results to CSV."""
    ap = argparse.ArgumentParser()
    ap.add_argument("--iso", type=Path, default=context["SHIPPING"], required=explicit)
    ap.add_argument("--csv", type=Path)
    ap.add_argument("--ids")
    if explicit:
        ap.add_argument("--registry", type=Path, required=True)
        ap.add_argument("--vanilla", type=Path, required=True)
    a = ap.parse_args(argv)
    if explicit:
        context.update(REGISTRY=a.registry, VANILLA=a.vanilla)
    rows = [dict(check="registry", **r) for r in context["audit"](a.iso, set(a.ids.split(",")) if a.ids else None)]
    if not a.ids:
        reg_live = {(r["live"]) for r in rows}
        rows += [r for r in context["site_audit"](a.iso) if r["live"] not in reg_live]
        bad, allrows = context["append_audit"](a.iso)
        rows += bad
        print(f"append helper 0x2f37c0: {len(allrows)} resolved format(s) checked against a3, {len(bad)} mismatched")
    order = {"FAULT": 0, "FAULT+SHIFT": 0, "SHIFT": 1, "GARBLE": 2, "SWAP": 3, "UNREADABLE": 4}
    rows.sort(key=lambda r: (order[r["verdict"]], r["check"], r["id"]))
    for r in rows:
        print(f"{r['verdict']:11} {r['check']:16} {r['id']:10} {r['site']:16} {r['live']:10} JP[{r['jp_args']}]"
              f" EN[{r['en_args']}] {r['chapter']}")
    from collections import Counter, defaultdict
    print(Counter(r["verdict"] for r in rows))
    if a.csv:
        cols = ["check", "id", "site", "live", "verdict", "jp_args", "en_args", "chapter", "en"]
        with open(a.csv, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=cols)
            w.writeheader()
            w.writerows(rows)
        print(f"wrote {len(rows)} rows -> {a.csv}")
    print(f"coverage notes: registry entries read at their own id (no resolvable lui/pointer site) ="
          f" {context["SKIPPED"]['fallback_to_id']}, JP unreadable = {context["SKIPPED"]['jp_unreadable']}; NOT checked: whole-composition"
          f" arg counts of strcat 0x2f39d0 / sprintf 0x101df8 builds (pieces are checked one by one), code in the"
          f" 0x1d00000 segment, sentinel-to-sentinel pointer tables")


def rendered_pages(tokens):
    """Count visible text tokens on each rendered line, grouped by page.

Headers and speaker control tokens are ignored, as are empty lines at the end of a page.
"""
    pages = []
    cur = [0]
    for t in tokens:
        k = t["kind"]
        if k in ("hdr", "speaker"):
            continue
        if k in ("page", "end"):
            while len(cur) > 1 and cur[-1] == 0:
                cur.pop()
            pages.append(cur)
            cur = [0]
            if k == "end":
                break
        elif k == "line":
            cur.append(0)
        elif k in ("glyph", "hl", "icon", "param8"):
            cur[-1] += 1
    return pages


def jp_reference_lines(context, entry, elf_bytes):
    """Return the original Japanese stream's rendered line counts as a reference for headerless content."""
    try:
        off = int(entry["id"], 16) - context["addr"].OLD_DELTA
    except (KeyError, ValueError):
        return None
    for require_hdr in (True, False):
        try:
            toks = context["dc"].decode_structured(elf_bytes, off, require_hdr=require_hdr)
        except (ValueError, IndexError):
            continue
        return [len(p) for p in context["rendered_pages"](toks) if sum(p) > 0]
    return None


def audit_entry(context, entry, iso_bytes, elf_bytes):
    """Decode one on-disc entry and report its page counts, capacity findings, or decoding error."""
    entry_id = entry["id"]
    land = entry.get("landing_vma")
    vma = int(land, 16) if land else int(entry_id, 16)
    max_lines = context["te"].box_max_lines(entry)
    max_chars = context["te"].box_max_chars(entry)
    rec = {
        "id": entry_id,
        "event": entry.get("event"),
        "source_pool": entry.get("source_pool"),
        "status": entry.get("status"),
        "patch_ref": entry.get("patch_ref"),
        "landing_vma": land,
        "decoded_at_vma": f"{vma:#x}",
        "box_max_lines": max_lines,
        "box_max_chars": max_chars,
        "en": entry.get("en"),
    }
    try:
        off = context["ISO_OFF"] + context["addr"].vma_to_file_off(vma)
    except ValueError as ex:
        rec["error"] = f"vma not mappable: {ex}"
        return rec

    try:
        rec["has_hdr"] = struct.unpack_from("<H", iso_bytes, off)[0] == context["dc"].HDR
    except struct.error as ex:
        rec["error"] = f"offset {off:#x} not readable: {ex}"
        return rec
    try:
        toks = context["dc"].decode_structured(iso_bytes, off, require_hdr=rec["has_hdr"])
    except (ValueError, IndexError) as ex:
        rec["error"] = str(ex)
        return rec

    rec["is_dialog_box"] = any(t["kind"] == "hdr" for t in toks)
    rec["text"] = context["dc"].stream_text(toks)
    pages = context["rendered_pages"](toks)
    counts = [len(p) for p in pages if sum(p) > 0]
    rec["pages"] = counts
    rec["max_page_lines"] = max(counts) if counts else 0
    rec["jp_pages"] = context["jp_reference_lines"](entry, elf_bytes)

    if rec.get("is_dialog_box"):
        rec["over_capacity"] = [
            {"page_index": n, "lines": len(p)}
            for n, p in enumerate([q for q in pages if sum(q) > 0])
            if len(p) > max_lines
        ]
        rec["broken"] = bool(rec["over_capacity"])
        rec["advisory"] = False
    else:
        rec["over_capacity"] = []
        rec["broken"] = False
        jp = rec["jp_pages"]
        rec["advisory"] = bool(jp and sum(counts) > sum(jp))

    en = entry.get("en") or ""
    if rec.get("is_dialog_box") and "{{" not in en:
        try:
            plan = context["te"].plan_stream_pages(en, max_chars, max_lines)
            rec["replan_pages"] = [len(lines) for _, _, lines in plan]
            rec["replan_added_pages"] = sum(1 for _, auto, _ in plan if auto)
            rec["replan_fits"] = all(n <= max_lines for n in rec["replan_pages"])
        except context["te"].EncodeError as ex:
            rec["replan_error"] = str(ex)
    return rec


def line_main(context, argv=None, *, explicit=False):
    """Check on-disc text against rendered line limits and print a report."""
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", help="write full per-entry results here")
    ap.add_argument("--all", action="store_true",
                    help="audit every on-disc entry, not just patch_ref phase3-*")
    ap.add_argument("--iso", default=str(context["MODDED_ISO"]), required=explicit)
    if explicit:
        ap.add_argument("--registry", type=Path, required=True)
        ap.add_argument("--elf", type=Path, required=True)
    args = ap.parse_args(argv)

    iso_bytes = Path(args.iso).read_bytes()
    elf_bytes = (args.elf if explicit else context["ROOT"] / "extracted" / "iso-root" / "SLPM_657.50").read_bytes()
    reg = read_registry(args.registry if explicit else context["REGISTRY_PATH"])
    cand = [e for e in reg["entries"] if e.get("status") in context["ON_DISC_STATUSES"]]
    if not args.all:
        cand = [e for e in cand if (e.get("patch_ref") or "").startswith("phase3-")]

    results = [context["audit_entry"](e, iso_bytes, elf_bytes) for e in cand]
    broken = [r for r in results if r.get("broken")]
    advisory = [r for r in results if r.get("advisory")]
    errs = [r for r in results if r.get("error")]

    print(f"iso: {args.iso}")
    print(f"audited {len(results)} on-disc entries "
          f"({'all patch_refs' if args.all else 'patch_ref phase3-* only'})")
    print(f"  decode errors            : {len(errs)}")
    print(f"  OVER CAPACITY (dialog box): {len(broken)}")
    print(f"  advisory (headerless, EN taller than JP): {len(advisory)}")
    if errs:
        print("\n--- decode errors (not necessarily broken, just unreadable here) ---")
        for r in errs:
            print(f"  {r['id']:10s} {str(r['event'])[:34]:34s} {r['error'][:90]}")
    if broken:
        auto = [r for r in broken if r.get("replan_fits")]
        manual = [r for r in broken if not r.get("replan_fits")]
        print(f"\n  of those: {len(auto)} fixed by re-encoding with the new "
              f"paginating encoder, {len(manual)} need a human "
              f"(not a paged box, or still over budget)")
        print("\n--- OVER-CAPACITY ENTRIES (text clips vertically) ---")
        hdr = (f"{'id':10s} {'event':34s} {'cap':4s} {'on-disc pages':24s} "
               f"{'worst':6s} after re-encode")
        print(hdr)
        print("-" * len(hdr))
        for r in sorted(broken, key=lambda x: -x["max_page_lines"]):
            after = (str(r["replan_pages"]) if r.get("replan_pages") is not None
                     else "n/a (not a paged box)")
            print(f"  {r['id']:10s} {str(r['event'])[:34]:34s} "
                  f"{r['box_max_lines']:<4d} {str(r['pages'])[:24]:24s} "
                  f"{r['max_page_lines']:<6d} {after}")
        print("\n--- detail ---")
        for r in sorted(broken, key=lambda x: -x["max_page_lines"]):
            print(f"\n{r['id']} {r['event']} ({r['source_pool']}, {r['status']}, "
                  f"{r['patch_ref']}) landing={r['landing_vma']}")
            print(f"  cap={r['box_max_lines']} lines / {r['box_max_chars']} chars; "
                  f"on-disc pages={r['pages']}")
            print(f"  on-disc: {r['text']}")
            if r.get("replan_pages") is not None:
                print(f"  re-encoded: pages={r['replan_pages']} "
                      f"(+{r['replan_added_pages']} auto page break(s)), "
                      f"fits={r['replan_fits']}")

    if advisory:
        print("\n--- ADVISORY: headerless (non-dialog-box) content whose EN needs")
        print("    MORE rendered lines than the shipped JP did in the same place.")
        print("    These panes have NO measured height - the JP line count is the")
        print("    only yardstick. They are NOT paged, so they cannot be auto-split:")
        print("    shortening the translation is the fix, and it is a human call.")
        hdr = f"{'id':10s} {'event':34s} {'JP lines':10s} EN lines"
        print("    " + hdr)
        for r in sorted(advisory, key=lambda x: -(x["max_page_lines"])):
            print(f"    {r['id']:10s} {str(r['event'])[:34]:34s} "
                  f"{str(r['jp_pages']):10s} {r['pages']}")
        print("\n    detail:")
        for r in sorted(advisory, key=lambda x: -(x["max_page_lines"])):
            print(f"\n    {r['id']} {r['event']} ({r['source_pool']}, {r['patch_ref']})")
            print(f"      JP on ELF : {r['jp_pages']} line(s)")
            print(f"      EN on disc: {r['pages']} -> {r['text']}")

    if args.json:
        Path(args.json).write_text(json.dumps({
            "iso": args.iso,
            "n_audited": len(results),
            "n_broken": len(broken),
            "n_advisory": len(advisory),
            "n_errors": len(errs),
            "entries": results,
        }, ensure_ascii=False, indent=1))
        print(f"\nwrote {args.json}")

    return 0


def read_registry(path):
    """Read and parse a registry JSON file."""
    return json.loads(path.read_text())


def unregistered_main(context, argv=None):
    """Export pointer-referenced JP strings outside the registry's known spans."""
    import bisect

    root, delta = context['ROOT'], context['DELTA']
    parser = argparse.ArgumentParser()
    parser.add_argument('--lo', type=lambda value: int(value, 0), default=0x400000)
    parser.add_argument('--hi', type=lambda value: int(value, 0), default=0x540000)
    args = parser.parse_args(argv)
    glyphmap = context['dc'].load_glyphmap()
    with open(root / 'iso/original/original.iso', 'rb') as source:
        source.seek(context['ELF_OFF'])
        elf = source.read(context['ELF_SIZE'])
    with open(root / 'registry/string-registry.json') as source:
        entries = json.load(source)['entries']
    spans = []
    for entry in entries:
        start = int(entry['id'], 16)
        offset, count = start - delta, 0
        while (0 <= offset + 2 * count < len(elf) - 1
               and struct.unpack_from('<H', elf, offset + 2 * count)[0] != 0xf800 and count < 4096):
            count += 1
        spans.append((start, start + 2 * count + 2))
    spans.sort()
    starts = [start for start, _ in spans]
    refs = {}
    for offset in range(0, len(elf) - 3, 4):
        word = struct.unpack_from('<I', elf, offset)[0]
        if args.lo <= word < args.hi and word % 2 == 0:
            refs.setdefault(word, []).append(offset + delta)
    rows = []
    for address, sites in sorted(refs.items()):
        index = bisect.bisect_right(starts, address) - 1
        if index >= 0 and spans[index][0] <= address < spans[index][1]:
            continue
        offset = address - delta
        if not 2 <= offset < len(elf) - 4:
            continue
        if struct.unpack_from('<H', elf, offset - 2)[0] not in (0xf800, 0):
            continue
        words = []
        for count in range(1024):
            if offset + 2 * count + 2 > len(elf):
                break
            word = struct.unpack_from('<H', elf, offset + 2 * count)[0]
            words.append(word)
            if word == 0xf800:
                break
        if words[-1] != 0xf800 or len(words) < 3:
            continue
        glyphs = [word for word in words if word < 0x800]
        known = [word for word in glyphs if isinstance(glyphmap.get(str(word)), str) and glyphmap.get(str(word))]
        if not glyphs or len(known) / len(glyphs) < 0.6:
            continue
        jp = ''.join(glyphmap.get(str(word)) if word < 0x800 and glyphmap.get(str(word)) else
                     ('|' if word == 0x0800 else '//' if word == 0x1000 else '') for word in words[:-1])
        kana = sum(1 for character in jp if '぀' <= character <= 'ヿ' or '一' <= character <= '鿿')
        if kana < 2:
            continue
        rows.append(dict(vma=hex(address), words=len(words), refs=' '.join(hex(site) for site in sites[:4]),
                         kana_ratio=round(len(known) / len(glyphs), 2), jp=jp))
    output = root / 'generated/history/unregistered-text.csv'
    with open(output, 'w', newline='') as destination:
        writer = csv.DictWriter(destination, fieldnames=['vma', 'words', 'refs', 'kana_ratio', 'jp'])
        writer.writeheader()
        writer.writerows(rows)
    print(f'{len(rows)} unregistered pointer-referenced JP strings -> {output}')


def report_context(report, root=ROOT):
    """Build the paths and helpers needed by the selected text report.

Specialized report types are routed to their own report modules.
"""
    if report in ("shapes", "clusters"):
        from ..maintenance import legacy
        path = {"shapes": "tools/audit_markup_shapes_2026-09-08c.py",
                "clusters": "tools/audit_midcontent_icon_pen0_2026-09-08.py"}[report]
        legacy.lookup(path, execute=True)
        raise ValueError(f"{path} is reference-only; use the native combined text-shape report")
    if report in ("writeback-drafted", "writeback-multi"):
        from . import writeback
        return writeback.report_context(report, root)
    if report in ("overflow", "streaming"):
        from . import backlog
        return backlog.report_context(report, root)
    root = Path(root)
    context = {
        "ROOT": root, "addr": addresses, "ISO_OFF": ISO_OFF,
        "SHIPPING": root / "iso/modded/modded-sentinel-bypass-fix.iso",
        "VANILLA": root / "iso/original/original.iso",
        "REGISTRY": root / "registry/string-registry.json",
        "REGISTRY_PATH": root / "registry/string-registry.json",
        "MODDED_ISO": root / "iso/modded/modded.iso",
        "SENT_LO": SENT_LO, "SENT_HI": SENT_HI, "BLOB_OFF": BLOB_OFF,
        "MAXW": MAXW, "SKIPPED": Counter(), "APPEND_HELPER": APPEND_HELPER,
        "CODE_LO": CODE_LO, "CODE_HI": CODE_HI, "DATA_HI": DATA_HI,
        "ON_DISC_STATUSES": ON_DISC_STATUSES,
    }
    if report == 'unregistered':
        from tools import dialog_codec
        context.update(ELF_OFF=0x9f800, ELF_SIZE=0x4398b0, DELTA=0xfff80, dc=dialog_codec)
        context['main'] = partial(unregistered_main, context)
    if report in ("lines",):
        from tools import text_encoder
        context.update(te=text_encoder, dc=text_encoder.dc)
    if report == "args":
        context["is_arg"] = is_arg
        context["kind"] = kind
        context["argtoks"] = partial(argtoks, context)
        context["iso_off"] = partial(iso_off, context)
        context["read_words"] = partial(read_words, context)
        context["u32"] = partial(u32, context)
        context["lui_addiu_target"] = lui_addiu_target
        context["live_targets"] = partial(live_targets, context)
        context["classify"] = partial(classify, context)
        context["hx"] = hx
        context["audit"] = partial(audit, context)
        context["_text_ok"] = partial(_text_ok, context)
        context["_is_ptr_table"] = partial(_is_ptr_table, context)
        context["_ptr_at_first_diff"] = partial(_ptr_at_first_diff, context)
        context["_read_seg"] = partial(_read_seg, context)
        context["site_audit"] = partial(site_audit, context)
        context["append_audit"] = partial(append_audit, context)
        context["main"] = partial(argument_main, context)
    if report == "lines":
        context["rendered_pages"] = rendered_pages
        context["jp_reference_lines"] = partial(jp_reference_lines, context)
        context["audit_entry"] = partial(audit_entry, context)
        context["main"] = partial(line_main, context)
    return context


def main(argv=None):
    """Select and run the requested text audit report."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", choices=("args", "lines", "shapes", "clusters", "writeback-drafted", "writeback-multi", "overflow", "streaming", "unregistered"))
    parser.add_argument("arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    if args.report in ("writeback-drafted", "writeback-multi"):
        from . import writeback
        return writeback.main([args.report, *args.arguments])
    if args.report in ("overflow", "streaming"):
        from . import backlog
        return backlog.main([args.report, *args.arguments])
    if args.report in ("shapes", "clusters"):
        try:
            return report_context(args.report)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            parser.error(str(exc))
    context = report_context(args.report)
    if args.report == 'unregistered':
        return context['main'](args.arguments)
    command = argument_main if args.report == "args" else line_main
    return command(context, args.arguments, explicit=True)


if __name__ == "__main__":
    main()
