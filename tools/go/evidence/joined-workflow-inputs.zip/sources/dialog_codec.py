#!/usr/bin/env python3
"""dialog_codec.py - shared, structural dialog-stream decoder/encoder.

Promotes tools/verify_b1.py's decode() (originally a human-readable-text-only
decoder, imported into build_change_ledger.py via an importlib path-hack)
into a real shared module, extended to return STRUCTURED data (a list of
tokens with byte-accurate positions/lengths) rather than just display text -
Phase 3's relocation tools need to know exact structure (pages, speakers,
control-code payloads) to safely re-encode a translated string, not just
render it for a human to read.

Control-code semantics implemented here - kept in sync with classify_word()
below; if you're reading this table, trust classify_word()'s actual ranges
over prose, and fix this comment rather than let it drift again (this table
already went stale once, on 2026-09-04 - see the CORRECTED note right below
for what changed and why):
  0x2800            HDR   - box-open / render-style state code. Conventionally
                             the first word of a stream, but NOT structurally
                             required to be (see "CORRECTION 2026-09-04 (b)"
                             below) - it is an ordinary self-contained 2-byte
                             type-5 code like any other.
  0x4000-0x47FF     SETUP - type 8, self-contained, 0 extra bytes (see below)
  0xA800-0xAFFF     SETUP - type 21, self-contained, 0 extra bytes (see below)
  0xF800            END   - terminator
  0x1000            PAGE  - page break; peek next word, consume as SPEAKER
                             only if in [0x3800,0x3FFF] (full type-7
                             codespace, widened 2026-09-04 - see note below),
                             else no speaker here
  0x0800            LINE  - manual in-page line break (renderer does not
                             auto-wrap), no payload
  0x0000            SPACE - glyph 0, used as inter-word space
  0xB000 (exact)    an 8-byte opaque payload follows (param==0 special case)
  0xB001-0xB7FF     TEXT COLOUR, not a generic "highlight" (type 22, nonzero
                             param = table index, handler 0x2a3198), 0 extra
                             bytes - copy verbatim. Confirmed 2026-09-04 by
                             hand-disassembling the handler AND reading the
                             10-entry RGBA table it indexes at ELF VMA
                             0x521950 (4 bytes/entry, bounded by ASCII string
                             data starting 0x521978): [0]=000000ff black
                             [1]=dc2323ff red [2]=2323dcff blue
                             [3]=0ad232ff green [4]=0a96b4ff teal
                             [5]=e68c0aff orange [6]=6e6e82ff grey
                             [7]=ffffffff WHITE [8]=000000ff BLACK
                             [9]=00000000 transparent. So 0xb007="set white",
                             0xb008="set black" etc - includes the
                             0xE86E/0xE864-shaped codes' type-22 siblings
  0x6800-0x97FF     self-contained ICON token (types 13-18), 0 extra bytes -
                             CORRECTED 2026-09-04, was wrongly modeled as an
                             8-byte param-block trigger (see note below)
  0xA000-0xA7FF     self-contained ICON token (type 20), 0 extra bytes -
                             same correction, empirically tested at 0xA000
  0x9800-0x9FFF     type 19, a DIFFERENT handler than the ICON family above -
                             deliberately left UNCLASSIFIED (raises rather
                             than guesses): zero real occurrences in the
                             Phase 3 backlog to test against, never
                             independently verified
  0xB800-0xBFFF     pen-X-set (type 23), 0 extra bytes
  0xC000-0xC7FF     pen-X-add (type 24), sign-extended 11-bit amount
  0xC800-0xCFFF     pen-Y-set (type 25), 0 extra bytes
  0xD000-0xD7FF     pen-Y-add relative (type 26), 0 extra bytes
  0xD800 (exact)    an 8-byte opaque payload follows (param==0 special case)
  0xD801-0xDFFF     0 extra bytes (type 27, nonzero param)
  0xE001-0xE7FF     type 28 render-object/layout command, 0 stream payload
                    (nonzero parameter is passed to the icon-resource helper)
  0xE000 (exact)    special type-28 branch reads the next 8-byte vararg slot;
                    intentionally left unclassified until represented safely
  0xE800-0xEFFF     text-scale/highlight (type 29), 0 extra bytes always -
                             covers OPEN_HL/CLOSE_HL (0xE86E/0xE864) used by
                             tools/patch_navi_c.py
  anything else that isn't a valid glyph index (0 <= w < GLYPH_MAX) is
  UNKNOWN - the decoder raises rather than guesses. A word in the glyph
  range is only actually a glyph if extracted/glyphmap.json has a non-empty
  entry for it; an empty/missing entry is also UNKNOWN.

CORRECTED 2026-09-04 (do not revert to the old model): codes in 0x6800-
0x97FF and 0xA000-0xA7FF were originally believed to be "param-block"
triggers consuming 8 opaque bytes (matching the ALREADY-CONFIRMED 0x7000/
0xa000/0x9800-0x9fff family cited in earlier project docs). 2 independent
adversarial reviewers hand-disassembled the shared handler (VMA 0x2a3150)
and CONFIRMED it unconditionally advances the stream cursor by 8 bytes for
every code in this range - the machine-level claim was correct. But
real-world decoding of actual on-disk occurrences REFUTED the practical
consequence: applying the 8-byte skip ate real kanji (e.g. "出てきた!"
truncated to "た!"). The owner's own knowledge of the game - it uses inline
icons that could be misrepresented - was the deciding clue: re-testing
real occurrences as self-contained, zero-payload ICON tokens (same
treatment as the 0xb0xx highlight family) produced fully grammatical
Japanese in every case tested. Full incident:
docs/planning-log/2026-09-04-phase3-overflow-relocation.md. Lesson: a
correct STATIC/dispatcher-level analysis is not automatically the correct
model for what's actually stored in the ELF's real string data - some
other mechanism (not yet identified) evidently intercepts these specific
codes before the raw bytes would ever reach this handler at runtime.

CORRECTION 2026-09-04 (b) - "0x2800 is the stream HEADER" was a convention,
not a format rule; there is no such thing as a "preamble".
The whole control-code engine was hand-disassembled end to end this pass and
the dispatcher is now fully mapped:

  dispatch entry  0x2a2a94  lhu   $a1, ($a1)       ; read the u16 code word
                  0x2a2a98  sra   $v0, $a1, 0xb    ; type = word >> 11
                  0x2a2a9c  sltiu $at, $v0, 0x1f   ; types 0..30 only
                  0x2a2aa0  beqz  $at, 0x2a34f0    ; type >= 31 -> no-op return
                  0x2a2aa4  daddu $s0, $a2, $zero  ; $s0 = the EXTRA-PAYLOAD cursor
                  0x2a2aa8  lui   $v1, 0x52
                  0x2a2ab0  addiu $v1, $v1, 0x19f0 ; jump table base = 0x5219f0
                  0x2a2ab8  lw    $v0, ($v0)       ; table[type]
                  0x2a2abc  jr    $v0

The 31-entry table at VMA 0x5219f0 reproduces every handler this project had
already confirmed piecemeal (idx 9 -> 0x2a30e8, idx 13-18 -> 0x2a3150,
idx 19 -> 0x2a30b8), so it is the real table, not a lookalike. The decisive
rule it establishes: a handler consumes EXTRA payload if and only if it
modifies $s0. Handlers that never touch $s0 are self-contained 2-byte codes.

Newly characterised this pass, both previously UNCLASSIFIED (decoder used to
raise on them):
  type 8  (0x4000-0x47FF) -> handler 0x2a30d0, 4 real instructions:
        bnez  $a3, ret            ; $a3 is the render-pass selector
        andi  $v0, $a1, 0x7ff     ; v0 = low-11-bit param
        b     ret
        sb    $v0, 3($s1)         ; renderer state byte +3 = param
      $s0 is never touched on any path -> 0 extra bytes, UNCONDITIONALLY.
      Note this family has NO "literal-zero-param means 8-byte payload" idiom
      at all (unlike types 9/22/27 and the 0xb000/0xd800/0x4800 exacts) -
      there is no `beq param, $zero` anywhere in the handler, so 0x4000 is
      just as self-contained as 0x4001.
  type 21 (0xA800-0xAFFF) -> handler 0x2a3188, 3 real instructions:
        andi  $v0, $a1, 0x7ff
        b     ret
        sb    $v0, 5($s1)         ; renderer state byte +5 = param
      Same story: $s0 untouched, 0 extra bytes, no param-zero special case.
      NOTE 0xA800-0xAFFF is type 21 and is NOT the type-20 ICON range
      (0xA000-0xA7FF, handler 0x2a3168) - they are different handlers and
      easy to conflate by eye. 0xa80a in particular is type 21, not an ICON.

And the reason the "preamble" ever looked like a mystery: type 5 (0x2800)
itself never touches $s0 either. Its handler (0x2a3060, continuing via
0x2a34f8 -> 0x2a3070) does exactly two things, both of them state writes:
        sb    $v0(=5), 5($s1)     ; state byte +5 = 5     <-- SAME BYTE type 21 writes
        lbu/ori 4/sb  1($s1)      ; state byte +1 |= 4
guarded by a runtime global (lw $v1, -0x55a0($at) with lui $at,0x57 =
VMA 0x56AA60, which is past end-of-file, i.e. .bss - a runtime mode flag).
So 0x2800 is a plain self-contained state-setting code that sets a render
style, exactly like 0xa80a does; it is merely CONVENTIONAL for it to come
first. Whichever of the two runs last wins state[5].

That is why real streams carry these setup codes in three different orders,
all four sharing the same set of words - hand-verified on disc:
  0x4ef2e0 navi-intro-a    a80a 4001 2800 b007 3b8b   (2800 is 3rd)
  0x4ef360 navi-intro-b    3b8d a80a 4001 2800 b007   (2800 is 4th)
  0x4f1220 ending-epilogue 2800 b007 a80a 4001 3b91   (2800 is 1st)
  0x458f20 cant-predict    4001 <glyph...>            (no 2800 at all)
An ELF-wide scan of all 5602 stream starts in 0x450000-0x539BB0 found that
0x4ef2e0 and 0x4ef360 are the ONLY two streams in the entire game where a
0x2800 exists but is not the leading word - so this is a genuine 2-instance
rarity, not an unrecognised sub-format. It still has to be modelled correctly
rather than special-cased, because the SAME missing knowledge (types 8/21)
independently breaks 0x4f1220 and 0x458f20, where 0x2800 sits exactly where
the old model expected it.

Consequence for decode_structured(): the old "first word must be HDR, then
maybe one speaker" prologue is replaced by a general prologue scan that
consumes the stream's leading run of self-contained control codes in ANY
order (HDR at most once, one speaker at most once, plus SETUP/HL/PEN0),
stopping at the first content word. For every stream that already decoded,
the emitted token list is byte-for-byte identical - the scan just emits the
same kinds the main loop would have. require_hdr=True now means "an hdr
token must appear somewhere in that leading run", not "at index 0".

IMPORTANT, found 2026-09-04 auditing the "plain" (no {{HL:}}/{{PARAM:}} in
`en`) tier of Phase 3's overflow backlog: several pool_b_gameplay JP streams
contain REAL 0xb0xx/param-block control codes that were never captured in
the registry's structured fields (standalone_codes/param_blocks/inline_codes)
- the `en` markup alone is NOT a reliable signal for whether a string's JP
source is control-code-free. Any relocation tool MUST decode the actual JP
bytes structurally before assuming "plain" - see audit_dialog_structure.py.
"""
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

HDR = 0x2800
END = 0xF800
PAGE = 0x1000
LINE = 0x0800
SPACE = 0x0000
SPK_LO, SPK_HI = 0x3800, 0x3FFF   # full type-7 codespace (0x3800/2048==7 exactly)
# NOTE (2026-09-04): verify_b1.py's original range (0x3A00-0x3AFF) was empirically
# narrow - it happened to cover only the specific character IDs sampled in the small
# B1_STRINGS set (Navi/King-adjacent). Auditing the real Phase 3 backlog found many
# entries using speaker codes as low as 0x39ea/0x39eb (grammatically coherent Japanese
# confirmed once decoded with the wider range: "Oh, welcome." / "What business do you
# have today?" at VMA 0x47f790) - the type-7 dispatch range (0x3800-0x3FFF, 1024
# possible speaker/character IDs) is the real boundary, not the narrow B1 sample.
# Widening this alone took the Phase 3 backlog's clean-decode rate from 531/803 to
# 745/803 - see docs/planning-log/2026-09-04-phase3-overflow-relocation.md.

GLYPH_MAX = 1323  # extracted/glyphmap.json has keys "0".."1322"


def load_glyphmap():
    return json.loads((ROOT / "extracted" / "glyphmap.json").read_text())


def load_rev(gm=None):
    gm = gm or load_glyphmap()
    rev = {}
    for k, v in gm.items():
        if v:
            idx = int(k, 16) if isinstance(k, str) and k.startswith("0x") else int(k)
            rev.setdefault(v, idx)
    return rev


def classify_word(w, gm):
    """Returns a tag string for a control word, or None if w is a plain glyph
    (caller must separately confirm w is in gm and non-empty to treat it as
    a real glyph - this function alone does not validate that)."""
    if w == HDR:
        return "HDR"
    if w == END:
        return "END"
    if w == PAGE:
        return "PAGE"
    if w == LINE:
        return "LINE"
    if w == SPACE:
        return "SPACE"
    if w == 0xB000:
        return "PARAM8"       # b000 exact: 8-byte opaque payload
    if 0xB001 <= w <= 0xB7FF:
        return "HL"            # self-contained highlight, 0 extra bytes
    if 0x6800 <= w <= 0x97FF or 0xA000 <= w <= 0xA7FF:
        return "ICON"           # self-contained icon-glyph token, 0 extra bytes
                                 # (corrected 2026-09-04 - see note below). Covers
                                 # types 13-18 (0x6800-0x97FF, one shared handler,
                                 # empirically tested at 0x8800/0x9000) and type 20
                                 # (0xA000-0xA7FF, empirically tested at 0xA000).
    # NOTE: type 19 (0x9800-0x9FFF, a DIFFERENT handler, 0x2a30b8) is deliberately
    # left unclassified - zero real occurrences exist in the Phase 3 in-scope
    # backlog to test against, and its handler was never independently verified
    # against real bytes the way 17/18/20 were. If encountered, this raises
    # rather than guesses - investigate before trusting either interpretation.
    if 0x4000 <= w <= 0x47FF:
        return "SETUP"          # type 8, handler 0x2a30d0: `sb param, 3($s1)`,
                                 # $s0 never touched -> self-contained, 0 extra
                                 # bytes, no param-zero special case (confirmed
                                 # 2026-09-04 by hand disassembly)
    if 0xA800 <= w <= 0xAFFF:
        return "SETUP"          # type 21, handler 0x2a3188: `sb param, 5($s1)`,
                                 # writing the SAME renderer state byte 0x2800's
                                 # own handler sets to 5. Self-contained, 0 extra
                                 # bytes. NOT the type-20 ICON range below it.
    if w == 0x4800:
        return "PARAM8"         # 4800 exact: 8-byte opaque payload (param==0
                                 # special case, confirmed 2026-09-04 via hand
                                 # disassembly of handler 0x2a30e8 - same
                                 # andi/beq-on-zero idiom as 0xb000/0xd800)
    if 0x4801 <= w <= 0x4FFF:
        return "PEN0"            # type 9 ("table coordinate"), nonzero param,
                                 # 0 extra bytes - same handler, confirmed via
                                 # the same trace; every real occurrence found
                                 # in the settings-option pool uses 0x4817
                                 # (param 0x17), consistently nonzero
    if 0xB800 <= w <= 0xBFFF:
        return "PEN0"           # pen-X-set, 0 extra bytes
    if 0xC000 <= w <= 0xC7FF:
        return "PEN0"           # type 24: sign-extended pen-X-add, 0 payload
    if 0xC800 <= w <= 0xCFFF:
        return "PEN0"           # pen-Y-set
    if 0xD000 <= w <= 0xD7FF:
        return "PEN0"           # pen-Y-add
    if w == 0xD800:
        return "PARAM8"         # d800 exact: 8-byte opaque payload
    if 0xD801 <= w <= 0xDFFF:
        return "PEN0"
    if 0xE001 <= w <= 0xE7FF:
        # Type 28's nonzero-parameter path calls the object/layout builder
        # with this parameter and does not advance the stream/vararg cursor.
        # Exact 0xE000 takes a separate vararg-consuming path and stays
        # unclassified until that argument can be represented without
        # confusing it with an inline stream payload.
        return "PEN0"
    if 0xE800 <= w <= 0xEFFF:
        return "PEN0"           # text-scale / OPEN_HL/CLOSE_HL family
    return None


def decode_structured(data, off, max_words=4096, require_hdr=True):
    """Decode one stream starting at byte offset `off` in `data` into a flat
    list of tokens. Each token is a dict:
      {"kind": "hdr"|"speaker"|"setup"|"page"|"line"|"space"|"glyph"|"hl"
               |"pen0"|"param8"|"end",
       "off": byte offset of this token's OWN code word (not any payload),
       "word": the raw u16 code/glyph word,
       "payload": raw 8 bytes (only for "param8"), else None}
    Raises ValueError on any word that isn't recognized (HDR/END/PAGE/LINE/
    SPACE/known-control-range) and isn't a valid non-empty glyphmap entry -
    NEVER silently guesses.

    PROLOGUE (rewritten 2026-09-04 - see "CORRECTION 2026-09-04 (b)" in the
    module docstring for the hand-disassembly this rests on): a stream may
    open with a run of self-contained state-setting control codes in ANY
    order, because that is literally all the dispatcher does with them - each
    one writes a renderer state byte and returns without moving the payload
    cursor. 0x2800 is one of those codes, not a structural header, so it is
    not required to be first (and in 0x458f20 it is absent entirely).
    This loop therefore consumes the leading control run - at most one HDR,
    at most one speaker, plus any number of SETUP/HL/PEN0 codes - and stops
    at the first content word (glyph/PAGE/LINE/SPACE/END) or anything else it
    does not handle here (ICON, PARAM8, a second HDR/speaker), leaving those
    to the main loop below, which emits them identically.

    Because the prologue emits exactly the kinds the main loop would have
    emitted for the same words, every stream that decoded before this change
    still decodes to a byte-for-byte identical token list; the change is
    purely additive (streams that used to raise now decode).

    require_hdr=True: an "hdr" token must appear somewhere in that leading
    run (it used to mean "at index 0").
    require_hdr=False (added 2026-09-04 for the settings-option pool):
    settings-menu-adjacent streams do NOT contain 0x2800 at all - found
    empirically, confirmed across all 9 real settings-option entries in the
    registry (every one's registered VMA starts directly on a glyph) - these
    are presumably rendered by a different, non-dialog-box renderer that
    doesn't need the box-open signal HDR provides elsewhere. The same flag
    also covers navi-intro-f0 (0x4ef500), which is header-less but DOES open
    with a bare speaker word - a shape the old fixed prologue could not
    express at all.
    """
    gm = load_glyphmap()
    tokens = []
    i = off
    # ---- prologue: leading run of self-contained state-setting codes ----
    seen_hdr = False
    seen_speaker = False
    for _ in range(max_words):
        w = struct.unpack_from("<H", data, i)[0]
        if w == HDR and not seen_hdr:
            seen_hdr = True
            tokens.append({"kind": "hdr", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if SPK_LO <= w <= SPK_HI and not seen_speaker:
            # dialog_box-mode streams name the first page's speaker up here,
            # with no PAGE word first (see patch_prologue.py's build_stream()).
            # pool_b_gameplay-shaped streams have no initial speaker at all.
            seen_speaker = True
            tokens.append({"kind": "speaker", "off": i, "word": w, "payload": None})
            i += 2
            continue
        tag = classify_word(w, gm)
        if tag == "SETUP":
            tokens.append({"kind": "setup", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "HL":
            tokens.append({"kind": "hl", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "PEN0":
            tokens.append({"kind": "pen0", "off": i, "word": w, "payload": None})
            i += 2
            continue
        break
    if require_hdr and not seen_hdr:
        w0 = struct.unpack_from("<H", data, off)[0]
        raise ValueError(
            f"decode_structured: no HDR {HDR:#06x} in the leading control run at "
            f"{off:#x} (first word {w0:#06x}, prologue consumed "
            f"{len(tokens)} word(s))")
    for _ in range(max_words):
        w = struct.unpack_from("<H", data, i)[0]
        tag = classify_word(w, gm)
        if tag == "END":
            tokens.append({"kind": "end", "off": i, "word": w, "payload": None})
            return tokens
        if tag == "PAGE":
            spk_off = i + 2
            spk = struct.unpack_from("<H", data, spk_off)[0]
            if SPK_LO <= spk <= SPK_HI:
                tokens.append({"kind": "page", "off": i, "word": w, "payload": None})
                tokens.append({"kind": "speaker", "off": spk_off, "word": spk, "payload": None})
                i = spk_off + 2
            else:
                tokens.append({"kind": "page", "off": i, "word": w, "payload": None})
                i += 2
            continue
        if tag == "LINE":
            tokens.append({"kind": "line", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "SPACE":
            tokens.append({"kind": "space", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "HL":
            tokens.append({"kind": "hl", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "ICON":
            tokens.append({"kind": "icon", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "SETUP":
            tokens.append({"kind": "setup", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "PEN0":
            tokens.append({"kind": "pen0", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "PARAM8":
            payload_off = i + 2
            payload = bytes(data[payload_off:payload_off + 8])
            tokens.append({"kind": "param8", "off": i, "word": w, "payload": payload})
            i = payload_off + 8
            continue
        if SPK_LO <= w <= SPK_HI:
            # Bare mid-stream speaker change (2026-09-05, found live in the
            # jp_decode_failed diagnostic bucket): the PAGE-adjacent case
            # above already covers a speaker word immediately after PAGE;
            # this covers the same type-7 dispatch range appearing anywhere
            # else in the main loop (all 4 real occurrences found so far
            # follow a LINE word - a speaker change within the same page,
            # not a new page). Purely additive: a word this range would
            # previously always fail "not a valid glyph" (SPK_LO/HI is
            # deliberately never registered in glyphmap.json), so no
            # existing decode result changes.
            tokens.append({"kind": "speaker", "off": i, "word": w, "payload": None})
            i += 2
            continue
        # not a recognized control word - must be a valid glyph
        key = str(w)
        if key not in gm or not gm[key]:
            raise ValueError(
                f"decode_structured: unrecognized word {w:#06x} at offset {i:#x} "
                f"(stream started {off:#x}) - not HDR/END/PAGE/LINE/SPACE/known "
                f"control range, and not a valid non-empty glyphmap entry")
        tokens.append({"kind": "glyph", "off": i, "word": w, "payload": None})
        i += 2
    raise ValueError(f"decode_structured: no END found within {max_words} words of {off:#x}")


def stream_text(tokens, rev_or_gm=None):
    """Human-readable rendering of a decode_structured() token list, for
    logs/debugging only - not used for byte-level correctness anywhere."""
    gm = load_glyphmap()
    out = []
    for t in tokens:
        k = t["kind"]
        if k in ("hdr", "end"):
            continue
        if k == "speaker":
            out.append(f"[spk {t['word']:#06x}]")
        elif k == "page":
            out.append("//")
        elif k == "line":
            out.append("|")
        elif k == "space":
            out.append(" ")
        elif k == "hl":
            out.append(f"{{{{HL:{t['word']:#06x}}}}}")
        elif k == "icon":
            out.append(f"{{{{ICON:{t['word']:#06x}}}}}")
        elif k == "pen0":
            out.append(f"<PEN {t['word']:#06x}>")
        elif k == "setup":
            out.append(f"<SETUP {t['word']:#06x}>")
        elif k == "param8":
            out.append(f"{{{{PARAM:{t['word']:#06x}}}}}")
        elif k == "glyph":
            out.append(gm.get(str(t["word"]), f"<{t['word']:#06x}>"))
    return "".join(out)


if __name__ == "__main__":
    import sys
    ELF_PATH = ROOT / "extracted" / "iso-root" / "SLPM_657.50"
    DELTA = 0xFFF80
    data = ELF_PATH.read_bytes()
    vma = int(sys.argv[1], 16)
    off = vma - DELTA
    toks = decode_structured(data, off)
    print(f"decoded {len(toks)} tokens from {vma:#x}:")
    for t in toks:
        extra = f" payload={t['payload'].hex()}" if t["payload"] else ""
        print(f"  @{t['off']:#08x} {t['kind']:8s} {t['word']:#06x}{extra}")
    print("\ntext:", stream_text(toks))
