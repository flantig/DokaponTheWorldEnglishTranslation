#!/usr/bin/env python3
"""text_encoder.py - builds a translated dialog stream's real bytes from a
registry entry's `en` markup text, using the ORIGINAL JP stream (decoded via
dialog_codec.decode_structured()) as the structural template for whatever the
EN markup doesn't itself specify (speaker carry-forward, trailing pause).

Scope (2026-09-04): built for the "truly plain" tier of Phase 3's overflow
backlog - entries whose JP stream has NO control codes at all (no hl/icon/
pen0/param8 tokens), confirmed via a live audit against
docs/audits/2026-09/overflow-backlog-audit-2026-09-03.json (623 of 803 in-scope entries).
Entries with JP-embedded icon/highlight codes are handled separately (many
have no EN position marker at all - a translation-completeness gap, not a
tooling gap, see docs/HANDOFF.md's 2026-09-04 entry) and must NOT be run
through this encoder without that markup first.

Design, grounded in a live structural audit of the actual 623-entry backlog,
not assumption:
  - Owner decision 2026-09-04: the EN text's OWN `//`/`|` page/line structure
    is authoritative, even when it diverges from JP's page count (83% of the
    backlog does - JP's page breaks are often just a JP-text-width artifact,
    not something a natural English sentence needs to mirror).
  - Speaker word: emitted on the stream's own initial page IF the JP source
    had an initial (post-HDR) speaker, and on any later EN page that carries
    its own `[spk 0xNNNN]` tag - otherwise omitted. This matches the real
    distribution (87/739 page breaks in the plain tier carry an explicit
    speaker; the rest are bare pacing pauses within one speaker's continuous
    line) and skills/STRING-REGISTRY.md's own documented convention ("[spk]
    - prefix on a page whose speaker DIFFERS from the previous page's").
  - Trailing pause: mirrored from JP structurally (a bare PAGE word
    immediately before JP's END), regardless of how many pages the EN text
    ends up needing - this is a pacing/wait-for-input property of the BOX,
    not tied to page count.
  - Box fit is TWO budgets, not one (2026-09-04): max_chars horizontally
    (wrap_line(), added when EN text was found clipping off the box's side
    edges) and max_lines VERTICALLY (paginate_lines(), added when the
    horizontal fix's extra lines were found clipping off the box's TOP and
    BOTTOM edges - owner screenshot Screenshot_20260904_032459.png). Over-wide
    text becomes more lines; over-tall text becomes more PAGES. Nothing is
    ever cropped and nothing is ever silently dropped.
"""
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import dialog_codec as dc  # noqa: E402

SPK_TAG_RE = re.compile(r"^\s*\[spk (0x[0-9a-fA-F]{4})\]\s*")

# Safe-width constants (2026-09-04). The renderer never auto-wraps (confirmed
# via real PCSX2 screenshots during the original B1 patch - see
# tools/patch_prologue.py's own comments) - ANY line exceeding the box's real
# pixel width clips at the edge. Found as a LIVE regression when Phase 3's
# navi_intro batch shipped without this check (owner report, 2026-09-04) -
# these constants + wrap_line()/encode_page_text()'s max_chars parameter are
# the fix, applied retroactively to everything already patched and going
# forward to everything still to come.
LARGE_BOX_MAX_CHARS = 22   # main story/narration dialog box (navi_intro,
                           # pool_b_gameplay, settings-option per owner
                           # confirmation 2026-09-04). Empirically derived
                           # from real B1 screenshots: 22-24 chars reliably
                           # fits, 27-28+ reliably clips - using the safe end
                           # of that range, not the risky edge.
NARRATION_BANNER_MAX_CHARS = 22  # navi-intro-a/navi-intro-b specifically
# (VMA 0x4ef2e0/0x4ef360) - the opening "It was one day..." scene-setting
# narration, drawn as a scrim banner over the map instead of in a dialog box.
#
# WAS 30, AN ESTIMATE, AND IT WAS WRONG - CORRECTED 2026-09-04 FROM REAL
# ENGLISH-ON-DISC PCSX2 CAPTURES. The old 30 came from eyeballing JP reference
# screenshots and concluding "this banner is visibly wider than the normal box".
# The SCRIM PANEL is indeed nearly full-screen (measured x 272..1465), but the
# scrim is not what clips, and the glyphs are drawn at the same advance as
# everywhere else - so the usable CHARACTER budget is not wider at all. Shipping
# 30 clipped live text off BOTH screen edges (owner report + captures below).
#
# EVIDENCE - three owner captures of the live English banner:
#   screenshots/Screenshot_20260904_042220.png, _042240.png, _042256.png.
#   They are pixel-identical renders of the same scene, offset by (dx,dy)
#   (-7,-2) and (+1,-1) (cross-correlation, mean-abs-diff 0.0), so every number
#   below is stated in 042220's pixel frame.
#
#  1. THE CLIP IS NOT A BOX. There is no window here - this scene composites the
#     map (and this text) into the in-game TV screen, and that render target,
#     spanning x 256..1479 = 1224 px, is the OUTER bound on where text can draw.
#     The scrim panel behind the text (x 272..1465) is only art and clips
#     nothing. See point 3 for the tighter bound actually observed.
#  2. GLYPH ADVANCE = 45.6 px, measured on runs with no spaces in them:
#     "country..." 10 glyphs -> 45.7 px/glyph, "creeping..." 11 -> 45.4.
#     A SPACE IS WIDER THAN A GLYPH CELL: least-squares over 8 word-start-to-
#     word-start distances on 3 fully-visible lines gives
#     distance = 45.6*letters + ~60..65*spaces, i.e. a space costs ~1.3-1.4
#     cells. This is why a raw character count flatters a space-heavy line.
#  3. WHAT ACTUALLY RENDERED (chars = characters in that rendered line):
#       COMPLETE  21  "an ominous shadow was"   ink 363..1366 -> only 107 px
#                     left / 113 px right of clear margin (~2.3 glyph cells)
#       COMPLETE  20  "The Dokapon Kingdom."    ink 396..1304
#       COMPLETE  19  "Under a great king,"     ink 437..1279
#       CLIPPED   26  "the people lived without a" - loses the leading "t" AND
#                     the trailing " a"                        (_042240.png)
#       CLIPPED   29  "A land of abundance, an ideal" - loses "A " left and
#                     "eal" right; this is the line the owner reported
#                                                              (_042220.png)
#       CLIPPED   30  "But into that Dokapon Kingdom," - loses "But " left and
#                     "om," right                              (_042256.png)
#     Across all three clipped lines NO surviving glyph ink was ever observed
#     left of x=321 or right of x=1433, so the usable text band is ~1112 px,
#     NOT the full 1224. Whether that ~56 px per side is a real inset clip
#     rectangle or just where the glyph cells happened to fall is NOT
#     established here - so 1112 is used as the budget, which is correct either
#     way (it is the widest span with observational support, and if the true
#     clip is wider then 22 is merely a little conservative, never unsafe).
#     On the mechanism: the three clipped lines do NOT fail the same way. The
#     29- and 30-char ones end in a genuine PARTIAL, pixel-clipped glyph flush
#     against the target edge (~1475-1480) - plain scissor clipping. The 26-char
#     one does not: it loses its leading "t" and trailing " a" WHOLE, clean
#     background either side, though modelling puts 30-60% of each of those
#     glyphs nominally inside the visible target. Something culls glyphs
#     entirely at a boundary tighter than the screen edge - most consistent with
#     a per-glyph "does this cell fit" test against a narrower rectangle,
#     plausibly the scrim (x 272..1465). Reproduced independently by an
#     adversarial reviewer using their own regressed advances (46.8/57.4 px).
#     Exact rule would need disassembly. This REINFORCES 22: it is a second,
#     independent route to "the safe zone is narrower than 1224 px". The
#     pass/fail boundary is bracketed by the observations in point 3, and that
#     bracket - not any model of the mechanism - is what 22 is derived from.
#  4. THE ARITHMETIC. 1112 px / 45.6 = 24.4 all-letter cells. With the realistic
#     ~1 space per 5 characters that is 22-23 chars. A space-heavy 22-char line
#     (18 letters + 4 spaces) needs ~1082 px - ~30 px clear each side. 23 needs
#     ~1128 px (marginal). 24 chars with 3 spaces needs ~1140 px and clips -
#     consistent with the 26-char line above already losing a glyph per side.
#     LIMIT OF THIS BUDGET, be honest about it (defect found by an adversarial
#     reviewer 2026-09-04): 22 is calibrated for NATURAL PROSE, roughly <=5
#     spaces in 22 characters. It is NOT a universal guarantee, because a space
#     costs ~1.4 cells: a pathological maximum-space line (11 letters + 11
#     spaces, e.g. "a b c d e f g h i j k") needs ~1150-1185 px and would still
#     clip the ~1112 px band. An earlier version of this note claimed that case
#     was safe by checking it against the 1224 px render target instead of the
#     1112 px band this same comment derives - wrong boundary, corrected here.
#     Nothing in this content class comes close (the widest space ratio in
#     either entry is 4 spaces in 21 chars), but if a future line ever does,
#     count PIXELS, not characters.
#  5. CROSS-CHECK: 22 is exactly LARGE_BOX_MAX_CHARS, derived independently from
#     real B1 screenshots of the ordinary dialog box. Two unrelated measurements
#     landing on the same number is the strongest confirmation available here,
#     and it kills the "the banner is wider" premise outright.
#
# Kept as its own named constant (rather than folded into LARGE_BOX_MAX_CHARS)
# because it is a genuinely different renderer with its own, separately-measured
# evidence - if the banner is ever found to differ, this is where it changes.
# Result at 22: the widest line either entry now emits is 21 characters (three
# of them tie at that width, one being "an ominous shadow was" itself) - i.e.
# nothing now renders wider than the widest line for which photographic proof of
# a complete render exists.
SMALL_BOX_MAX_CHARS = 16   # navi_intro's character-creation "decision boxes"
                           # (party size/gender/color/class/controller/mode/
                           # money/weeks/turn-order prompts) - owner-confirmed
                           # smaller than the main box, but NO real screenshot
                           # evidence exists yet for the exact safe width.
                           # THIS IS AN UNVERIFIED, DELIBERATELY CONSERVATIVE
                           # ESTIMATE, not an established fact like
                           # LARGE_BOX_MAX_CHARS - needs real playtesting to
                           # calibrate precisely. Do not treat as equally
                           # solid.

# --- VERTICAL capacity (2026-09-04) -----------------------------------------
# The horizontal fix above (wrap_line) turns one over-wide line into 2-3
# rendered lines. Nothing checked whether those lines still FIT the box, and
# they don't always: the owner's screenshot
# screenshots/Screenshot_20260904_032459.png caught 0x4ef530/0x4ef5c0
# (navi-intro-f1/f2) rendering a 4-line page - line 1 cropped off the top,
# line 4 cropped off the bottom.
#
# EVIDENCE the standard dialog box holds exactly 3 lines:
#  1. DIRECT PIXEL MEASUREMENT, two owner PCSX2 captures of the SAME box:
#       Screenshot_20260904_033144.png (JP, 1-line page): box tan fill spans
#         rows 965..1233 -> height 269 px; its single text row is centered on
#         row 1087 vs the box centre 1099 -> the text block is VERTICALLY
#         CENTERED in the box.
#       Screenshot_20260904_032459.png (EN, the broken 4-line page): box spans
#         rows 961..1229 -> height 269 px, IDENTICAL. So the box height is a
#         FIXED constant; it does NOT grow with line count. Its four text rows
#         sit at 957 / 1043 / 1130 / ~1217 -> line pitch 86-87 px. Row 1 starts
#         at 930, ABOVE the box top edge (961); row 4's ink is cut off at the
#         box bottom edge (1229). 3 lines span 2*86.5 + ~50 = ~223 px and fit
#         inside 269; 4 lines need ~310 px and cannot.
#  2. THE SHIPPED JP GAME NEVER EXCEEDS 3. Brute-scan of every decodable
#     0x2800..0xF800 stream in the original ELF (tools/audit_line_overflow.py's
#     rendered_pages() line-counting rule): 1696 streams, 2687 non-empty pages
#     -> 1-line 1023 (38%), 2-line 1178 (44%), 3-line 486 (18%), 4-or-more: ZERO.
#     3 is common, so it is definitely safe; 4 is used nowhere, in a 2687-page
#     sample, by the developers who designed the box.
#  3. CONFIRMED AT INSTRUCTION LEVEL by a raw-MIPS trace of the renderer
#     (2026-09-04, same methodology as skills/ADD-FONT-GLYPH.md's 0x2a3e00
#     trace). Native units, and the derivation is exact:
#       - Token dispatcher 0x2a2a60, jump table 0x5219f0 (31 dwords, indexed by
#         word>>11). type 1 LINE -> 0x2a2ac8, type 2 PAGE -> 0x2a2cd8,
#         type 5 HDR -> 0x2a3060, type 7 SPEAKER -> 0x2a3450.
#       - LINE handler 0x2a2ac8: `lui $v0,0x41f0` (= 30.0f) then
#         `pen_y += 30.0 * scale`. LINE PITCH = 30 px. Glyph cell = 24 px
#         (quad corner table 0x47D720 = {0,24, 0,0, 24,24, 24,0}).
#       - BOX HEIGHT IS A FIXED CREATE-TIME CONSTANT. The standard dialog
#         factory 0x2a1fb0 does `addiu $a3,$zero,116` and calls win_create
#         (0x27d0a0) with h=116; 51 of its 58 call sites take that default
#         rect. win_create derives the TEXT AREA as H - 32 (padding 10+10,
#         margin 6+6) -> 84. NOTHING in the text module (0x2a0000-0x2a9000)
#         ever writes win+0x20/+0x24, so the box never resizes to its text.
#         (Matches the pixel finding in 1: identical height for a 1-line and a
#         4-line page.)
#       - PAGE handler 0x2a2cd8 (byte-identical copy at 0x2a53a0 for the first
#         page) counts the LINE tokens ahead of it and then sets
#         `pen_y = (H - ((n-1)*30 + 24)*scale) / 2` - the block is VERTICALLY
#         CENTERED (the factory forces valign=1 at 0x2a2058). Confirms 1's
#         centering observation.
#       - The engine's own capacity formula, found independently at 0x277fc8:
#         `rows = floor((H - 24*s) / (30*s)) + 1`. For H=84, s=1 that is
#         floor(60/30)+1 = 3 EXACTLY, with ZERO SLACK. So 3 is not a
#         conservative estimate, it is the precise capacity.
#       - And it explains the screenshot exactly: at n=4,
#         pen_y = (84 - 114)/2 = -15, i.e. the block overflows SYMMETRICALLY
#         off the top AND the bottom - which is what row 1 above the box edge
#         and row 4 cut off at the bottom actually are.
LARGE_BOX_MAX_LINES = 3
SMALL_BOX_MAX_LINES = 3    # the character-creation "decision box" is the SAME
                           # physical box as the large one - confirmed in
                           # Screenshot_20260904_033144.png, which IS a decision
                           # prompt (a はい/いいえ list floats over the box's
                           # right side) and whose box measures the identical
                           # 269 px tall. Only the usable text WIDTH shrinks
                           # (hence SMALL_BOX_MAX_CHARS), not the height. The JP
                           # original never puts more than 2 lines in one of
                           # these, so 3 is the ceiling, not a demonstrated
                           # value - but it is the same box, so it cannot be
                           # LESS than the large box's 3.
JOB_DESCRIPTION_MAX_LINES = 7  # pool_b_gameplay/job-descriptions' own taller
# win_create window, MIPS-confirmed 2026-09-05: `addiu $a3,$zero,236` (h=236 ->
# n=7 under h=30n+26) appears at both real call sites (0x26d0a8, 0x355f98),
# each ~40 bytes before `jal 0x27d0a0` (win_create) - see
# docs/planning-log/2026-09-05-text-box-formulas.md. This is exactly the
# taller-window case box_max_lines()'s own docstring flagged as a KNOWN GAP
# ("job descriptions (7)... would be WRONGLY paginated down to 3") - mapped
# here now that this pool is being migrated. Width (max_chars) is NOT
# re-derived for this window - LARGE_BOX_MAX_CHARS is reused as an unverified
# placeholder only (the `win_create` `$a2` width argument at these same 2
# call sites was never read) - flagged, not fixed, in the same planning doc.
NARRATION_BANNER_MAX_LINES = 3  # the opening-narration banner (navi-intro-a/b).
# RE-VERIFIED 2026-09-04 alongside the NARRATION_BANNER_MAX_CHARS correction
# above, and it is UNCHANGED - the width recalibration produces more lines and
# therefore more auto-paginated pages, which is the safe direction, but it does
# not move the vertical budget.
#
# NOW DIRECTLY PHOTOGRAPHED, no longer inferred from the JP original alone: all
# three of the English captures listed under NARRATION_BANNER_MAX_CHARS are
# 3-line pages, and all three render their 3 lines COMPLETE - nothing cropped at
# top or bottom. Measured in Screenshot_20260904_042220.png:
#   scrim panel   y 482..819  (338 px tall)
#   text ink      y 552..771  (219 px: ascender top of row 1 to descender bottom
#                              of row 3), line pitch 84 px
#   clear margin  70 px above the block, 48 px below.
# A 4th line would add 84 px to a vertically-centred block (42 px each way),
# leaving ~6 px below the scrim edge. That MIGHT still draw - but the scrim is
# not the clip boundary (the render target is, see the width constant), the
# shipped JP game never puts more than 3 lines in this banner, and nothing in
# these captures exercises 4. So 3 stays: it is the demonstrated maximum, and
# the only number here with photographic proof behind it.


class EncodeError(ValueError):
    pass


CONTENT_KINDS = ("glyph", "page", "line", "space", "end")


def jp_prologue(jp_tokens):
    """The stream's leading run of self-contained state-setting control codes,
    i.e. every token before the first content token.

    Rewritten 2026-09-04 alongside dialog_codec.decode_structured()'s own
    prologue rewrite (see that module's "CORRECTION 2026-09-04 (b)" for the
    hand-disassembly). The prologue is NOT always "[hdr]" or "[hdr, speaker]":
    0x2800 is an ordinary self-contained state code, so real streams carry
    these words in whatever order the original authors emitted them, and one
    stream in the registry (0x4ef500) has no 0x2800 at all while another
    (0x458f20) opens on a bare 0x4001.

    Everything in here MUST be reproduced verbatim, in its original order, in
    any relocated copy - these words select the render style, the text colour
    and the speaker for the whole box. Dropping them (which emitting a bare
    0x2800 would do) silently changes how the box draws: 0x4ef2e0/0x4ef360
    would lose both the wide narration-banner style set by 0xa80a and the text
    colour set by 0xb007. The registry's own note on 0x4f1220 already spelled
    this requirement out ("Preserve this exact word+order verbatim in any
    relocated copy - do not normalize") before the mechanism was understood.
    """
    for n, t in enumerate(jp_tokens):
        if t["kind"] in CONTENT_KINDS:
            return jp_tokens[:n]
    return list(jp_tokens)


def jp_structure(jp_tokens):
    """Extract the two structural facts the EN encoder needs from a decoded
    JP token list: (initial_speaker_word_or_None, trailing_pause_bool)."""
    initial_speaker = None
    for t in jp_prologue(jp_tokens):
        if t["kind"] == "speaker":
            initial_speaker = t["word"]
            break
    end_idx = next(n for n, t in enumerate(jp_tokens) if t["kind"] == "end")
    trailing_pause = end_idx > 0 and jp_tokens[end_idx - 1]["kind"] == "page"
    return initial_speaker, trailing_pause


def box_max_chars(entry):
    """Classify a registry entry's dialog box size, owner-confirmed
    2026-09-04: navi_intro's character-creation "decision boxes" (party
    size/gender/name/color/class/controller/mode/money/weeks/turn-order
    prompts - `event` starting "charcreate", excluding the class-tooltip
    sub-set which is a DIFFERENT, not-yet-classified UI context) are a
    smaller box than the main narration/dialogue box; everything else
    checked so far (navi_intro's own narration, pool_b_gameplay,
    settings-option) uses the main large box. Returns the right max_chars
    value to pass into encode_stream()/encode_entry_from_elf()."""
    event = entry.get("event") or ""
    if event.startswith("charcreate") and "tooltip" not in event:
        return SMALL_BOX_MAX_CHARS
    if event in ("navi-intro-a", "navi-intro-b"):
        return NARRATION_BANNER_MAX_CHARS
    return LARGE_BOX_MAX_CHARS


def box_max_lines(entry):
    """Vertical twin of box_max_chars(): how many rendered lines this entry's
    box holds before text clips off the top/bottom edge. Same classification
    rule (deliberately - one box class, one pair of budgets), see the
    LARGE/SMALL/NARRATION_BANNER_MAX_LINES constants for the evidence behind
    each number.

    KNOWN GAP - TALLER WINDOW CLASSES EXIST. The 2026-09-04 MIPS trace resolved
    the height argument at all 160 win_create (0x27d0a0) call sites and found
    the game sizes windows on exactly `h = 30n + 26`: 56 (1 line), 86 (2),
    116 (3, the standard bottom message box, 8 sites), 146 (4), 176 (5),
    206 (6), 236 (7), 266 (8), 326 (10), 386 (12), 506 (16). Content that lives
    in one of the taller windows - the help manual (up to 11 lines), job
    descriptions (7), status/menu/discard panels (5-6) - would be WRONGLY
    paginated down to 3 by this function.

    That is latent, not live: verified 2026-09-04 that ZERO entries currently
    on disc and ZERO entries currently eligible for relocation belong to any
    taller class (the help pool does not even use LINE tokens - it positions
    with explicit type-27 0xd8xx pen-Y codes). Before extending this project to
    those pools, map the pool -> window class first and add the case here;
    do not let them fall through to the LARGE default."""
    event = entry.get("event") or ""
    if event.startswith("charcreate") and "tooltip" not in event:
        return SMALL_BOX_MAX_LINES
    if event in ("navi-intro-a", "navi-intro-b"):
        return NARRATION_BANNER_MAX_LINES
    if entry.get("chapter") == "job-descriptions":
        return JOB_DESCRIPTION_MAX_LINES
    return LARGE_BOX_MAX_LINES


def _strip_edge_punct(word, target, edge):
    """Match `target` against `word`, allowing non-alphanumeric punctuation
    directly attached on the given `edge` ("lead" or "trail") to fall OUTSIDE
    the match - e.g. target="Swarm" matches word="Swarm!" (edge="trail"),
    returning "!" as the outside punctuation; target="Swarm" against bare
    "Swarm" returns "". Returns None if `word` doesn't match at all (exact,
    or via a legal punctuation-attached variant).

    This mirrors how the JP source itself behaves: real occurrences (found
    2026-09-08 auditing the battle-messages/event-notification pools, e.g.
    "Wiwi Swarm!"/"the Plague." style entries) close the highlight code
    immediately after the highlighted WORD, with trailing sentence
    punctuation/copula sitting outside the wrap, uncoloured - so leaving
    attached punctuation outside the match is the semantically correct
    behaviour here, not just a parsing convenience."""
    if word == target:
        return ""
    if edge == "trail" and word.startswith(target):
        rest = word[len(target):]
        if rest and all(not c.isalnum() for c in rest):
            return rest
    if edge == "lead" and word.endswith(target):
        rest = word[:len(word) - len(target)]
        if rest and all(not c.isalnum() for c in rest):
            return rest
    return None


def _match_phrase_span(words, i, cand_tokens):
    """Try to match `cand_tokens` (a phrase's space-split tokens) starting at
    `words[i]`, tolerating attached leading punctuation on the phrase's FIRST
    word and attached trailing punctuation on its LAST word (see
    _strip_edge_punct()) - internal tokens of a multi-word phrase must match
    exactly, no tolerance (they're never sentence-boundary-adjacent).
    Returns (lead_punct, trail_punct) on a match, else None."""
    n = len(cand_tokens)
    if i + n > len(words):
        return None
    if n == 1:
        w = words[i]
        t = cand_tokens[0]
        if w == t:
            return "", ""
        lead = _strip_edge_punct(w, t, "lead")
        # lead-stripped remainder might ALSO carry trailing punctuation
        if lead is not None:
            return lead, ""
        trail = _strip_edge_punct(w, t, "trail")
        if trail is not None:
            return "", trail
        # both a leading AND trailing punctuation-attached remainder (rare,
        # e.g. "(Word)."): strip both ends explicitly
        core = w
        lead2 = ""
        while core and not core[0].isalnum():
            lead2 += core[0]
            core = core[1:]
        trail2 = ""
        while core and not core[-1].isalnum():
            trail2 = core[-1] + trail2
            core = core[:-1]
        if core == t:
            return lead2, trail2
        return None
    lead = _strip_edge_punct(words[i], cand_tokens[0], "lead")
    if lead is None:
        return None
    for k in range(1, n - 1):
        if words[i + k] != cand_tokens[k]:
            return None
    trail = _strip_edge_punct(words[i + n - 1], cand_tokens[-1], "trail")
    if trail is None:
        return None
    return lead, trail


def encode_label(text, rev, hl_wraps=None, hl_cursor=None, placeholder_map=None):
    """Word -> glyph words, space = glyph 0 between words. Raises EncodeError
    (not KeyError) naming the exact missing character, for a clear failure
    rather than an opaque traceback.

    `placeholder_map` (added 2026-09-08, for the positional-marker tier -
    see derive_en_positional_markup()): an optional `{char: (kind, word,
    payload_or_None)}` dict. Any character in `text` that is a key of this
    map is spliced as RAW BYTES (the control code word, plus its 8-byte
    payload for a `param8`-kind entry) instead of being looked up in `rev` -
    checked BEFORE the glyphmap lookup, so a placeholder character (always
    drawn from the Private-Use-Area, never a real glyph) can never collide
    with real content. Orthogonal to `hl_wraps`/`hl_cursor` (not combined in
    any real entry yet - see the module's 2026-09-08 planning-log entry for
    why that combination is an open, deliberately out-of-scope gap).

    `hl_wraps` (added 2026-09-04, for entries with a registry `inline_codes`
    list - e.g. 0x4efb40's Maconde, bracketed by 0xb001/0xb008 in the JP
    source): an optional list of `(exact_phrase, before_code, after_code)`
    triples. `exact_phrase` may be MULTIPLE space-separated words (generalized
    2026-09-08, for the mid-content hl-wraps-a-literal-PHRASE shape found at
    real scale in the battle-messages/event-notification pools - e.g.
    "Drag Down", "Bumper Harvest", "Roadblock Rock" - the original 2026-09-04
    version only matched a single token; a 1-word phrase behaves identically
    to that original behaviour, so this is purely additive). Consumed IN
    ORDER via the mutable `hl_cursor` 2-int list (`[next_unconsumed_index,
    overrun_count]`) - shared across every encode_label() call for one
    stream, so occurrence order across MULTIPLE lines/pages still matches
    jp's control-code-pair order end to end.

    Matching (generalized 2026-09-08 - see _match_phrase_span()/
    _strip_edge_punct()): a phrase matches a contiguous, in-order run of the
    text's own space-split tokens, tolerating punctuation attached directly
    to the phrase's outer edges (e.g. phrase "Swarm" matches the token
    "Swarm!", colouring only "Swarm" and leaving "!" outside/uncoloured -
    this matches the JP source's own real behaviour of closing the highlight
    right after the word, before any trailing punctuation/copula). Internal
    tokens of a multi-word phrase must match exactly. Once every wrap is
    consumed, any FURTHER occurrence of a target phrase increments
    `hl_cursor[1]` instead of silently going unwrapped - encode_stream()
    raises if this is ever nonzero, since a translation with MORE
    occurrences than the JP source's control-code count means the extra
    one(s) would ship with no colour code at all, silently wrong rather than
    caught."""
    words = text.split(" ")
    all_phrase_tokens = [w.split(" ") for w, _, _ in hl_wraps] if hl_wraps else []
    out = b""
    i = 0
    while i < len(words):
        wrap = None
        n_consumed = 1
        edge_punct = ("", "")
        if hl_wraps is not None:
            if hl_cursor[0] < len(hl_wraps):
                cand_phrase, before, after = hl_wraps[hl_cursor[0]]
                cand_tokens = cand_phrase.split(" ")
                m = _match_phrase_span(words, i, cand_tokens)
                if m is not None:
                    wrap = (before, after)
                    n_consumed = len(cand_tokens)
                    edge_punct = m
                    hl_cursor[0] += 1
            else:
                # every wrap already consumed - flag any FURTHER occurrence of
                # any known phrase (single- or multi-word) as an unwrapped
                # over-count, generalized from the original single-word check
                for cand_tokens in all_phrase_tokens:
                    if _match_phrase_span(words, i, cand_tokens) is not None:
                        hl_cursor[1] += 1
                        break
        # inter-word SPACE (glyph 0) must precede the wrap-open code, not
        # follow it - the ORIGINAL single-word implementation emitted the
        # space before deciding whether to wrap at all; a 2026-09-08 refactor
        # draft moved space-emission inside the per-token loop below (which
        # runs AFTER wrap[0] is emitted) and was caught by a real byte-level
        # regression against 0x4efb40's own already-shipped disc bytes
        # ("sorcerer{{HL:}} Maconde" instead of the real "sorcerer {{HL:}}
        # Maconde") - fixed by keying the space strictly on stream position
        # (i > 0), emitted before any wrap code, exactly once per token.
        if i > 0:
            out += struct.pack("<H", 0)
        lead_punct, trail_punct = edge_punct
        if lead_punct:
            for c in lead_punct:
                if c not in rev:
                    raise EncodeError(f"encode_label: character {c!r} has no glyphmap entry")
                out += struct.pack("<H", rev[c])
        if wrap:
            out += struct.pack("<H", wrap[0])
        for j in range(n_consumed):
            if j > 0:
                out += struct.pack("<H", 0)
            word = words[i + j]
            if j == 0 and lead_punct:
                word = word[len(lead_punct):]
            if j == n_consumed - 1 and trail_punct:
                word = word[:len(word) - len(trail_punct)]
            for c in word:
                if placeholder_map is not None and c in placeholder_map:
                    pkind, pword, ppayload = placeholder_map[c]
                    out += struct.pack("<H", pword)
                    if pkind == "param8":
                        if ppayload is None:
                            raise EncodeError(
                                f"encode_label: placeholder for param8 code "
                                f"{pword:#06x} has no payload bytes")
                        out += ppayload
                    continue
                if c not in rev:
                    raise EncodeError(f"encode_label: character {c!r} has no glyphmap entry")
                out += struct.pack("<H", rev[c])
        if wrap:
            out += struct.pack("<H", wrap[1])
        if trail_punct:
            for c in trail_punct:
                if c not in rev:
                    raise EncodeError(f"encode_label: character {c!r} has no glyphmap entry")
                out += struct.pack("<H", rev[c])
        i += n_consumed
    return out


def _visible_len(s, zero_width_chars=None):
    """len(s), minus any character that is a member of `zero_width_chars`.

    Added 2026-09-08 for the positional-marker tier's Private-Use-Area
    placeholder characters (see derive_en_positional_markup()): a placeholder
    standing in for an `hl` code draws nothing (it only changes renderer
    colour state, same as the ALREADY-established convention that
    derive_en_hl_markup()'s stripped `{{HL:xxxx}}` markup counts as 0 width
    once removed from the text passed to wrap_line()) - so it must not count
    against the character budget any more than the literal markup text would
    have. `zero_width_chars=None`/empty is a pure no-op (`len(s)`), so every
    pre-2026-09-08 caller is unaffected."""
    if not zero_width_chars:
        return len(s)
    return len(s) - sum(1 for c in s if c in zero_width_chars)


def wrap_line(text, max_chars, zero_width_chars=None):
    """Greedy word-wrap: split `text` into sub-lines each <= max_chars visible
    characters, breaking only at spaces (never mid-word - this project's own
    precedent for a genuinely too-long single word is a manual hyphenation
    fix, e.g. "Se-cret!", not automatic mid-word splitting). A single word
    longer than max_chars on its own is left whole (returned as its own
    sub-line, still over budget) rather than mangled - the caller should
    treat that as a real finding needing a human look, not silently accept
    it. Returns a list of 1+ sub-line strings.

    Found 2026-09-04: the renderer does NOT auto-wrap (established via real
    PCSX2 screenshots during the original B1 patch, see
    tools/patch_prologue.py's own comments) - every EN string this project
    ever writes into a dialog box MUST respect this or text clips off the
    box edge, confirmed as a real, live regression when Phase 3's newly-
    relocated navi_intro content shipped without this check. This function
    is the safety net: it runs even if a drafted `en` field's own `|`
    placement didn't already respect the limit.

    `zero_width_chars` (2026-09-08): see _visible_len() - width accounting
    only, never affects where a break can legally land (still one space per
    word gap).
    """
    words = text.split(" ")
    lines = []
    cur = []
    cur_len = 0
    for w in words:
        wl = _visible_len(w, zero_width_chars)
        add_len = wl + (1 if cur else 0)
        if cur and cur_len + add_len > max_chars:
            lines.append(" ".join(cur))
            cur = [w]
            cur_len = wl
        else:
            cur.append(w)
            cur_len += add_len
    if cur:
        lines.append(" ".join(cur))
    return lines or [""]


def layout_page_lines(page_text, max_chars=None, zero_width_chars=None):
    """The rendered line list for ONE EN page's text: the translator's own `|`
    breaks, each additionally word-wrapped if it exceeds `max_chars` (see
    wrap_line()) - a safety net on top of whatever breaks the translator
    already chose, never a replacement for them (existing breaks are never
    merged back together).

    Split out of encode_page_text() 2026-09-04 so callers can count the lines
    a page will actually render to BEFORE any bytes are emitted - that count
    is what the vertical-capacity check (see paginate_lines()) needs, and
    single-sourcing it keeps what a tool reports and what the encoder emits
    from ever disagreeing.

    `zero_width_chars` (2026-09-08): see _visible_len()/wrap_line()."""
    lines = []
    for line in page_text.split("|"):
        line = line.strip()
        if max_chars is not None and _visible_len(line, zero_width_chars) > max_chars:
            lines.extend(wrap_line(line, max_chars, zero_width_chars))
        else:
            lines.append(line)
    return lines


def paginate_lines(lines, max_lines=None):
    """Chunk a page's rendered lines into groups of at most `max_lines`, i.e.
    into as many real PAGE (0x1000) boxes as the text actually needs.

    This is the vertical counterpart to wrap_line(): where wrap_line() turns
    an over-wide line into more lines, this turns an over-tall page into more
    pages. PAGINATE, DO NOT CROP - the failure mode being fixed here is a page
    whose first and last lines were silently cut off by the box edges
    (screenshots/Screenshot_20260904_032459.png), which is strictly worse than
    one extra button press.

    Chunking is GREEDY and never splits a line: every break therefore lands on
    a boundary the translator wrote (`|`) or that wrap_line() chose, never
    mid-line. `max_lines=None` disables pagination entirely (returns one
    chunk), preserving the pre-2026-09-04 behaviour for any caller that wants
    it.
    """
    lines = list(lines) or [""]
    if max_lines is None:
        return [lines]
    if max_lines < 1:
        raise EncodeError(f"paginate_lines: max_lines must be >= 1, got {max_lines}")
    return [lines[i:i + max_lines] for i in range(0, len(lines), max_lines)]


# --- WHERE to split an over-tall page (2026-09-04, second pass) --------------
# paginate_lines() above (the first pass) chunks GREEDILY: fill page 1 to the
# 3-line brim, dump whatever is left onto page 2. It fixes the cropping bug and
# is byte-neutral, but the owner reviewed the result in real PCSX2 play and
# rejected the SPLIT POINTS it picks:
#
#   "It's quite awkward, try to split them up by sentence or splitting a
#    dialogue box in half (retaining full words of course). We have boxes that
#    are sometimes just one or two words."
#
# Real examples from the 10 entries the greedy pass had already re-patched:
#   0x4ef980 page 1  "This side, where I / live, / is called the Dokapon"
#                    then a whole box holding only "Kingdom."
#   0x4f00f0         "An unconnected / controller / has been"  +  "selected!"
#   0x47ea00         ".../ Choose which field"  +  "magic to throw away."
# In every one of those the text has an obvious better break (a sentence end,
# or the translator's own `|`) that the greedy fill walked straight past.
#
# WHAT MAKES A SPLIT GOOD - the rules chosen here, and why:
#
#  1. A ONE-LINE PAGE IS NOT ITSELF THE BUG. The shipped JP game renders 1023
#     of its 2687 pages (38%) as a single line - see the brute-scan cited under
#     LARGE_BOX_MAX_LINES. What reads badly is a one-line page that is a
#     mid-sentence FRAGMENT ("magic to throw away.", "Kingdom.", "selected!").
#     So the primary term is not "balance" but WHERE THE CUT LANDS, and a
#     complete short sentence alone in a box stays allowed.
#  2. Cut preference, cheapest first: a SENTENCE end (. ! ? ...) beats the
#     translator's own `|` line break, which beats a clause mark (, ; :), which
#     beats a bare word gap. The translator's `|` ranks high because it is a
#     deliberate human phrasing decision, not a wrap artifact; it ranks below a
#     sentence end because a sentence end is the stronger semantic boundary.
#  3. Balance is the SECONDARY term, exactly as the owner phrased it ("or
#     splitting a dialogue box in half"): squared deviation of each page's line
#     count from the even share. Weighted so it decides between two equally
#     good cut kinds, and so a `|`-aligned even split can outrank a
#     sentence-aligned lopsided one, but so that it can never justify cutting
#     mid-sentence at a bare word gap. That is the "don't split absurdly early
#     just to hit a period" guard, expressed as a cost rather than a window:
#     an early sentence cut pays the imbalance it causes.
#  4. WORDS ARE NEVER SPLIT. Cuts only ever land in the gap between two words,
#     so wrap_line()'s word-boundary guarantee is untouched.
#  5. PAGE COUNT NEVER GROWS. The search is run at exactly the page count the
#     greedy pass would have used (ceil(lines / max_lines)); the greedy split
#     is always itself a legal candidate in the search space, so that count is
#     always reachable. The player never pays an extra button press for a
#     prettier break.
#
# BYTE-NEUTRALITY (why re-splitting is safe on already-patched entries).
# The encoded length is invariant under ANY re-choice of split points, and the
# reason is exact, not empirical: every gap between two consecutive words in a
# page becomes exactly one 16-bit word in the stream - a glyph-0 space if the
# gap stays inside a line, a LINE (0x0800) if it becomes a line break, a PAGE
# (0x1000) if it becomes a page break. Moving a break just relabels which kind
# of word a given gap emits. Since rule 5 keeps the page COUNT fixed too, the
# total word count (and so the byte length) cannot change. Verified empirically
# across the whole eligible set as well - see the regression run in
# docs/planning-log/2026-09-04-vertical-line-capacity.md.

# Cut-site costs, cheapest = most desirable. Absolute values only matter
# relative to each other and to BALANCE_WEIGHT below.
CUT_COST_SENTENCE = 0   # after . ! ? or ... - the strongest boundary
CUT_COST_HARDLINE = 1   # at a `|` the translator wrote themselves
CUT_COST_CLAUSE = 4     # after , ; : - or an em/en dash
CUT_COST_WORD = 9       # a bare word gap: last resort, mid-sentence
# How much one line of imbalance is worth against those. At 2.0, a lopsided
# 3+1 sentence cut (cost 0 + 2*(1+1) = 4) loses to an even 2+2 cut at a `|`
# (1 + 0 = 1) but still beats an even 2+2 cut at a bare word gap (9 + 0 = 9).
BALANCE_WEIGHT = 2.0

_TERMINAL_PUNCT = ".!?…"          # full stop, bang, query, ellipsis glyph
_CLAUSE_PUNCT = ",;:—–"           # comma, semicolon, colon, em dash, en dash
_TRAILING_CLOSERS = "\"')]}»”’"   # quotes/brackets sitting AFTER the mark


def _cut_cost(prev_word, next_word, next_starts_block):
    """How good a page break in the gap between `prev_word` and `next_word` is
    (lower = better). `next_starts_block` says the gap is one of the
    translator's own `|` breaks.

    The sentence test deliberately requires the following word NOT to start
    with a lowercase letter. That is what keeps a trailing-off ellipsis in the
    MIDDLE of a sentence ("well... anyway") from being mistaken for a sentence
    end, and it costs nothing real: an English sentence practically never
    starts lowercase, while "...Huh?"-style leading ellipses still pass (they
    start with '.', not a lowercase letter)."""
    w = prev_word.rstrip(_TRAILING_CLOSERS)
    # NB `w[-1:]`, and the explicit `tail and` guards below: for an empty word
    # `tail` is "", and `"" in ".!?"` is True in Python - a silently wrong
    # "sentence end" on every empty atom without them.
    tail = w[-1:]
    if tail and tail in _TERMINAL_PUNCT and not next_word[:1].islower():
        cost = CUT_COST_SENTENCE
    elif tail and tail in _CLAUSE_PUNCT:
        cost = CUT_COST_CLAUSE
    else:
        cost = CUT_COST_WORD
    if next_starts_block:
        cost = min(cost, CUT_COST_HARDLINE)
    return cost


def _page_atoms(page_text):
    """Flatten one page's text into (block_index, word) atoms in reading order.

    Blocks are the translator's `|`-separated segments, stripped exactly the
    way layout_page_lines() strips them, and split on a literal single space so
    that rejoining any contiguous run of atoms reproduces the original text
    character-for-character (a double space survives as an empty-string atom,
    which _split_positions() then refuses to cut next to - see there)."""
    atoms = []
    for bi, block in enumerate(page_text.split("|")):
        for word in block.strip().split(" "):
            atoms.append((bi, word))
    return atoms


def _atoms_text(atoms):
    """Rejoin a contiguous atom run back into `|`-separated page text."""
    parts = []
    cur_bi = None
    for bi, word in atoms:
        if bi != cur_bi:
            parts.append([word])
            cur_bi = bi
        else:
            parts[-1].append(word)
    return "|".join(" ".join(p) for p in parts)


def _split_positions(atoms):
    """Every atom index a page break may legally be placed BEFORE.

    Everything is cuttable EXCEPT an INSIDE-A-BLOCK gap that touches an
    empty-string atom. Such an atom comes from a double space, and that gap is
    the one place where cutting would NOT be byte-neutral: the block strip() on
    each side of the cut swallows the extra space glyph the uncut text emits
    (`"a  b"` is 4 stream words; `"a"` + PAGE + `"b"` is only 3). A gap at a
    BLOCK boundary is always cuttable even next to an empty atom, because that
    gap already emits a separator word - the cut only changes it from LINE to
    PAGE - and refusing those was found (2026-09-04) to make the minimum page
    count unreachable on `||` texts, which silently added a whole extra box.
    Only 8 of the registry's 3589 entries contain such text at all, and none of
    them are in a paged dialog box, so this is robustness, not a live fix."""
    return [i for i in range(1, len(atoms))
            if atoms[i][0] != atoms[i - 1][0]
            or (atoms[i - 1][1] != "" and atoms[i][1] != "")]


def plan_page_chunks(page_text, max_chars=None, max_lines=None, zero_width_chars=None):
    """Split ONE EN page's text into the list of per-box rendered-line lists it
    needs, choosing the split points by meaning and balance rather than by
    greedy fill. Returns a list of line-lists, one per real PAGE box.

    Byte-for-byte identical to the old greedy behaviour whenever the page
    already fits (`max_lines is None`, or the page renders within budget) -
    which is the overwhelmingly common case, and the reason a translator's own
    `//`-authored pages are never touched or re-flowed by this.

    `zero_width_chars` (2026-09-08): see _visible_len()/wrap_line() - threaded
    through so a page containing positional-marker placeholder characters
    still measures/splits by VISIBLE width, not raw character count.

    See the block comment above for the cost model and its justification."""
    base = layout_page_lines(page_text, max_chars, zero_width_chars)
    if max_lines is None:
        return [base]
    if max_lines < 1:
        raise EncodeError(f"plan_page_chunks: max_lines must be >= 1, got {max_lines}")
    if len(base) <= max_lines:
        return [base]

    atoms = _page_atoms(page_text)
    n = len(atoms)
    cuts_allowed = _split_positions(atoms)
    if not cuts_allowed:
        # nothing may be cut (degenerate text) - fall back rather than crop
        return paginate_lines(base, max_lines)

    line_cache = {}

    def span_lines(i, j):
        key = (i, j)
        if key not in line_cache:
            line_cache[key] = layout_page_lines(_atoms_text(atoms[i:j]), max_chars, zero_width_chars)
        return line_cache[key]

    cut_cost = {}
    for c in cuts_allowed:
        cut_cost[c] = _cut_cost(atoms[c - 1][1], atoms[c][1],
                                atoms[c][0] != atoms[c - 1][0])

    n_pages = -(-len(base) // max_lines)   # ceil; the greedy pass's page count

    def best_arrangement(k_pages):
        """Cheapest legal way to cut the page into exactly `k_pages` boxes
        under the full cost model, or None if no such cut exists.

        The balance term is sum((L_i - mean)**2), which is NOT additive over
        boxes because `mean` depends on the solution's own TOTAL line count.
        It is made additive by fixing that total: for a solution with total
        T lines over K boxes, sum((L_i - T/K)**2) == sum(L_i**2) - T*T/K, and
        sum(L_i**2) IS additive. So the DP carries T as part of its state and
        the -T*T/K correction is applied once at the end, per candidate T.
        That makes the search exact (no heuristic pruning) and polynomial:
        states are (atom index) x (boxes left) x (lines used so far), which for
        a real page is a few thousand at most.

        T is bounded above by k_pages * max_lines (the boxes' own capacity) and
        below by len(base) (greedy wrapping minimises line count, so no cut
        arrangement can ever use fewer lines than the uncut page does)."""
        t_max = k_pages * max_lines
        INF = float("inf")
        # dp[(i, k, t)] -> (cut_cost_sum + BALANCE_WEIGHT * sum(L**2), cuts)
        memo = {}

        def rec(i, k, t_left):
            key = (i, k, t_left)
            hit = memo.get(key)
            if hit is not None:
                return hit
            if k == 1:
                lines = span_lines(i, n)
                L = len(lines)
                res = ((BALANCE_WEIGHT * L * L, []) if L <= max_lines and L == t_left
                       else (INF, None))
                memo[key] = res
                return res
            acc = (INF, None)
            for c in cuts_allowed:
                if c <= i:
                    continue
                head = span_lines(i, c)
                L = len(head)
                if L > max_lines:
                    # wrapping is monotone in text length: once this head is
                    # too tall, every later cut point is too
                    break
                if L >= t_left:
                    continue
                sub_cost, sub_cuts = rec(c, k - 1, t_left - L)
                if sub_cuts is None:
                    continue
                cost = cut_cost[c] + BALANCE_WEIGHT * L * L + sub_cost
                # `<=`, not `<`: cuts_allowed is ascending, so this keeps the
                # LATEST cut among equally-scoring ones - which is exactly the
                # old greedy fill's choice (the last gap that still leaves a
                # legal head is the end of line `max_lines`). Ties are genuine
                # coin flips, and resolving them the greedy way means an
                # already-patched entry is only ever re-flowed when the new
                # model actually scores its split BETTER, never merely
                # differently. Two real entries (0x4ef2e0, 0x4ef360) changed
                # for no quality gain before this tie-break was added.
                if cost <= acc[0]:
                    acc = (cost, [c] + sub_cuts)
            memo[key] = acc
            return acc

        best = None
        for t in range(len(base), t_max + 1):
            cost, cuts = rec(0, k_pages, t)
            if cuts is None:
                continue
            cost -= BALANCE_WEIGHT * t * t / k_pages
            if best is None or cost < best[0]:
                best = (cost, cuts)
        return best

    chosen = None
    k = n_pages
    while chosen is None and k <= len(base):
        chosen = best_arrangement(k)
        if chosen is None:
            k += 1
    if chosen is None:
        # Should be unreachable (the greedy split is always a legal candidate
        # at k = n_pages), but never crop or drop text if it somehow is.
        return paginate_lines(base, max_lines)

    bounds = [0] + chosen[1] + [n]
    return [span_lines(bounds[t], bounds[t + 1]) for t in range(len(bounds) - 1)]


def encode_lines(lines, rev, hl_wraps=None, hl_cursor=None, placeholder_map=None):
    """Encode an already-laid-out list of rendered lines, joined by LINE
    (0x0800). No wrapping, no pagination - the caller has already decided
    exactly what goes on screen. See encode_label() for
    `hl_wraps`/`hl_cursor`/`placeholder_map`."""
    out = b""
    for i, line in enumerate(lines):
        if i:
            out += struct.pack("<H", dc.LINE)
        out += encode_label(line.strip(), rev, hl_wraps, hl_cursor, placeholder_map)
    return out


def encode_page_text(page_text, rev, max_chars=None):
    """One EN page's text, `|`-split into lines joined by LINE (0x0800), with
    `max_chars` word-wrapping applied. Emits exactly one page's worth of bytes
    - it does NOT paginate, so a caller using this directly is responsible for
    the vertical budget itself (encode_stream() is the paginating path). Kept
    with its original signature and behaviour for backward compatibility."""
    return encode_lines(layout_page_lines(page_text, max_chars), rev)


def plan_stream_pages(en_text, max_chars=LARGE_BOX_MAX_CHARS,
                      max_lines=LARGE_BOX_MAX_LINES, zero_width_chars=None):
    """The exact page/line layout encode_stream() will emit, without encoding
    anything: a list of (page_speaker_or_None, is_auto_inserted, [lines]) in
    stream order. `is_auto_inserted` marks a page this function created purely
    to satisfy the vertical budget (i.e. one the translator did not write a
    `//` for). Exposed so tools can report and review the split before any
    bytes are written.

    The translator's own `//` pages are always honoured one-for-one; only a
    page that does not FIT is split further, and where that split lands is
    chosen by plan_page_chunks() (sentence boundary first, then the
    translator's own `|`, then balance) rather than by greedy fill.

    `zero_width_chars` (2026-09-08): see _visible_len()/wrap_line()."""
    out = []
    for pi, page_raw in enumerate(en_text.split("//")):
        m = SPK_TAG_RE.match(page_raw)
        page_speaker = int(m.group(1), 16) if m else None
        page_text = page_raw[m.end():] if m else page_raw
        chunks = plan_page_chunks(page_text, max_chars, max_lines, zero_width_chars)
        for ci, chunk in enumerate(chunks):
            out.append((page_speaker if ci == 0 else None, ci > 0, chunk))
    return out


EN_HL_TAG_RE = re.compile(r"\{\{HL:(0x[0-9a-fA-F]+)\}\}")
EN_PARAM_ICON_TAG_RE = re.compile(r"\{\{(?:PARAM|ICON):0x[0-9a-fA-F]+\}\}")


class MarkupMismatch(ValueError):
    """Raised by derive_en_hl_markup() when en_text's {{HL:xxx}} marker
    sequence doesn't structurally match the JP source's own hl-code
    sequence - the caller must treat the entry as ineligible for this
    encoding path (skip it), never force it through anyway."""
    pass


def derive_en_hl_markup(en_text, jp_tokens):
    """Markup-aware tier (2026-09-08): parses `en_text` for literal
    `{{HL:0xNNNN}}` markers - this project's own established registry
    convention for recording exactly where a translator intends an inline
    text-colour wrap to land (e.g. 0x4efb40 "Maconde", 0x4e7ee0 "Bumper
    Harvest" - dozens of entries already carry this convention in `en`, put
    there by an earlier authoring pass, but never consumed by any encoder:
    encode_stream() has always hard-refused any en text containing "{{").

    Structural validation (the safety net - never trusts en's markers
    blind): the FULL, in-order sequence of hl-code VALUES found anywhere in
    the real JP token stream (both jp_prologue()'s own leading run AND the
    content that follows it - the boundary between the two is NOT load-
    bearing here, see below) must equal en_text's own in-order marker-value
    sequence EXACTLY. If it doesn't - wrong count, wrong values, wrong
    order, an odd (unpaired) count, an empty phrase between two adjacent
    markers, or any {{ICON:}}/{{PARAM:}} marker mixed in - this raises
    MarkupMismatch and the caller must not use this path for the entry.

    Why the prologue/content boundary doesn't matter here: jp_prologue()
    classifies a LEADING hl token as "prologue" purely because it is not a
    CONTENT_KINDS token, even when - as happens for a large real class in
    the battle-messages/event-notification pools - that hl is genuinely
    OPENING a wrap around the very first translated word (e.g. 0x457c10's
    JP stream is bare hl(0xb002), 3 glyphs, hl(0xb008), more glyphs, END -
    no HDR, no speaker at all). Letting the standard encode_stream()
    machinery reproduce jp_prologue() verbatim AND ALSO letting hl_wraps
    re-emit that same leading hl code would double it. So this function does
    the opposite of relying on that boundary: it returns a JP TOKEN LIST
    with every LEADING hl token stripped out entirely (so the caller's
    downstream jp_prologue() computes a hl-free prologue, verbatim-emitting
    only genuine structural codes - hdr/speaker/setup/pen0/icon), and folds
    EVERY hl code (prologue-classified or not) into `hl_wraps` instead,
    positioned exactly where en_text's own markers say, via encode_label()'s
    existing (now phrase-capable) wrap mechanism. Net effect: byte-identical
    reproduction of the JP's real hl-code positions and values, driven
    entirely by en_text's own already-authored markup, with zero risk of a
    duplicated code.

    Returns (clean_en_text, filtered_jp_tokens, hl_wraps):
      - clean_en_text: en_text with every `{{HL:0xNNNN}}` marker removed
        (plain text, ready for the normal wrap_line()/paginate_lines()
        pipeline - no residual "{{" substring, so it will not trip
        encode_stream()'s own guard).
      - filtered_jp_tokens: jp_tokens with leading (prologue-classified) hl
        tokens removed - pass this to encode_stream(), not the original
        jp_tokens.
      - hl_wraps: a list of (phrase, before_code, after_code) triples, in
        stream order, ready to pass straight into encode_stream()'s own
        `hl_wraps` parameter.
    """
    if EN_PARAM_ICON_TAG_RE.search(en_text):
        raise MarkupMismatch(
            "derive_en_hl_markup: en_text contains a {{PARAM:}}/{{ICON:}} "
            "marker - out of scope for this function (belongs to the "
            "separate icon-substitution/prologue-verbatim mechanism)")

    jp_hl_full = [t["word"] for t in jp_tokens if t["kind"] == "hl"]
    if not jp_hl_full:
        raise MarkupMismatch("derive_en_hl_markup: JP source has no hl codes at all")
    if len(jp_hl_full) % 2 != 0:
        raise MarkupMismatch(
            f"derive_en_hl_markup: JP source has an odd number of hl codes "
            f"({len(jp_hl_full)}) - not a clean open/close-pair shape")

    markers = list(EN_HL_TAG_RE.finditer(en_text))
    en_hl_vals = [int(m.group(1), 16) for m in markers]
    if en_hl_vals != jp_hl_full:
        raise MarkupMismatch(
            f"derive_en_hl_markup: en_text hl-marker sequence "
            f"{[hex(v) for v in en_hl_vals]} != JP source's own hl-code "
            f"sequence {[hex(v) for v in jp_hl_full]}")

    hl_wraps = []
    clean_parts = []
    cursor = 0
    for k in range(0, len(markers), 2):
        m_open, m_close = markers[k], markers[k + 1]
        clean_parts.append(en_text[cursor:m_open.start()])
        phrase = en_text[m_open.end():m_close.start()]
        if phrase == "":
            raise MarkupMismatch(
                f"derive_en_hl_markup: empty phrase between consecutive "
                f"markers at en_text offset {m_open.end()} - nothing to wrap")
        clean_parts.append(phrase)
        before, after = jp_hl_full[k], jp_hl_full[k + 1]
        hl_wraps.append((phrase, before, after))
        cursor = m_close.end()
    clean_parts.append(en_text[cursor:])
    clean_en_text = "".join(clean_parts)
    if "{{" in clean_en_text:
        raise MarkupMismatch(
            "derive_en_hl_markup: residual '{{' left in clean_en_text after "
            "stripping markers - unexpected marker shape, refusing to guess")

    n_pro = len(jp_prologue(jp_tokens))
    filtered_jp_tokens = [t for i, t in enumerate(jp_tokens)
                          if not (i < n_pro and t["kind"] == "hl")]

    return clean_en_text, filtered_jp_tokens, hl_wraps


def derive_en_prologue_markup(en_text, jp_tokens):
    """Prologue-echo tier (2026-09-08): the sibling case to
    derive_en_hl_markup() for entries whose disqualifying hl/icon codes sit
    ENTIRELY inside jp_prologue() - a structurally EASIER shape (the codes
    never need repositioning relative to translated words, because
    jp_prologue()'s existing verbatim-reproduction in encode_stream() already
    emits them exactly as-is) but with a real, non-mechanical constraint:
    encode_stream() always emits the prologue tokens FIRST, unconditionally,
    before any page/line content - so whatever value an icon/PARAM code in
    the prologue substitutes at runtime ALWAYS renders at the very front of
    the box. There is no way to reposition it with this encoder (that would
    need the same kind of content-position machinery hl_wraps provides for
    mid-content hl, generalized to standalone substitution codes - not built,
    see docs/planning-log/2026-09-08-markup-aware-migration.md's "Outstanding"
    section).

    This function therefore does NOT attempt to reposition anything. It only
    recognizes the case where en_text's OWN wording already commits to
    value-first phrasing - i.e. en_text is LITERALLY the same
    {{HL:0xNNNN}}/{{PARAM:0xNNNN}} notation jp_prologue() itself produces,
    as an exact prefix, immediately followed by the rest of the sentence -
    and mechanically strips that known, already-reproduced-elsewhere prefix
    so the remainder can go through the ordinary plain encoder unmodified.

    Precedent (established 2026-09-07, before this function existed - see
    build_expected_prefix() in Git a55731d5's
    tools/migrate_charcreate_gap_2026-09-07e.py, now retired): 0x4efeb0/0x4efdf0/
    0x4f0000, all 3 already shipped, all 3 chose EN wording with the
    substituted value first ("[Name], what job will you take?",
    "[Ordinal]. Hero...").

    Raises MarkupMismatch (fail-safe, never guesses) if:
      - the prologue has no hl/icon token at all (nothing to strip - this
        entry doesn't belong to this shape, route it elsewhere);
      - any DISQUALIFYING kind (hl/icon/pen0/param8/setup) appears in
        CONTENT (past the prologue) - this function only ever handles codes
        fully inside the prologue, never a mid-content one;
      - the prologue contains a pen0/param8/setup token - out of scope (no
        established {{...}} en-text notation exists for pen0/setup, and
        param8 additionally carries an 8-byte payload that the prologue-
        verbatim emission silently drops - see the 0x47c600 finding in the
        same planning doc - so even a param8-only-in-prologue entry must not
        go through this path);
      - en_text does not start with the EXACT notation the real prologue
        tokens produce, in order - this is a translation/word-order
        decision (the substituted value would need to render at the very
        front of the box under the current encoder), not a mechanical fix;
        refusing to guess at new wording is deliberate.

    Prefix stops right after the LAST icon token, not the full prologue
    (re-derived 2026-09-08 from the shipped precedent's own real bytes - an
    earlier draft of this function required the trailing hl-CLOSE code to be
    echoed too and it failed round-trip validation against all 3
    already-shipped entries; build_expected_prefix() in the 07e script never
    required it either - it `break`s immediately after appending its one
    icon token, though that script only ever saw a single-icon shape). A
    trailing hl-close with nothing after it in the prologue needs no en-side
    notation: it is reproduced verbatim regardless (this function never
    modifies jp_tokens, unlike derive_en_hl_markup - the caller passes the
    ORIGINAL jp_tokens straight to encode_stream(), whose own jp_prologue()
    call reproduces the ENTIRE real prologue exactly, independent of how much
    of it this function required en_text to spell out). If the prologue has
    NO icon token at all (pure hl, nothing to substitute), this shape doesn't
    apply - that is derive_en_hl_markup()'s job (it can reposition a pure hl
    pair mid-content; this function never repositions anything).

    Returns (stripped_en_text, expected_prefix) - stripped_en_text is ready
    for encode_stream()/encode_entry_from_elf() against the UNMODIFIED
    jp_tokens; expected_prefix is returned only for logging/registry-note
    purposes.
    """
    disqualifying = {"hl", "icon", "pen0", "param8", "setup"}
    prologue = jp_prologue(jp_tokens)
    content_kinds = {t["kind"] for t in jp_tokens[len(prologue):]} & disqualifying
    if content_kinds:
        raise MarkupMismatch(
            f"derive_en_prologue_markup: disqualifying kind(s) "
            f"{sorted(content_kinds)} found in CONTENT (past the "
            f"{len(prologue)}-word prologue) - this function only handles "
            f"codes fully inside the prologue, route this entry through the "
            f"markup-aware mid-content tier instead")

    if not any(t["kind"] == "icon" for t in prologue):
        raise MarkupMismatch(
            "derive_en_prologue_markup: prologue has no icon (substitution) "
            "token - nothing to strip here; a pure-hl prologue belongs to "
            "derive_en_hl_markup() instead, which can reposition it "
            "mid-content rather than requiring value-first wording")

    last_icon_idx = max(i for i, t in enumerate(prologue) if t["kind"] == "icon")
    parts = []
    for t in prologue[:last_icon_idx + 1]:
        if t["kind"] == "hl":
            parts.append(f"{{{{HL:{t['word']:#06x}}}}}")
        elif t["kind"] == "icon":
            parts.append(f"{{{{PARAM:{t['word']:#06x}}}}}")
        elif t["kind"] in ("pen0", "param8", "setup"):
            raise MarkupMismatch(
                f"derive_en_prologue_markup: prologue contains a "
                f"{t['kind']!r} token before its last icon - out of scope "
                f"(only hl/icon have an established {{{{...}}}} en-text "
                f"notation; pen0/setup have none, and param8 additionally "
                f"carries an 8-byte payload the prologue-verbatim emission "
                f"silently drops)")
        # hdr/speaker/other structural kinds carry no {{...}} notation

    expected_prefix = "".join(parts)
    if not en_text.startswith(expected_prefix):
        raise MarkupMismatch(
            f"derive_en_prologue_markup: en_text does not start with the "
            f"expected prologue-echo prefix {expected_prefix!r} - this is a "
            f"word-order/translation decision, not a mechanical fix; "
            f"refusing to guess at new wording")
    stripped = en_text[len(expected_prefix):]
    if "{{" in stripped:
        raise MarkupMismatch(
            "derive_en_prologue_markup: residual '{{' left in en_text after "
            "stripping the known prologue-echo prefix - unexpected extra "
            "markup, refusing to guess")
    return stripped, expected_prefix


def encode_prologue_echo_stream(en_text, jp_tokens, rev,
                                max_chars=LARGE_BOX_MAX_CHARS,
                                max_lines=LARGE_BOX_MAX_LINES):
    """Convenience wrapper around derive_en_prologue_markup() + encode_stream()
    that also fixes a real gap found validating this tier against hand-
    decoded samples (2026-09-08): layout_page_lines() does `line.strip()` on
    every `|`-split chunk before wrapping (correct for the normal case - a
    translator would never intend a meaningful leading/trailing space on a
    line) - but for THIS tier specifically, the content immediately following
    the stripped prologue-echo prefix legitimately needs a real space before
    its first word whenever English requires one there (e.g.
    "{{HL:0xb002}}{{PARAM:0xa000}} is all fired up!" - a real space between
    the substituted name and "is"). JP itself never exercises this (Japanese
    has no word-spacing), which is exactly why none of the 3 pre-existing
    shipped precedents (0x4efeb0/0x4efdf0/0x4f0000) surfaced it - all 3
    happen to follow the substitution directly with a comma/period/tag, never
    a bare space. Confirmed by direct token inspection: encoding
    "{{HL:0xb002}}{{PARAM:0xa000}} is all fired up!" through
    derive_en_prologue_markup()+encode_stream() alone silently drops the
    space, producing back-to-back hl-close then the glyph 'i' with nothing
    between - "[Name]is all fired up!" onscreen, wrong.

    Fix: splice a single SPACE word (0x0000) into the encoded byte stream
    immediately after the verbatim-reproduced prologue bytes, IF and only if
    derive_en_prologue_markup()'s stripped text begins with a literal " ".
    This does not touch layout_page_lines()/wrap_line() (shared by the whole
    plain tier, deliberately not touched here - same caution this project
    already applies to the separate trailing-`//`-vs-trailing_pause gap found
    the same pass) and cannot affect wrap-width math, since that math already
    runs on the `.strip()`-ped text either way - inserting the space is purely
    additive, after wrapping has already been decided.
    """
    stripped, expected_prefix = derive_en_prologue_markup(en_text, jp_tokens)
    needs_space = stripped.startswith(" ")
    stream = encode_stream(stripped, jp_tokens, rev, max_chars=max_chars,
                           max_lines=max_lines, hl_wraps=None)
    if needs_space:
        prologue_byte_len = 2 * len(jp_prologue(jp_tokens))
        stream = (stream[:prologue_byte_len] + struct.pack("<H", 0)
                 + stream[prologue_byte_len:])
    return stream


# --- POSITIONAL-MARKER tier (2026-09-08) --------------------------------
# The general case for a JP source whose disqualifying hl/icon/param8 codes
# sit ANYWHERE in the stream - the ~270-entry bucket flagged as "genuinely
# unsolved" by docs/planning-log/2026-09-08-markup-aware-migration.md's own
# "Outstanding" section (real count established, not the ~275 estimate:
# see docs/planning-log/2026-09-08-icon-pen0-markup-mechanism.md). Neither
# derive_en_hl_markup() (pure hl phrase-wrap, needs a literal TEXT phrase to
# match against) nor derive_en_prologue_markup() (value-first wording,
# substitution confined to the stream's own leading prologue) covers this:
# real occurrences have the substitution mid-sentence, at the very end, or
# scattered across multiple separate points, with real translated text on
# BOTH sides.
#
# PLACEHOLDER_BASE picks a Private-Use-Area codepoint range - guaranteed to
# never collide with a real glyphmap character (extracted/glyphmap.json's
# real Latin/kana/punctuation content lives nowhere near U+E000) and to
# survive str.split(" ")/str.strip() like ordinary text, so it needs zero
# special-casing in the word-splitting/line-wrapping machinery beyond width
# accounting (see _visible_len()).
PLACEHOLDER_BASE = 0xE000

EN_POSITIONAL_MARKER_RE = re.compile(r"\{\{(HL|PARAM|ICON):(0x[0-9a-fA-F]+)\}\}")

# The 0xE800-0xEFFF sub-range of `pen0` is, per dialog_codec.py's own module
# docstring, THE SAME paired open/close wrap shape as `hl` (type 29,
# OPEN_HL/CLOSE_HL 0xE86E/0xE864) - just classified under a different `kind`
# string because dialog_codec.classify_word() groups it with the other
# self-contained, 0-extra-byte "PEN0" codes rather than with "HL". Treating
# it as hl-equivalent here (accept a `{{HL:0xNNNN}}` marker for it) is purely
# additive coverage, not a guess - the byte-level behaviour is confirmed
# identical (tools/patch_navi_c.py already emits it via its own OPEN_HL/
# CLOSE_HL constants for an unrelated, already-shipped patch).
_PEN0_HL_LO, _PEN0_HL_HI = 0xE800, 0xEFFF


def _is_hl_like(t):
    return t["kind"] == "hl" or (t["kind"] == "pen0" and _PEN0_HL_LO <= t["word"] <= _PEN0_HL_HI)


def derive_en_positional_markup(en_text, jp_tokens):
    """Positional-marker tier: parse `en_text` for `{{HL:0xNNNN}}`/
    `{{PARAM:0xNNNN}}`/`{{ICON:0xNNNN}}` markers placed literally wherever in
    the sentence the translator wants that JP control code to land, and turn
    them into a ready-to-encode placeholder map.

    Unlike derive_en_hl_markup(), this needs NO word/phrase matching at all:
    every marker directly and unambiguously names its own target STREAM
    POSITION by where the translator physically put it in `en_text`. That is
    strictly simpler than phrase-matching (no risk of landing on the wrong
    occurrence of a repeated word - the exact failure mode that excluded
    0x4e8290 from the 2026-09-08 hl-wrap batch, see
    docs/planning-log/2026-09-08-markup-aware-migration.md section 6) - the
    tradeoff is that the translator has to place the marker explicitly at
    authoring time rather than the tool inferring a position from wording.

    `{{PARAM:0xNNNN}}` and `{{ICON:0xNNNN}}` are accepted INTERCHANGEABLY for
    both `icon`-kind and `param8`-kind JP tokens - this matches this
    project's own ALREADY-ESTABLISHED registry usage (e.g. 0x457c50 already
    uses `{{PARAM:0x7000}}` for a genuine `icon`-kind token, not a real
    param8 - see that entry's own registry `note`, which explicitly flags
    "bare 2-byte placeholder, NOT the standard 10-byte opaque param_block
    shape"). Which raw bytes actually get emitted is decided by the matched
    JP token's own real `kind` (from dialog_codec.classify_word()), never by
    which spelling the translator happened to use - so a translator does not
    need to know the icon/param8 distinction, an implementation detail.

    Structural validation (fail-safe, never guesses, same discipline as
    derive_en_hl_markup()/derive_en_prologue_markup()): builds the JP
    source's FULL in-order sequence of hl-like/icon/param8 tokens (prologue-
    classified or not - same "the prologue/content boundary isn't load-
    bearing here" principle as derive_en_hl_markup(), for the same reason:
    the translator's markers ARE the position, so this function never needs
    to ask jp_prologue() where content starts). Every marker's value, in
    exact en_text order, must equal that sequence 1:1 (count, value, AND
    kind family: an HL marker only matches an hl-like token, a PARAM/ICON
    marker only matches an icon-or-param8 token) or this raises
    MarkupMismatch.

    SCOPE GUARD (critical - prevents silent byte loss): if the JP stream's
    CONTENT (past jp_prologue()) contains any OTHER disqualifying code this
    function does not understand - a true pen-position `pen0` token (outside
    the 0xE800-0xEFFF hl-like sub-range: pen-X/Y-set, pen-Y-add, table-
    coord - real cursor-movement commands, not value substitutions, with no
    established {{...}} notation) or a mid-stream `setup` token - this
    raises MarkupMismatch rather than silently omitting that code's bytes
    from the output. Do NOT weaken this guard to "just skip unknown codes" -
    that would ship a corrupted stream that happens to still decode.

    Returns (clean_en_text, placeholder_map, filtered_jp_tokens):
      - clean_en_text: `en_text` with every marker replaced by ONE Private-
        Use-Area placeholder character (see PLACEHOLDER_BASE) - ready for
        encode_stream(), whose own `"{{" in en_text` guard will not fire
        (the markers are gone).
      - placeholder_map: {placeholder_char: (kind, word, payload_or_None)} -
        pass straight to encode_stream()'s new `placeholder_map` parameter.
      - filtered_jp_tokens: `jp_tokens` with any LEADING (prologue-
        classified) hl/icon/param8 run stripped - pass this to
        encode_stream(), NOT the original `jp_tokens`, or its own
        prologue-verbatim reproduction would emit those same codes a SECOND
        time (the exact double-emission bug derive_en_hl_markup() already
        had to guard against, generalized here to icon/param8 too).
    """
    n_pro = len(jp_prologue(jp_tokens))
    for i, t in enumerate(jp_tokens):
        if i < n_pro:
            continue  # verbatim-reproduced by encode_stream() regardless
        if t["kind"] == "pen0" and not (_PEN0_HL_LO <= t["word"] <= _PEN0_HL_HI):
            raise MarkupMismatch(
                f"derive_en_positional_markup: content contains a true "
                f"pen-position pen0 token ({t['word']:#06x}) - out of scope, "
                f"no {{{{...}}}} notation exists for cursor-movement codes; "
                f"this entry needs a separate, not-yet-built mechanism")
        if t["kind"] == "setup":
            raise MarkupMismatch(
                f"derive_en_positional_markup: content contains a mid-stream "
                f"'setup' token ({t['word']:#06x}) past the leading prologue "
                f"- out of scope, no established notation for this")

    jp_seq = [t for t in jp_tokens if _is_hl_like(t) or t["kind"] in ("icon", "param8")]
    markers = list(EN_POSITIONAL_MARKER_RE.finditer(en_text))
    if len(markers) != len(jp_seq):
        raise MarkupMismatch(
            f"derive_en_positional_markup: en_text has {len(markers)} "
            f"{{{{HL/PARAM/ICON}}}} marker(s) but the JP source has "
            f"{len(jp_seq)} hl-like/icon/param8 token(s) in its full stream "
            f"- count mismatch")

    placeholder_map = {}
    clean_parts = []
    cursor = 0
    for idx, (m, jt) in enumerate(zip(markers, jp_seq)):
        tag_kind, tag_val = m.group(1), int(m.group(2), 16)
        if tag_val != jt["word"]:
            raise MarkupMismatch(
                f"derive_en_positional_markup: marker #{idx} ({m.group(0)}) "
                f"value {tag_val:#06x} != JP's own in-order value "
                f"{jt['word']:#06x} (kind {jt['kind']!r}) - order or value "
                f"mismatch")
        if tag_kind == "HL" and not _is_hl_like(jt):
            raise MarkupMismatch(
                f"derive_en_positional_markup: marker #{idx} is {{{{HL:...}}}} "
                f"but the JP source's matching token is kind {jt['kind']!r}, "
                f"not hl-like")
        if tag_kind in ("PARAM", "ICON") and jt["kind"] not in ("icon", "param8"):
            raise MarkupMismatch(
                f"derive_en_positional_markup: marker #{idx} is "
                f"{{{{{tag_kind}:...}}}} but the JP source's matching token is "
                f"kind {jt['kind']!r}, not 'icon'/'param8'")
        clean_parts.append(en_text[cursor:m.start()])
        ph = chr(PLACEHOLDER_BASE + idx)
        clean_parts.append(ph)
        placeholder_map[ph] = (jt["kind"], jt["word"], jt.get("payload"))
        cursor = m.end()
    clean_parts.append(en_text[cursor:])
    clean_en_text = "".join(clean_parts)
    if "{{" in clean_en_text:
        raise MarkupMismatch(
            "derive_en_positional_markup: residual '{{' left in clean_en_text "
            "after stripping markers - unexpected marker shape, refusing to "
            "guess")

    filtered_jp_tokens = [t for i, t in enumerate(jp_tokens)
                          if not (i < n_pro and (_is_hl_like(t) or t["kind"] in ("icon", "param8")))]

    return clean_en_text, placeholder_map, filtered_jp_tokens


def zero_width_placeholders(placeholder_map):
    """The subset of a placeholder_map's characters that are zero-width for
    wrap-budget purposes: an `hl`-kind (or hl-like pen0) code draws nothing -
    it only changes renderer colour state - matching the ALREADY-established
    "hl markup is zero-width once stripped" precedent from
    derive_en_hl_markup()'s own `clean_en_text`. An `icon`/`param8` code DOES
    draw something (the substituted glyph/value) so it is NOT included here -
    it keeps its default 1-character width estimate (documented, not
    measured - same honesty-about-estimates precedent as
    SMALL_BOX_MAX_CHARS; a real pixel calibration is a follow-up, not done
    this pass). Pass the result as wrap_line()/layout_page_lines()/
    plan_page_chunks()/plan_stream_pages()/encode_stream()'s
    `zero_width_chars` argument.

    BUG FIX (2026-09-08, caught by an independent fresh adversarial
    reviewer): `placeholder_map` stores the JP token's own RAW
    dialog_codec.py `kind` string, which for the hl-like pen0 sub-family
    (0xE800-0xEFFF - see _is_hl_like()) is `"pen0"`, not `"hl"`. The
    original version of this function checked `kind == "hl"` only, so it
    silently excluded hl-like pen0 placeholders from the zero-width set -
    reproducing the exact over-counting bug the zero-width fix exists to
    prevent (see the 0x457d60 validation sample in
    docs/planning-log/2026-09-08-icon-pen0-markup-mechanism.md: a naive,
    un-zeroed count wrongly flagged a real entry as over budget). Confirmed
    live on real on-disc hl-like pen0 codes (e.g. 0xe832 at entry
    0x478d30) before this fix. Does NOT affect byte correctness
    (encode_label() always splices the right raw bytes regardless of where
    line/page breaks land) - only wrap/pagination QUALITY for the
    `pen0`-involving shapes (~29+ entries once markup is authored for
    them); none of the currently-queued `hl+icon`-only ready_as_is/
    needs_hl_backfill_mechanical entries exercise this path."""
    return {ph for ph, (kind, word, _) in placeholder_map.items()
           if kind == "hl" or (kind == "pen0" and _PEN0_HL_LO <= word <= _PEN0_HL_HI)}


def encode_mixed_markup_stream(en_text, jp_tokens, rev,
                               max_chars=LARGE_BOX_MAX_CHARS,
                               max_lines=LARGE_BOX_MAX_LINES):
    """Top-level encoder for the positional-marker tier: derives the
    placeholder map from `en_text`'s own `{{HL:}}`/`{{PARAM:}}`/`{{ICON:}}`
    markup (see derive_en_positional_markup()) and threads it through
    encode_stream(), including the hl-placeholder zero-width fix so wrap/
    pagination width accounting matches what actually renders.

    This is the direct answer to the task's "genuinely unsolved" bucket: a
    control code substitution positioned anywhere in the sentence (leading,
    trailing, mid-sentence, or scattered across multiple points), preserving
    each token's exact original bytes/args while letting the translator's
    English wording flow naturally around it - the translator expresses the
    desired word order simply by where they place the marker in `en_text`.

    POST-ENCODE PAGE-CONSISTENCY CHECK (2026-09-08, added after an
    independent fresh adversarial reviewer built a concrete repro): neither
    derive_en_positional_markup()'s structural validation nor
    plan_page_chunks()'s auto-pagination cost model has ANY concept of an
    hl-like open/close pair needing to stay on the SAME rendered page - the
    validation only checks the flat in-order code sequence, and the
    pagination DP treats a placeholder character exactly like ordinary text,
    cuttable at any word gap. A long enough translated sentence CAN get
    auto-paginated with an hl-open on one page and its matching hl-close on
    a LATER page - since colour state persists until explicitly changed (no
    evidence PAGE resets it - dialog_codec.py's own module docstring), this
    would leave a highlight colour "bleeding" into subsequent pages, a real
    rendering bug the round-trip order/value check does not catch (proven
    live with a synthetic long-sentence repro, not just theoretical).

    Fix: decode this function's OWN output and refuse (EncodeError) if any
    hl-like pair (paired up in output order, same even-count-alternating-
    pairs assumption derive_en_hl_markup() already makes for a real JP
    stream) spans more than one page. Not yet triggered by any of the 10
    `ready_as_is`/20 `needs_hl_backfill_mechanical` entries (their
    highlighted spans are short), but several already need 1-2 auto-
    inserted overflow pages, so this WILL be exercised as the remaining
    ~178 not-yet-authored entries in the bucket get markup - catching it
    here, loudly, is safer than a silent visual bug on real disc content."""
    clean_en_text, placeholder_map, filtered_jp_tokens = derive_en_positional_markup(en_text, jp_tokens)
    zw = zero_width_placeholders(placeholder_map)
    stream = encode_stream(clean_en_text, filtered_jp_tokens, rev,
                           max_chars=max_chars, max_lines=max_lines,
                           placeholder_map=placeholder_map, zero_width_chars=zw)
    _check_hl_pairs_single_page(stream)
    return stream


_HL_PROLOGUE_KINDS = ("hdr", "speaker", "setup", "hl", "pen0")


def _hl_pairs_error(hl_hits):
    """Pure/side-effect-free: returns None if `hl_hits` (a list of
    {"word", "page", "tok_idx"} dicts, in output order) forms a clean set of
    same-page open/close pairs under the naive alternating-pairs assumption
    (hits[0]/hits[1], hits[2]/hits[3], ...), else an error message string.
    Split out of _check_hl_pairs_single_page() so it can be tried twice - once
    on the raw hit list (the ORIGINAL, unchanged check - see that function's
    docstring for why this must stay a byte-identical fast path) and, only if
    that fails, once more on a reduced list with specific known-safe hits
    explained away (see _exclude_provably_safe_hl_hits())."""
    if len(hl_hits) % 2 != 0:
        return (f"odd number of hl-like codes ({len(hl_hits)}) in the "
                f"encoded output - not a clean open/close-pair shape, "
                f"refusing to guess which pairs with which")
    for k in range(0, len(hl_hits), 2):
        a, b = hl_hits[k], hl_hits[k + 1]
        if a["page"] != b["page"]:
            return (f"hl-like pair ({a['word']:#06x} on page {a['page']}, "
                    f"{b['word']:#06x} on page {b['page']}) is split across "
                    f"an auto-paginated page boundary - colour state would "
                    f"bleed into the next page; shorten the highlighted "
                    f"span, add a manual '|'/'//' break the translator "
                    f"controls, or otherwise keep both codes on the same "
                    f"page before this entry can ship")
    return None


def _exclude_provably_safe_hl_hits(toks, hl_hits):
    """Best-effort FALLBACK for _check_hl_pairs_single_page(): tries to
    explain away specific hl-like hits that are PROVABLY incapable of ever
    bleeding colour onto rendered content, so the remaining hits can be
    re-checked as normal alternating open/close pairs. Returns a new
    (possibly unchanged) list, or None if neither rule below applies.

    This is emphatically NOT "relax the odd-count check" - both rules are
    individually, locally provable from the token stream alone, discovered
    2026-09-09 while investigating 3 real held-back entries
    (0x476c30/0x476c60/0x478e00, see docs/planning-log/
    2026-09-09-odd-hl-count-fix.md). The underlying fact that makes both
    rules sound: dialog_codec.py's own module docstring establishes that
    0xB001-0xB7FF ("hl") is "TEXT COLOUR, not a generic highlight... 0 extra
    bytes - copy verbatim" - i.e. every hl-like code is a plain, independent
    SET-CURRENT-COLOUR instruction (last-write-wins), NOT a stack push/pop
    primitive. The "pairs" this whole mechanism reasons about are an
    application-level USAGE CONVENTION (open-colour, content, reset-colour)
    this project observed empirically, not a hardware requirement - so a
    hl-like code that provably never has any content rendered under its own
    colour setting was never really part of any pair to begin with, and
    excluding it from the pairing requirement cannot reintroduce the
    colour-bleed bug this check exists to prevent.

    Rule 1 - DEAD CODE: an hl-like hit immediately followed, with ZERO
    intervening tokens of ANY kind, by ANOTHER hl-like hit can never have
    coloured anything - there is no glyph/icon/param8 between them for the
    first code's colour to apply to before the second code overwrites it.
    Confirmed live at 0x476c30/0x476c60 ("disguised as X"/"is disguised as
    X"): real JP decode is `hl(0xb002) icon(name) hl(0xb008) glyph(は) LINE
    hl(0xb004) hl(0xb002) icon(name) hl(0xb008) glyph(に) LINE 変装した!` - the
    stray 0xb004 sits DIRECTLY adjacent to the following 0xb002 with nothing
    between them, so it is excluded and the remaining 4 hits form 2 clean,
    same-page pairs exactly as intended.

    Rule 2 - LEADING, PERMANENTLY-UNCLOSED BASELINE: the FIRST hl-like hit
    (after Rule 1), if and only if it sits inside the stream's own leading
    state-setting run (nothing of a kind outside _HL_PROLOGUE_KINDS precedes
    it - the exact run dialog_codec.decode_structured()'s own prologue loop
    consumes, and text_encoder.jp_prologue()'s own docstring already
    characterises as selecting "the text colour... for the whole box"),
    LOOKS LIKE a box-wide BASELINE colour rather than a scoped highlight that
    needs closing. Confirmed live at 0x478e00 ("PlayStation2 Multitap"): real
    JP decode opens with a bare, never-closed 0xb004 that persists to the
    literal end of the box in the REAL, already-shipped JP source too.

    BUG FOUND 2026-09-09 by an independent fresh adversarial reviewer,
    live-reproduced through this exact production pipeline (real
    derive_en_positional_markup()/encode_mixed_markup_stream() call, real
    plan_page_chunks() auto-pagination, no hand-inserted PAGE tokens) before
    this guard existed: stream position ALONE ("nothing but prologue-kind
    tokens precedes it") does NOT prove a hit has no real partner - it only
    proves nothing precedes it in the CURRENT wording/pagination, which a
    translator's English and auto-pagination both influence. A genuine
    scoped highlight-open placed first can satisfy the exact same positional
    test as a true permanent baseline. Concrete repro: hl(A) opens on page 0,
    its TRUE close hl(B) gets auto-paginated 5 PAGES away, and one further,
    genuinely unrelated hl(C) happens to land on B's page too - Rule 2 (as
    first written) discarded A on positional grounds alone, leaving [B, C]
    which coincidentally shares a page and passes - silently missing the
    real A/B cross-page bleed this whole mechanism exists to catch.

    FIX: only ever apply Rule 2 when it is IMPOSSIBLE for any cross-page
    split to exist among the hits in the first place - i.e. when every hit
    in the ORIGINAL (pre-Rule-1) `hl_hits` already shares a single page. If
    there is no page boundary anywhere among the real hits, no reduction or
    re-pairing of them can ever manufacture a false "same page" verdict for
    a split that structurally cannot exist. This still resolves 0x478e00
    (confirmed single-page - no PAGE token appears in its real encoded
    output at all) while refusing to guess in any multi-page case, including
    the reviewer's repro (open on page 0, everything else on page 5 -> the
    single-page guard below correctly blocks Rule 2 from ever firing, and
    the function returns the odd, still-failing list unchanged). Using the
    PRE-Rule-1 hit set for this guard (rather than the post-Rule-1 reduced
    list) is deliberate and provably equivalent either way: Rule 1 only ever
    removes the EARLIER of two hits that are immediately adjacent in the
    token stream (see above), and the LATER one of any such pair always
    survives into `reduced` - so no page can ever lose ALL of its
    representation to Rule 1, meaning the set of distinct pages touched by
    `hl_hits` and by `reduced` is always identical. Computed from the
    original list here simply because it is the more obviously-correct
    thing to read, not because it differs in practice.

    Only ONE hit is ever removed by this rule (never more, without concrete
    evidence) - if that is not enough to restore an even, cleanly-pairable
    remainder, the caller's normal check will reject the reduced list too
    and _check_hl_pairs_single_page() falls back to its ORIGINAL error, per
    this project's "refuse rather than guess" discipline.

    Both rules only ever REMOVE hits that are individually, locally
    provable-safe (Rule 1 by a physical impossibility-of-rendering argument;
    Rule 2, post-fix, additionally gated so it can only ever fire when a
    cross-page split is structurally impossible regardless of which hits get
    paired with which); neither touches a hit that is part of a genuinely
    rendered, potentially cross-page span in a case where a split COULD
    exist, so a real bleed bug is still caught by the ordinary same-page
    check the caller re-runs on whatever this function returns. Also, this
    function is invoked ONLY as a fallback, after the untouched hit list has
    already failed the original check - so it can NEVER change behaviour for
    any entry that currently passes (byte-identical fast path preserved)."""
    reduced = []
    n = len(hl_hits)
    for i, hit in enumerate(hl_hits):
        if i + 1 < n and hl_hits[i + 1]["tok_idx"] == hit["tok_idx"] + 1:
            continue  # Rule 1: immediately superseded, never rendered anything
        reduced.append(hit)

    single_page = len({h["page"] for h in hl_hits}) == 1
    if reduced and len(reduced) % 2 != 0 and single_page:
        first = reduced[0]
        preceding_kinds = {t["kind"] for t in toks[:first["tok_idx"]]}
        if not (preceding_kinds - set(_HL_PROLOGUE_KINDS)):
            reduced = reduced[1:]  # Rule 2: leading, permanently-unclosed baseline
            # (single_page guard above makes this provably safe: with every
            # hit already confined to one page, no cross-page split can
            # exist among them for this reduction to hide)

    if reduced == hl_hits:
        return None
    return reduced


def _check_hl_pairs_single_page(stream_bytes):
    """Decode `stream_bytes` (this module's own freshly-encoded output) and
    raise EncodeError if any hl-like open/close pair (see _is_hl_like()) is
    split across a PAGE (0x1000) boundary - see encode_mixed_markup_stream()'s
    docstring for why this matters and isn't caught anywhere else.

    2026-09-09: extended with a FALLBACK (_exclude_provably_safe_hl_hits())
    that recognises 2 additional known-safe shapes an odd hl-like count can
    take - a locally dead (immediately-superseded) code, and a leading,
    permanently-unclosed box-wide baseline colour - found while investigating
    3 real entries this original strict version unconditionally refused
    regardless of wording (0x476c30/0x476c60/0x478e00, see
    docs/planning-log/2026-09-09-odd-hl-count-fix.md). The fallback is tried
    ONLY after the original, untouched-hit-list check has already failed, so
    it changes nothing for any entry that currently passes."""
    try:
        toks = dc.decode_structured(stream_bytes, 0, require_hdr=False)
    except ValueError as ex:
        raise EncodeError(f"_check_hl_pairs_single_page: could not decode own "
                          f"output to verify - {ex}")
    page_idx = 0
    hl_hits = []   # {"word", "page", "tok_idx"} in output order
    for i, t in enumerate(toks):
        if t["kind"] == "page":
            page_idx += 1
            continue
        if _is_hl_like(t):
            hl_hits.append({"word": t["word"], "page": page_idx, "tok_idx": i})

    err = _hl_pairs_error(hl_hits)
    if err is None:
        return

    reduced = _exclude_provably_safe_hl_hits(toks, hl_hits)
    if reduced is not None and _hl_pairs_error(reduced) is None:
        return

    raise EncodeError(f"_check_hl_pairs_single_page: {err}")


def encode_stream(en_text, jp_tokens, rev, max_chars=LARGE_BOX_MAX_CHARS,
                  max_lines=LARGE_BOX_MAX_LINES, hl_wraps=None,
                  placeholder_map=None, zero_width_chars=None):
    """Build the full stream bytes (HDR...END) for a "truly plain" entry.

    Raises EncodeError if `en_text` contains any markup this encoder doesn't
    support ({{HL:}}/{{PARAM:}}/{{ICON:}}) - those entries must go through
    bespoke handling, never silently through this path.

    `hl_wraps` (2026-09-04): optional list of `(exact_word, before_code,
    after_code)` for entries whose registry `inline_codes` field records
    control codes bracketing a specific word inside the CONTENT (not the
    prologue) - see encode_label(). Consumed in stream order across every
    line/page via one shared cursor.

    `max_chars`: safe rendered-line width, auto-wrapped on top of whatever
    `|` breaks the en text already has (see wrap_line()). Defaults to the
    main dialog box's established safe width; pass SMALL_BOX_MAX_CHARS (or
    another value) explicitly for content known to use a smaller box.

    `max_lines`: safe rendered-line COUNT per page (2026-09-04). If wrapping
    a page's text produces more lines than the box can show, the extra lines
    go into ADDITIONAL PAGE (0x1000) boxes rather than being cropped off the
    box's top and bottom edges - see paginate_lines(). Pass None to disable
    (pre-2026-09-04 behaviour).

    An auto-inserted overflow page is emitted as a BARE PAGE word with NO
    speaker word after it. That is not a shortcut, it is what the shipped game
    does - brute-scan of all 1696 decodable JP streams in the original ELF
    found 992 non-trailing page breaks, of which 726 are bare, 301 of those
    continuing a page that HAD set a speaker (e.g. VMA 0x47f1b0, one priest
    talking straight through the break; 0x480840, one clerk). And of the 266
    breaks that DO carry a speaker word, exactly ZERO repeat the previous
    page's value - the game never re-states a speaker it has already set, so
    the setting evidently persists across PAGE. Re-emitting it here would be
    an unprecedented byte sequence, and these type-7 words appear to double as
    per-page voice-clip indices (navi-intro-f1 uses three DIFFERENT ones for
    three Navi pages), so a duplicate could re-trigger a voice line too.

    `placeholder_map`/`zero_width_chars` (2026-09-08, positional-marker tier
    - see derive_en_positional_markup()/encode_mixed_markup_stream()):
    `placeholder_map` is threaded straight through to encode_label() (raw-
    byte splicing for a Private-Use-Area placeholder character);
    `zero_width_chars` is threaded through plan_stream_pages()'s wrap/
    pagination width accounting so an `hl`-code placeholder (draws nothing)
    doesn't count against the character budget the way a real glyph would.
    The caller (encode_mixed_markup_stream()) is responsible for passing
    `en_text` ALREADY marker-free (placeholders substituted in) - this
    function's own `"{{" in en_text` guard below still applies unchanged and
    will not fire for such text, since the markers are gone by the time they
    reach here.
    """
    if "{{" in en_text:
        raise EncodeError(
            "encode_stream: en text contains {{...}} markup - this encoder only "
            "handles the plain tier (no inline control codes); route this entry "
            "through the markup-aware tier instead")

    initial_speaker, trailing_pause = jp_structure(jp_tokens)
    prologue = jp_prologue(jp_tokens)
    pages = list(plan_stream_pages(en_text, max_chars, max_lines, zero_width_chars))
    hl_cursor = [0, 0]

    # Page 0's EN speaker override has to be resolved BEFORE the prologue is
    # emitted: the JP prologue's speaker word can sit anywhere inside the run
    # (0x4ef360 puts it first, 0x4ef2e0 fourth, 0x4f1220 last), and the
    # substitution must happen in place so the original word ORDER survives.
    page0_speaker = pages[0][0] if pages else None

    # Emit the JP prologue verbatim - see jp_prologue()'s docstring for why.
    # For the two ordinary shapes ("[hdr]" and "[hdr, speaker]") this produces
    # byte-for-byte what the previous hardcoded `pack(dc.HDR)` + page-0 speaker
    # branch produced; it only diverges for streams that genuinely carry extra
    # setup words, an unusual ordering, or no 0x2800 at all.
    out = b""
    for t in prologue:
        w = t["word"]
        if t["kind"] == "speaker" and page0_speaker is not None:
            w = page0_speaker
        out += struct.pack("<H", w)

    for si, (page_speaker, auto, lines) in enumerate(pages):
        if si == 0:
            if initial_speaker is not None:
                pass  # already emitted above, in its original prologue position
            elif page_speaker is not None:
                # JP had no initial speaker but EN explicitly wants one on page 1 -
                # trust the EN markup (it's the more specific signal)
                out += struct.pack("<H", page_speaker)
        elif auto:
            # auto-inserted overflow page: BARE page word, never a speaker -
            # see this function's docstring for the evidence
            out += struct.pack("<H", dc.PAGE)
        else:
            out += struct.pack("<H", dc.PAGE)
            if page_speaker is not None:
                out += struct.pack("<H", page_speaker)
            # else: bare page break, no speaker word - matches the real
            # distribution (most page breaks in this tier are bare pacing
            # pauses within one speaker's continuous line)

        out += encode_lines(lines, rev, hl_wraps, hl_cursor, placeholder_map)

    if hl_wraps is not None and hl_cursor[0] < len(hl_wraps):
        raise EncodeError(
            f"encode_stream: {len(hl_wraps) - hl_cursor[0]} of {len(hl_wraps)} "
            f"hl_wraps entries were never matched against en_text - the word(s) "
            f"expected past index {hl_cursor[0]} never appeared, which means "
            f"either the translation changed the word or dropped an occurrence; "
            f"refusing to silently emit the JP's control codes without them "
            f"actually bracketing anything in the EN output")
    if hl_wraps is not None and hl_cursor[1] > 0:
        raise EncodeError(
            f"encode_stream: en_text has {hl_cursor[1]} MORE occurrence(s) of a "
            f"hl_wraps target word than the JP source has control-code pairs "
            f"for - those extra occurrence(s) would ship with no colour code "
            f"at all, silently wrong; either the translation added an "
            f"occurrence or hl_wraps is missing an entry")
    if trailing_pause:
        out += struct.pack("<H", dc.PAGE)
    out += struct.pack("<H", dc.END)
    return out


def encode_entry_from_elf(en_text, jp_vma, elf_bytes, rev,
                          max_chars=LARGE_BOX_MAX_CHARS,
                          max_lines=LARGE_BOX_MAX_LINES, hl_wraps=None):
    """Convenience wrapper: decode the JP source at `jp_vma` from `elf_bytes`
    (VMA, old-segment DELTA=0xFFF80) and encode `en_text` against it.

    Scope guard, narrowed 2026-09-04: control codes sitting in the stream's
    PROLOGUE are no longer disqualifying, because encode_stream() now copies
    the prologue through verbatim (see jp_prologue()). What still disqualifies
    an entry is a control code INSIDE the content - an icon or a highlight
    span interleaved with the text, which has to be positioned relative to
    words the translator rewrote, and which the `en` field carries no markup
    for. That is the real "markup-aware tier" boundary; "anywhere in the
    stream" was a conservative over-approximation of it.

    `hl_wraps` (2026-09-04): pass this (built from a registry entry's
    `inline_codes` field - see encode_label()) for an entry whose ONLY
    content-kind disqualifier is `hl` and whose HL pairs bracket a known,
    exact word in `en_text` (e.g. 0x4efb40's Maconde). Any OTHER disqualifying
    kind (icon/pen0/param8/setup in the content) still raises unconditionally -
    this narrow allowance covers exactly the inline_codes shape, not a general
    markup-aware tier.

    Streams with no 0x2800 at all (0x4ef500, 0x458f20) are decoded with
    require_hdr=False and are fine here: the prologue-verbatim rule reproduces
    exactly the words they do have, and never invents an 0x2800 they don't.
    """
    off = jp_vma - 0xFFF80
    try:
        jp_tokens = dc.decode_structured(elf_bytes, off)
    except ValueError:
        jp_tokens = dc.decode_structured(elf_bytes, off, require_hdr=False)
    n_pro = len(jp_prologue(jp_tokens))
    kinds = set(t["kind"] for t in jp_tokens[n_pro:])
    allowed = {"hl"} if hl_wraps is not None else set()
    bad = (kinds & {"hl", "icon", "pen0", "param8", "setup"}) - allowed
    if bad:
        raise EncodeError(
            f"encode_entry_from_elf: JP source at {jp_vma:#x} contains inline "
            f"control codes ({bad}) in its CONTENT (past the {n_pro}-word "
            f"prologue) - those have to be positioned relative to translated "
            f"words, which this encoder has no markup for; this entry needs the "
            f"markup-aware tier, not this encoder")
    # NOTE (2026-09-05): a bare mid-content 'speaker' token (JP has a speaker
    # change after LINE, not PAGE - newly decodable after
    # dialog_codec.decode_structured()'s SPK_LO/HI-in-main-loop widening, see
    # that module's history) does NOT need special handling here. Verified by
    # inspecting the real entries this newly unblocks (0x4efdf0/0x4efeb0/
    # 0x4f0030): the page/speaker structure the encoder emits comes entirely
    # from the EN text's own `//` page breaks and `[spk 0xNNNN]` tags (see
    # plan_stream_pages()/encode_stream() below) - the JP source's internal
    # PAGE-vs-LINE position past the prologue is irrelevant to that, it only
    # matters for the disqualifying-kind screen above. An earlier version of
    # this function added a JP-position-based guard here on the mistaken
    # assumption that position mattered; it produced a false positive on
    # 0x4f0030 (a genuinely plain, correctly-EN-marked-up entry) and was
    # removed.
    if hl_wraps is not None:
        n_hl = sum(1 for t in jp_tokens[n_pro:] if t["kind"] == "hl")
        # each hl_wraps entry is a (before, after) PAIR = 2 raw 'hl' tokens
        if n_hl != len(hl_wraps) * 2:
            raise EncodeError(
                f"encode_entry_from_elf: JP source at {jp_vma:#x} has {n_hl} "
                f"'hl' tokens in its content but hl_wraps has {len(hl_wraps)} "
                f"before/after pairs ({len(hl_wraps) * 2} tokens) - these must "
                f"match 1:1 (one registry inline_codes pair per real JP "
                f"before/after code pair) or the wrong codes could land on "
                f"the wrong words")
    return encode_stream(en_text, jp_tokens, rev, max_chars=max_chars,
                         max_lines=max_lines, hl_wraps=hl_wraps)


CTRL_TOKEN_RE = re.compile(r"<(0x[0-9a-fA-F]{4})>")


def class_tooltip_lines(en_text, max_chars):
    """The rendered line list for a class-selection tooltip's `en` text: the
    translator's own `|` breaks, each additionally word-wrapped if it exceeds
    `max_chars` (same safety-net rule as encode_page_text()).

    Split out from encode_class_tooltip_stream() so the caller can check the
    resulting LINE COUNT against the box's real vertical budget BEFORE
    encoding - see the tool's own --max-lines guard. Single-sourcing this
    keeps the count the tool reports and the bytes the encoder emits from
    ever disagreeing.
    """
    lines = []
    for raw in en_text.split("|"):
        s = raw.strip()
        if len(s) > max_chars:
            lines.extend(wrap_line(s, max_chars))
        else:
            lines.append(s)
    return lines or [""]


def encode_class_tooltip_stream(en_text, rev, max_chars=LARGE_BOX_MAX_CHARS):
    """Encoder for the navi_intro class-selection tooltip content class
    (5 entries, VMA 0x4f0390/0x4f0400/0x4f0470/0x4f04d0/0x4f0540).

    Structurally the SIMPLEST stream shape in the project - reverse-engineered
    2026-09-01 (docs/HANDOFF.md item 3a, "Cluster 3"), re-confirmed by live
    decode 2026-09-04: NO 0x2800 HDR, NO speaker code, NO page breaks, NO
    control codes of any kind. Just plain glyph runs separated by 0x0800 LINE
    words and terminated by 0xF800.

    Same headerless family as encode_settings_stream() (which is why
    dialog_codec.decode_structured()'s require_hdr=False flag is reused
    verbatim here rather than reinvented), but deliberately a SEPARATE
    function: settings-option streams carry `<0xNNNN>` layout control codes
    and an option-name/description split that these do not, and silently
    accepting that markup here would mean encoding something the class-tooltip
    renderer has never been shown to handle.

    Every input shape this content class has never been observed to contain is
    REFUSED rather than guessed at, per project convention:
      - `{{HL:}}`/`{{PARAM:}}`/`{{ICON:}}` markup (no control codes exist here)
      - `<0xNNNN>` settings-style control tokens (same reason)
      - `//` page breaks (JP has zero PAGE tokens - this is not a paged box)
      - `[spk 0xNNNN]` speaker tags (JP has no speaker word at all)
    """
    if "{{" in en_text:
        raise EncodeError(
            "encode_class_tooltip_stream: en text contains {{...}} markup - the "
            "class-tooltip JP sources contain NO control codes at all (verified by "
            "live decode of all 5), so there is nothing for this markup to mean here")
    if CTRL_TOKEN_RE.search(en_text):
        raise EncodeError(
            "encode_class_tooltip_stream: en text contains a <0xNNNN> control token - "
            "that is the settings-option convention; class tooltips have no control "
            "codes, route this entry deliberately rather than through this encoder")
    if "//" in en_text:
        raise EncodeError(
            "encode_class_tooltip_stream: en text contains a `//` page break, but the "
            "JP class-tooltip streams have zero PAGE (0x1000) tokens - this box is not "
            "paged, and emitting a PAGE word here would be an unverified guess")
    if "[spk " in en_text:
        raise EncodeError(
            "encode_class_tooltip_stream: en text carries a [spk 0xNNNN] tag, but the "
            "JP class-tooltip streams have no speaker word at all (confirmed by "
            "contrast with the HDR-bearing streams on either side)")

    out = b""
    for i, line in enumerate(class_tooltip_lines(en_text, max_chars)):
        if i:
            out += struct.pack("<H", dc.LINE)
        if line:
            out += encode_label(line, rev)
    out += struct.pack("<H", dc.END)
    return out


def encode_settings_stream(en_text, rev, max_lines=None):
    """Encoder for the settings-option content class (2026-09-04 finding):
    these streams do NOT start with HDR (0x2800) at all - a different,
    non-dialog-box renderer - and their `en`/`jp` fields already use a
    `<0xNNNN>` convention (not `{{HL:}}`/`{{PARAM:}}`) for embedded layout
    control codes, since translators here already preserved the codes
    verbatim at draft time (confirmed: every real settings-option entry's
    `en` control-code sequence matches its `jp` exactly, same values, same
    order - unlike the icon/highlight gap found elsewhere in the backlog).

    Structure: `|` = LINE (0x0800) between options/lines, same as the main
    encoder. A trailing `//` (if present) means the JP source ends with a
    bare PAGE (0x1000) wait before END - mirrors the main encoder's
    trailing-pause concept, but driven directly by EN's own `//` marker
    (confirmed reliable across all 9 real entries) rather than needing to
    consult JP structure at all. `<0xNNNN>` tokens are copied verbatim as a
    single control word IF their low-11-bit param is nonzero (the confirmed
    0-extra-byte case for the type-9/type-26 families used here) - a token
    whose param is exactly 0 is refused rather than guessed, since that's
    the confirmed 8-byte-payload-consuming exception for these families and
    this encoder has no JP payload to copy from (settings content has no
    real occurrence of this case to draw from - if one ever appears, it
    needs bespoke handling, not this generic path).

    `max_lines` (2026-09-04, optional, default None = off): REFUSE to encode a
    stream whose rendered line count exceeds this. Deliberately a REFUSAL, not
    the automatic pagination encode_stream() does - this content class is NOT a
    paged dialog box (a different, non-HDR renderer draws it), its option rows
    are positioned by the embedded `<0xNNNN>` cursor codes, and pushing rows
    onto a second "page" would hide selectable options rather than merely
    pacing them. The right fix for an over-tall settings pane is a shorter
    translation, which is a human decision. tools/audit_line_overflow.py
    currently flags all 9 on-disc settings entries as over the JP original's
    own 3-line maximum.
    """
    if "{{" in en_text:
        raise EncodeError(
            "encode_settings_stream: en text contains {{...}} markup - unexpected "
            "for the settings-option content class, which uses <0xNNNN> instead - "
            "investigate before proceeding")

    trailing_pause = en_text.endswith("//")
    body = en_text[:-2] if trailing_pause else en_text

    out = b""
    n_lines = 0
    first_line_overall = True
    for line in body.split("|"):
        # option-name + control-code sequence stays atomic on its own first
        # sub-line (splitting a name away from its alignment codes would
        # break the cursor-positioning purpose those codes serve); the
        # DESCRIPTION text after the last control code is what actually
        # needs wrapping (found 2026-09-04: every real settings-option
        # entry's description is well over the safe width once the
        # <0xNNNN> tokens are excluded from the character count).
        pos = 0
        prefix = b""
        prefix_visible_len = 0  # option-name text only, control codes take 0 visible width
        last_end = 0
        for m in CTRL_TOKEN_RE.finditer(line):
            name_part = line[pos:m.start()].strip()
            prefix += encode_label(name_part, rev) if name_part else b""
            prefix_visible_len += len(name_part)
            code = int(m.group(1), 16)
            param = code & 0x7FF
            if param == 0:
                raise EncodeError(
                    f"encode_settings_stream: token {code:#06x} has param==0, the "
                    f"confirmed 8-byte-payload-consuming case for this code family - "
                    f"no real settings-option entry has ever exercised this path, "
                    f"needs bespoke handling before trusting it here")
            prefix += struct.pack("<H", code)
            pos = m.end()
            last_end = m.end()
        remainder = line[last_end:].strip()

        # the first wrapped chunk shares its rendered line with the prefix
        # text (option name) - its budget must be reduced by how much of
        # the line the prefix already visibly occupies (bug found + fixed
        # 2026-09-04: wrapping the remainder against the FULL width ignored
        # the prefix entirely, so e.g. "Character" + a 20-char first chunk
        # still overflowed to 30 visible characters on the actual line)
        first_budget = max(LARGE_BOX_MAX_CHARS - prefix_visible_len, 8)
        if remainder:
            first_words = remainder.split(" ")
            first_chunk = []
            first_len = 0
            while first_words:
                w = first_words[0]
                add = len(w) + (1 if first_chunk else 0)
                if first_chunk and first_len + add > first_budget:
                    break
                first_chunk.append(first_words.pop(0))
                first_len += add
            rest = " ".join(first_words)
            sub_lines = [" ".join(first_chunk)] + (wrap_line(rest, LARGE_BOX_MAX_CHARS) if rest else [])
        else:
            sub_lines = [""]

        if not first_line_overall:
            out += struct.pack("<H", dc.LINE)
        first_line_overall = False
        out += prefix
        out += encode_label(sub_lines[0], rev) if sub_lines[0] else b""
        n_lines += 1
        for extra in sub_lines[1:]:
            out += struct.pack("<H", dc.LINE)
            out += encode_label(extra, rev)
            n_lines += 1

    if max_lines is not None and n_lines > max_lines:
        raise EncodeError(
            f"encode_settings_stream: this text renders to {n_lines} lines but the "
            f"pane budget is {max_lines} - settings panes are NOT paged, so this "
            f"cannot be auto-split; shorten the translation instead")

    if trailing_pause:
        out += struct.pack("<H", dc.PAGE)
    out += struct.pack("<H", dc.END)
    return out


def _classify_word_ui_grid(w, gm):
    """Retain verifier-compatible UI tokenization, including standalone B000.

    This is historical tokenization: D800 still hides eight source bytes here.
    The reviewed native Settings/Controls consumer reads those arguments externally;
    Go preserves its two-byte source words. See the positional-labels checkpoint in
    tools/go/evidence; do not generalize this local override to other consumers.
    """
    if w == 0xB000:
        return "HL"
    return dc.classify_word(w, gm)


def decode_ui_grid_stream(data, off, max_words=4096):
    """Structural decoder for the settings-SCREEN UI-grid content class -
    same token shape as dialog_codec.decode_structured() (kind/off/word/
    payload dicts, same kind vocabulary) but built on
    _classify_word_ui_grid() above instead of dialog_codec.classify_word(),
    and with NO HDR/prologue handling at all: this renderer never emits
    0x2800 (confirmed empirically across every real occurrence of this
    content class, same finding encode_settings_stream() already documents
    for the sibling settings-option pool) so every stream starts directly
    on its first real control/glyph word."""
    gm = dc.load_glyphmap()
    tokens = []
    i = off
    for _ in range(max_words):
        w = struct.unpack_from("<H", data, i)[0]
        tag = _classify_word_ui_grid(w, gm)
        if tag == "END":
            tokens.append({"kind": "end", "off": i, "word": w, "payload": None})
            return tokens
        if tag == "PAGE":
            tokens.append({"kind": "page", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "LINE":
            tokens.append({"kind": "line", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "SPACE":
            tokens.append({"kind": "space", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "HL":
            tokens.append({"kind": "hl", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "ICON":
            tokens.append({"kind": "icon", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "SETUP":
            tokens.append({"kind": "setup", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "PEN0":
            tokens.append({"kind": "pen0", "off": i, "word": w, "payload": None})
            i += 2
            continue
        if tag == "PARAM8":
            payload_off = i + 2
            payload = bytes(data[payload_off:payload_off + 8])
            tokens.append({"kind": "param8", "off": i, "word": w, "payload": payload})
            i = payload_off + 8
            continue
        if dc.SPK_LO <= w <= dc.SPK_HI:
            tokens.append({"kind": "speaker", "off": i, "word": w, "payload": None})
            i += 2
            continue
        key = str(w)
        if key not in gm or not gm[key]:
            raise EncodeError(
                f"decode_ui_grid_stream: unrecognized word {w:#06x} at offset {i:#x} "
                f"(stream started {off:#x})")
        tokens.append({"kind": "glyph", "off": i, "word": w, "payload": None})
        i += 2
    raise EncodeError(f"decode_ui_grid_stream: no END found within {max_words} words of {off:#x}")


def _glyph_runs(tokens):
    """Every maximal run of consecutive kind=='glyph' tokens, as a list of
    (start_index, end_index_exclusive) pairs into `tokens`."""
    runs = []
    i, n = 0, len(tokens)
    while i < n:
        if tokens[i]["kind"] == "glyph":
            j = i
            while j < n and tokens[j]["kind"] == "glyph":
                j += 1
            runs.append((i, j))
            i = j
        else:
            i += 1
    return runs


def encode_pen0_positional_stream(jp_stream_bytes, replacements, rev):
    """Refuse retired authoring; the original encoder remains in Git a55731d5."""
    raise EncodeError(
        "reference-only: use tools/go with reviewed positional-label recipes; "
        "see tools/go/MIGRATION.md"
    )


if __name__ == "__main__":
    import json
    ELF_PATH = ROOT / "extracted" / "iso-root" / "SLPM_657.50"
    elf_bytes = ELF_PATH.read_bytes()
    rev = dc.load_rev()

    reg = json.load(open(ROOT / "registry" / "string-registry.json"))
    by_id = {e["id"]: e for e in reg["entries"]}
    vma_str = sys.argv[1]
    e = by_id[vma_str]
    stream = encode_entry_from_elf(e["en"], int(vma_str, 16), elf_bytes, rev)
    print(f"{vma_str}: en={e['en']!r}")
    print(f"encoded {len(stream)} bytes: {stream.hex(' ')}")
    toks = dc.decode_structured(stream, 0)
    print("round-trip decode:", dc.stream_text(toks, rev))
