#!/usr/bin/env python3
r"""batch_e_art.py - hook functions (tools/make_batch_c_png.py "hook" ops and
"maskfn" allow shapes) for explainer batch E (2026-10-01):

  win_w / win_fw / TEXTURES win_w   週間報告 / 最終報告 header, 昇給 stamp
  op_p                              決定 + the 10 colour-select names
  command\button                    16 kanji command icons
  sale                              4 shop signs
  dk-1 / f_title / casino / race    水曜エンタメ logo + per-show title
  food_t                            Food Battle logo, bracket header, 優勝 burst
  title / allmap_1 / allmap_2       ドカポン・ザ・ワールド logo (option A English)

Owner rules (2026-10-01): edits strictly inside the inner border lines (frame
byte-identical, proven by the allow mask: make_batch_c_png restores every pixel
outside it and the scratch-ISO verify re-checks the read-back); no flat or dark
boxes behind text (the art's own background is rebuilt: flat interiors with
their own colour, textured areas by patch copy from the same texture);
original colours (the driver snaps to colours already in the texture) and
outline style; centred against the neighbouring references; neighbouring
glyphs never clipped.  The approved rank cells of win_w/win_fw (1/2/3/4,
x < 868) are outside every allow mask.

Lettering: Noto Sans (SIL OFL 1.1, /usr/share/fonts/google-noto/), rendered
here at 4x supersampling; strokes/shadows/bevels are built from the
supersampled coverage.  No game or proprietary font is used.
"""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage as ndi

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_explainer_png as mx  # noqa: E402
from batch_d_banner_art import fast_exemplar  # noqa: E402

SS = 4
FD = "/usr/share/fonts/google-noto/NotoSans-"


# ------------------------------------------------------------------ geometry
def rect_mask(shape, r):
    m = np.zeros(shape[:2], bool)
    x, y, w, h = r
    m[max(0, y):y + h, max(0, x):x + w] = True
    return m


def disc_mask(shape, cx, cy, r):
    H, W = shape[:2]
    yy, xx = np.mgrid[0:H, 0:W]
    # a pixel is inside only when its far corner is inside (whole pixel)
    dx = np.abs(xx + 0.5 - cx) + 0.5
    dy = np.abs(yy + 0.5 - cy) + 0.5
    return dx * dx + dy * dy <= r * r


def lum(a):
    return mx.lum(a)


def sat(a):
    c = a[..., :3].astype(np.int32)
    return c.max(axis=2) - c.min(axis=2)


# ------------------------------------------------------------------ lettering
def font(name, px):
    path = name if name.endswith(".ttf") else FD + name + ".ttf"
    return ImageFont.truetype(path, max(1, int(round(px * SS))))


def cap_px(name, cap):
    """font px giving cap height `cap` (texture px)."""
    f = font(name, 100)
    bb = f.getbbox("H", anchor="ls")
    return cap * 100.0 / (-bb[1] / SS)


class Glyphs:
    """supersampled coverage of one text line, positioned in texture space.
    cx = horizontal centre of the INK, cy = centre of the cap height (or of the
    ink when valign='ink'); sx/sy scale, skew (letters lean right for > 0),
    rot (degrees ccw about the centre), tracking (texture px between letters)."""

    def __init__(self, shape, text, name, cap, cx, cy, sx=1.0, sy=1.0, skew=0.0, rot=0.0,
                 tracking=0.0, valign="cap", word_space=None):
        H, W = shape[:2]
        px = cap_px(name, cap)
        f = font(name, px)
        if word_space is not None:
            text = text.replace(" ", word_space)
        trk = tracking * SS / sx
        # draw each char (tracking) on a generous canvas
        tw = sum(f.getlength(c) for c in text) + trk * max(0, len(text) - 1)
        asc, desc = f.getmetrics()
        pad = int(4 * SS + cap * SS)
        cw, ch = int(tw + 2 * pad), int(asc + desc + 2 * pad)
        img = Image.new("L", (cw, ch), 0)
        d = ImageDraw.Draw(img)
        x = pad
        base = pad + asc
        for c in text:
            d.text((x, base), c, font=f, fill=255, anchor="ls")
            x += f.getlength(c) + trk
        capss = -f.getbbox("H", anchor="ls")[1]
        if sx != 1.0 or sy != 1.0:
            img = img.resize((max(1, int(round(cw * sx))), max(1, int(round(ch * sy)))), Image.LANCZOS)
            base *= sy
            capss *= sy
        if skew:
            lw, lh = img.size
            img = img.transform((lw, lh), Image.AFFINE, (1, skew, -skew * base, 0, 1, 0), resample=Image.BICUBIC)
        g = np.array(img).astype(np.float32) / 255.0
        ys, xs = np.nonzero(g > 0.02)
        if valign == "ink":
            ccy = (ys.min() + ys.max() + 1) / 2.0
        else:
            ccy = base - capss / 2.0
        ccx = (xs.min() + xs.max() + 1) / 2.0
        if rot:
            im2 = Image.fromarray((g * 255).astype(np.uint8), "L")
            im2 = im2.rotate(rot, resample=Image.BICUBIC, center=(ccx, ccy))
            g = np.array(im2).astype(np.float32) / 255.0
        # place on the full supersampled canvas (only the needed window is kept)
        ox = int(round(cx * SS - ccx))
        oy = int(round(cy * SS - ccy))
        self.shape = (H, W)
        self.full = np.zeros((H * SS, W * SS), np.float32)
        gh, gw = g.shape
        X0, Y0 = max(0, ox), max(0, oy)
        X1, Y1 = min(W * SS, ox + gw), min(H * SS, oy + gh)
        lost = g.sum() - g[Y0 - oy:Y1 - oy, X0 - ox:X1 - ox].sum()
        if lost > 1:
            raise SystemExit("text %r runs off the texture" % text)
        self.full[Y0:Y1, X0:X1] = g[Y0 - oy:Y1 - oy, X0 - ox:X1 - ox]
        ys, xs = np.nonzero(self.full > 0.02)
        self.ink = (xs.min() / SS, ys.min() / SS, (xs.max() + 1) / SS, (ys.max() + 1) / SS)
        self.cap = cap


def ink_width(text, name, cap, sx=1.0, tracking=0.0, word_space=None):
    g = Glyphs((max(64, int(cap * 3)), int(len(text) * cap * 2 + 64)), text, name, cap,
               len(text) * cap + 32, cap * 1.5, sx=sx, tracking=tracking, word_space=word_space)
    return g.ink[2] - g.ink[0]


def fit_cap(text, name, cap, max_w, sx=1.0, tracking=0.0, word_space=None, min_cap=4):
    """largest cap <= cap whose ink width fits max_w."""
    c = cap
    while c > min_cap and ink_width(text, name, c, sx, tracking, word_space) > max_w:
        c -= 0.25
    return c


def dil_ss(m, r):
    """grey dilation of a supersampled coverage (0..1) by a disc of radius r texture px."""
    if r <= 0:
        return m
    u8 = np.clip(m * 255, 0, 255).astype(np.uint8)
    return mx.dilate(u8, int(round(r * SS))).astype(np.float32) / 255.0


def shift_ss(m, dx, dy):
    """shift a supersampled map by (dx, dy) texture px (rounded to 1/SS)."""
    dx, dy = int(round(dx * SS)), int(round(dy * SS))
    r = np.zeros_like(m)
    h, w = m.shape
    r[max(0, dy):h + min(0, dy), max(0, dx):w + min(0, dx)] = \
        m[max(0, -dy):h - max(0, dy), max(0, -dx):w - max(0, dx)]
    return r


def blur_ss(m, r):
    return ndi.gaussian_filter(m, r * SS) if r > 0 else m


class Layer:
    """supersampled RGBA accumulator; paint(alpha, colour-or-image) composites
    'over'; down() averages premultiplied colour to texture resolution."""

    def __init__(self, shape):
        H, W = shape[:2]
        self.H, self.W = H, W
        self.rgb = np.zeros((H * SS, W * SS, 3), np.float32)
        self.a = np.zeros((H * SS, W * SS), np.float32)

    def paint(self, alpha, colour):
        al = np.clip(alpha, 0, 1)
        c = np.asarray(colour, np.float32)
        if c.ndim == 1:
            c = c[:3]
        else:
            c = c[..., :3]
        self.rgb = c * al[..., None] + self.rgb * (1 - al[..., None])
        self.a = al + self.a * (1 - al)

    def down(self):
        H, W = self.H, self.W
        pre = (self.rgb * self.a[..., None]).reshape(H, SS, W, SS, 3).mean(axis=(1, 3))
        al = self.a.reshape(H, SS, W, SS).mean(axis=(1, 3))
        with np.errstate(invalid="ignore", divide="ignore"):
            rgb = np.where(al[..., None] > 0, pre / al[..., None], 0)
        return np.dstack([rgb, al * 255]).astype(np.float32)


def up(img):
    """nearest upsample of a texture-res (H,W,C) image to supersampled."""
    return np.repeat(np.repeat(img, SS, axis=0), SS, axis=1)


def vgrad(shape, y0, y1, stops):
    """supersampled vertical gradient image between texture rows y0..y1."""
    H, W = shape[:2]
    ys = (np.arange(H * SS) + 0.5) / SS
    t = np.clip((ys - y0) / max(1e-6, (y1 - y0)), 0, 1) * (len(stops) - 1)
    i0 = np.floor(t).astype(int)
    i1 = np.minimum(i0 + 1, len(stops) - 1)
    f = (t - i0)[:, None]
    S = np.array([s[:3] for s in stops], np.float32)
    rows = S[i0] * (1 - f) + S[i1] * f
    return np.broadcast_to(rows[:, None, :], (H * SS, W * SS, 3))


def put(a, layer, allow, key, what, orig=None):
    """composite a texture-res float layer over a; abort if any of it falls
    outside allow (a clipped letter would otherwise be silently restored).
    With orig: a pixel outside allow whose ORIGINAL is already (almost) what the
    layer paints there (e.g. new black outline meeting a neighbour's black
    outline) is not a leak: the driver keeps the original, which looks the same."""
    vis = layer[..., 3] > 0.5
    leak = vis & ~allow
    if orig is not None and leak.any():
        same = (orig[..., 3] >= 200) & (np.abs(orig[..., :3].astype(np.float32) - layer[..., :3]).max(axis=2) <= 40)
        leak &= ~same
    if leak.any():
        ys, xs = np.nonzero(leak)
        raise SystemExit("%s: %s leaks %d px outside allow, e.g. %s" % (
            key, what, len(xs), list(zip(xs.tolist(), ys.tolist()))[:6]))
    mx.composite(a, layer)


def rebuild(a, hole, valid, P=4, win=40, seed=1):
    """patch-copy rebuild of `hole` from `valid & ~hole` pixels of a (in place)."""
    if hole.any():
        a[:] = fast_exemplar(a, hole, valid, P=P, win=win, seed=seed)


def orig_colour_image(orig, src_mask):
    """texture-res image whose every pixel = the nearest ORIGINAL pixel inside src_mask."""
    _, (iy, ix) = ndi.distance_transform_edt(~src_mask, return_indices=True)
    return orig[iy, ix].astype(np.float32)


# ------------------------------------------------------------------ win_w / win_fw
WIN = {
    # key: header text, stamp params
    "win_w": {"head": "Weekly Report"},
    "win_fw": {"head": "Final Report"},
    "tx_win_w": {"head": "Weekly Report"},
}
HEAD_REGION = (182, 12, 288, 63)      # x 182..469, y 12..74: between panel top and the dotted rule
HEAD_LOW = (186, 75, 270, 3)          # rows 75..77 between the rule's end dots (descender room)
STAMP_C = (911.5, 44.5)
STAMP_INSET = 0.25                    # allow = whole pixels inside (inner ring radius - inset)


def stamp_inner_r(orig):
    """radius of the red interior inside the stamp's thin white ring (median of
    rays; kanji strokes that merge into the ring are ignored by the median)."""
    cx, cy = STAMP_C
    white = (orig[..., 1] > 150) & (orig[..., 3] > 128)
    rs = []
    for ang in np.linspace(0, 2 * np.pi, 180, endpoint=False):
        # walk inward from the outer rim: rim (white) -> band (red) -> ring (white)
        state, inner = 0, None
        for r in np.arange(44, 10, -0.25):
            x, y = int(cx + r * np.cos(ang)), int(cy + r * np.sin(ang))
            w = white[y, x]
            if state == 0 and w:
                state = 1
            elif state == 1 and not w and orig[y, x, 3] > 128:
                state = 2
            elif state == 2 and w:
                state = 3
            elif state == 3 and not w:
                inner = r
                break
        if inner:
            rs.append(inner)
    return float(np.median(rs))


def win_allow(orig, s):
    key = s["key"]
    m = rect_mask(orig.shape, HEAD_REGION) | rect_mask(orig.shape, HEAD_LOW)
    r = stamp_inner_r(orig) - STAMP_INSET
    m |= disc_mask(orig.shape, STAMP_C[0], STAMP_C[1], r)
    m[:, 640:868] = False          # rank cells 1/2/3/4 (approved) and panel gap: never touched
    return m


def head_footprint(orig):
    x, y, w, h = HEAD_REGION
    sub = orig[y:y + h, x:x + w]
    m = (sat(sub) < 60) | (lum(sub) < 120)
    m = ndi.binary_fill_holes(m)
    m = ndi.binary_opening(m, np.ones((2, 2), bool)) | (lum(sub) < 90)
    out = np.zeros(orig.shape[:2], bool)
    out[y:y + h, x:x + w] = m
    return mx.grow(out, 2) & rect_mask(orig.shape, HEAD_REGION)


def draw_head(a, allow, key, text, cx, cy, cap, name="CondensedBold", max_w=268):
    """white letters, grey bevel on the upper-left inner edge, ~2.5 px black
    outline, soft dark drop shadow to the lower right (the old header's style)."""
    cap = fit_cap(text, name, cap, max_w)
    g = Glyphs(a.shape, text, name, cap, cx, cy)
    G = g.full
    out = dil_ss(G, 2.4)
    lay = Layer(a.shape)
    sh = blur_ss(shift_ss(dil_ss(G, 2.6), 1.5, 2.0), 0.9)
    lay.paint(sh * 0.55, (40, 25, 10))
    lay.paint(out, (0, 0, 0))
    lay.paint(G, (255, 255, 255))
    # bevel: interior pixels near the upper-left edge go grey (gradient)
    inner = np.clip(G - shift_ss(G, 1.6, 1.6), 0, 1) * G
    lay.paint(inner * 0.75, (150, 150, 150))
    put(a, lay.down(), allow, key, "header %r" % text)
    return cap, g.ink


def draw_stamp(a, allow, key, lines, cx, cy, r_in, rot=0.0, name="CondensedBlack"):
    """white lettering on the stamp's flat red (the old kanji were clean white)."""
    lay = Layer(a.shape)
    n = len(lines)
    # sizes: fit every line inside the disc (chord width at the line's rows)
    gap = 0.18
    cap = r_in * (0.62 if n == 1 else 0.48)
    for _ in range(200):
        tot = cap * n + cap * gap * 2.2 * (n - 1)
        ok = True
        for i, t in enumerate(lines):
            yc = -tot / 2 + cap / 2 + i * (cap + cap * gap * 2.2)
            yy = max(abs(yc - cap / 2), abs(yc + cap / 2))
            chord = 2 * np.sqrt(max(0, r_in * r_in - yy * yy)) - 5
            if ink_width(t, name, cap) > chord:
                ok = False
        if ok:
            break
        cap -= 0.25
    tot = cap * n + cap * gap * 2.2 * (n - 1)
    G = np.zeros((a.shape[0] * SS, a.shape[1] * SS), np.float32)
    for i, t in enumerate(lines):
        yc = cy - tot / 2 + cap / 2 + i * (cap + cap * gap * 2.2)
        G = np.maximum(G, Glyphs(a.shape, t, name, cap, cx, yc).full)
    if rot:
        im = Image.fromarray((G * 255).astype(np.uint8), "L").rotate(rot, resample=Image.BICUBIC,
                                                                     center=(cx * SS, cy * SS))
        G = np.array(im).astype(np.float32) / 255
    lay.paint(G, (255, 255, 255))
    put(a, lay.down(), allow, key, "stamp %r" % (lines,))
    return cap


def win(a, orig, o, colors, allow):
    key = o["key"]
    # header: erase the kanji (+ outline/shadow), rebuild the map parchment
    hole = head_footprint(orig) & allow
    valid = rect_mask(a.shape, HEAD_REGION) & allow
    rebuild(a, hole, valid, P=4, win=60, seed=3)
    draw_head(a, allow, key, o["head"], o.get("head_cx", 320.0), o.get("head_cy", 45.0), o.get("head_cap", 29))
    # stamp: interior is flat red (206,0,0) -> repaint it, then the new words
    r = stamp_inner_r(orig) - STAMP_INSET
    disc = disc_mask(a.shape, STAMP_C[0], STAMP_C[1], r) & allow
    a[disc] = (206, 0, 0, 255)
    draw_stamp(a, allow, key, o["stamp"], STAMP_C[0], STAMP_C[1], r, rot=o.get("stamp_rot", 0.0))


# ------------------------------------------------------------------ op_p (colour select)
# sheet-1 icon cells (rect table ELF 0x52e880, 16 B/cell; colour tokens <4877>..<4880>
# = cells 19..28, 決定 = cell 29 (385,3,50,28), the F069 'Ok!' sprite)
OP_COLOURS = [  # cell rect, JP, EN (= registry colour vocabulary 0x534af0..0x534b3c)
    ((205, 254, 83, 19), "あか", "Red"), ((205, 283, 83, 19), "オレンジ", "Orange"),
    ((205, 312, 83, 19), "きいろ", "Yellow"), ((205, 341, 83, 19), "きみどり", "Lime Green"),
    ((205, 370, 83, 19), "みどり", "Green"), ((309, 254, 83, 19), "みずいろ", "Light Blue"),
    ((309, 283, 83, 19), "あお", "Blue"), ((309, 312, 83, 19), "ピンク", "Pink"),
    ((309, 341, 83, 19), "くろ", "Black"), ((309, 370, 83, 19), "しろ", "White")]
OP_LABEL_X0 = 28          # label area starts 28 px into the cell (swatch = cell x+2..x+25)
OP_OK = (385, 3, 50, 28)


def op_label_rect(cell):
    x, y, w, h = cell
    return (x + OP_LABEL_X0, y + 1, w - OP_LABEL_X0 - 1, h - 2)


def op_allow(orig, s):
    m = np.zeros(orig.shape[:2], bool)
    for cell, _, _ in OP_COLOURS:
        m |= rect_mask(orig.shape, op_label_rect(cell))
    m |= rect_mask(orig.shape, OP_OK)    # a frameless sprite: its outline touches the cell edge
    return m


def clear_px(orig, rect):
    """most common fully transparent RGBA inside rect (erasing = this value)."""
    x, y, w, h = rect
    sub = orig[y:y + h, x:x + w].reshape(-1, 4)
    t = sub[sub[:, 3] == 0]
    if not len(t):
        return np.array([0, 0, 0, 0], np.uint8)
    u, n = np.unique(t, axis=0, return_counts=True)
    return u[np.argmax(n)]


def op_p(a, orig, o, colors, allow):
    key = o["key"]
    name = o.get("font", "CondensedBold")
    # one size for all ten names: the widest must fit the label area (2 px margin)
    cap = o.get("cap", 9.0)
    w_max = OP_COLOURS[0][0][2] - OP_LABEL_X0 - 1 - 4
    for _, _, en in OP_COLOURS:
        cap = min(cap, fit_cap(en, name, cap, w_max))
    for cell, jp, en in OP_COLOURS:
        r = op_label_rect(cell)
        a[rect_mask(a.shape, r) & allow] = clear_px(orig, r)
        x, y, w, h = r
        # centre on the old label's centre (the JP names are centred in the label area)
        lay = Layer(a.shape)
        g = Glyphs(a.shape, en, name, cap, x + w / 2.0, y + h / 2.0)
        lay.paint(g.full, (0, 0, 0))
        put(a, lay.down(), allow, key, en)
    # 決定 -> OK! : white, ~2 px black outline like the old sprite
    x, y, w, h = OP_OK
    a[rect_mask(a.shape, OP_OK) & allow] = clear_px(orig, (380, 3, 5, 28))
    lay = Layer(a.shape)
    t = o.get("ok", "OK!")
    okcap = fit_cap(t, "CondensedBlack", o.get("ok_cap", 15), w - 10)
    g = Glyphs(a.shape, t, "CondensedBlack", okcap, x + w / 2.0, y + h / 2.0)
    lay.paint(dil_ss(g.full, 2.0), (0, 0, 0))
    lay.paint(g.full, (255, 255, 255))
    put(a, lay.down(), allow, key, t)
    o["_report"] = "colour cap %.2f, OK cap %.2f" % (cap, okcap)


# ------------------------------------------------------------------ command\button
# 4x4 grid of 32x32 round icons (cell i at (32*(i%4), 32*(i//4))).  The menu
# labels next to them are already English (registry 0x535720..0x535880); the icon
# gets a short word, or a pictogram where a word does not fit (sword, shield).
BUTTONS = [  # kanji, english (menu terms: 襲う Attack, 金庫 Vault, 出る Leave, 去る Depart)
    ("買", "BUY"), ("売", "SELL"), ("出", "LEAVE"), ("襲", "ATK"),
    ("泊", "STAY"), ("使", "USE"), ("職", "JOB"), ("鞄", "BAG"),
    ("贈", "GIFT"), ("金", "VAULT"), ("治", "CURE"), ("体", "HP"),
    ("武", "@sword"), ("盾", "@shield"), ("去", "EXIT"), ("確", "OK")]


def button_disc(orig, i):
    x, y = 32 * (i % 4), 32 * (i // 4)
    m = np.zeros(orig.shape[:2], bool)
    sub = orig[y:y + 32, x:x + 32, 3] > 128
    sub = ndi.binary_fill_holes(sub)
    # keep the disc's outer black ring (1 px) + its anti-aliased rim
    m[y:y + 32, x:x + 32] = ndi.binary_erosion(sub, np.ones((3, 3), bool), iterations=1)
    return m


def button_allow(orig, s):
    m = np.zeros(orig.shape[:2], bool)
    for i in range(16):
        m |= button_disc(orig, i)
    return m


def old_glyph(orig, disc):
    """the old kanji (+ its dark-grey AA) inside a disc: anything not near-black."""
    c = orig[..., :3].astype(np.int32)
    return disc & (c.max(axis=2) >= 40)


def row_profile(orig, gm):
    """median colour of the old glyph per row -> (ys, colours) for remapping."""
    ys = np.unique(np.nonzero(gm)[0])
    cols = []
    for y in ys:
        px = orig[y][gm[y]][:, :3].astype(np.float32)
        br = px.max(axis=1)
        px = px[br >= np.percentile(br, 50)]      # bright core, not the AA fringe
        cols.append(np.median(px, axis=0))
    return ys, np.array(cols)


def profile_fill(shape, ys, cols, y0, y1):
    """supersampled colour image: rows y0..y1 of the new glyph take the old
    glyph's per-row colours, stretched linearly."""
    H, W = shape[:2]
    yy = (np.arange(H * SS) + 0.5) / SS
    t = np.clip((yy - y0) / max(1e-6, y1 - y0), 0, 1)
    src = ys[0] + t * (ys[-1] - ys[0])
    rows = np.stack([np.interp(src, ys, cols[:, c]) for c in range(3)], axis=1)
    return np.broadcast_to(rows[:, None, :], (H * SS, W * SS, 3))


def pictogram(shape, kind, cx, cy, s):
    """white silhouette (supersampled coverage) of a sword or shield, height ~2s."""
    H, W = shape[:2]
    img = Image.new("L", (W * SS, H * SS), 0)
    d = ImageDraw.Draw(img)

    def P(pts):
        return [((cx + x * s) * SS, (cy + y * s) * SS) for x, y in pts]
    if kind == "sword":   # diagonal sword, point to the upper right
        import math
        ang = math.radians(-45)
        ca, sa = math.cos(ang), math.sin(ang)

        def R(pts):
            return [(x * ca + y * sa, -x * sa + y * ca) for x, y in pts]
        blade = [(0, -1.0), (0.21, -0.76), (0.21, 0.28), (-0.21, 0.28), (-0.21, -0.76)]
        guard = [(-0.52, 0.28), (0.52, 0.28), (0.52, 0.47), (-0.52, 0.47)]
        grip = [(-0.12, 0.47), (0.12, 0.47), (0.12, 0.80), (-0.12, 0.80)]
        pom = [(-0.20, 0.80), (0.20, 0.80), (0.20, 1.0), (-0.20, 1.0)]
        for part in (blade, guard, grip, pom):
            d.polygon(P(R(part)), fill=255)
    else:                 # heater shield with a dark inner line
        pts = [(-0.80, -0.95), (0.0, -0.80), (0.80, -0.95), (0.80, 0.05)]
        p0, c1, p2 = (0.80, 0.05), (0.76, 0.62), (0.0, 1.0)
        for t in np.linspace(0, 1, 16)[1:]:
            pts.append(((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * c1[0] + t * t * p2[0],
                        (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * c1[1] + t * t * p2[1]))
        pts += [(-x, y) for x, y in reversed(pts[3:-1])]
        d.polygon(P(pts), fill=255)
        inner = [(x * 0.62, y * 0.62 - 0.06) for x, y in pts]
        d.polygon(P(inner), fill=0)
        inner2 = [(x * 0.42, y * 0.42 - 0.08) for x, y in pts]
        d.polygon(P(inner2), fill=255)
    return np.array(img).astype(np.float32) / 255


def button(a, orig, o, colors, allow):
    key = o["key"]
    name = o.get("font", "CondensedBlack")
    black = np.array([0, 0, 0, 255], np.uint8)
    rep = []
    for i, (jp, en) in enumerate(BUTTONS):
        disc = button_disc(orig, i) & allow
        gm = old_glyph(orig, disc)
        ys, cols = row_profile(orig, gm)
        # the disc interior is flat black: repaint it (old kanji + its AA gone)
        dark = orig[disc & ~mx.grow(gm, 1)][:, :3]
        fillc = np.median(dark, axis=0) if len(dark) else black[:3]
        a[disc] = np.append(np.rint(fillc), 255).astype(np.uint8)
        cx, cy = 32 * (i % 4) + 16.0, 32 * (i // 4) + 16.0
        lay = Layer(a.shape)
        if en.startswith("@"):
            sc = 13.0 if en == "@sword" else 10.5
            G = pictogram(a.shape, en[1:], cx, cy, sc)
            y0, y1 = cy - sc * 0.8, cy + sc * 0.8
        else:
            r_in = 13.5
            best = None
            for fn in (name, "ExtraCondensedBlack"):
                cap = 11.0 if len(en) <= 2 else (10.5 if len(en) == 3 else 10.0)
                while cap > 5:
                    yy = cap / 2 + 0.5
                    chord = 2 * np.sqrt(r_in * r_in - yy * yy) - 2.0
                    if ink_width(en, fn, cap) <= chord:
                        break
                    cap -= 0.25
                # ExtraCondensed only when it buys >= 1.5 px of cap height
                if best is None or cap >= best[1] + 1.5:
                    best = (fn, cap)
            fn, cap = best
            g = Glyphs(a.shape, en, fn, cap, cx, cy)
            G = g.full
            y0, y1 = g.ink[1], g.ink[3]
            rep.append("%s=%s %s cap %.2f" % (jp, en, fn, cap))
        lay.paint(G, profile_fill(a.shape, ys, cols, y0, y1))
        put(a, lay.down(), allow, key, en)
    o["_report"] = ", ".join(rep)


# ------------------------------------------------------------------ sale (shop signs)
# 4 sprite cells (20, 32*k, 87, 32), rect table ELF 0x4ecbe0.  Cells 0/1 keep their
# English '40%OFF' / '20%OFF' second line; only the katakana first line changes.
SALE = [  # cell index, allow rows (y0, y1 incl.), JP, lines [(text, font, cap, cy)], colour key
    (0, (0, 17), "バーゲンセール", [("BARGAIN SALE", "CondensedBlackItalic", 9.75, 8.0)], "Y"),
    (1, (32, 49), "サンデーセール", [("SUNDAY SALE", "CondensedBlackItalic", 9.75, 40.0)], "R"),
    (2, (66, 95), "定休日", [("CLOSED", "CondensedBlack", 15.0, 79.5)], "R"),
    (3, (97, 126), "臨時休業", [("TEMPORARILY", "CondensedBlack", 9.5, 104.5),
                               ("CLOSED", "CondensedBlack", 9.5, 117.5)], "R"),
]
SALE_X = (20, 87)
SALE_OUTLINE = 2.6


def sale_colour(orig, k):
    c = orig[..., :3].astype(np.int32)
    if k == "Y":
        return (c[..., 0] > 200) & (c[..., 1] > 170) & (c[..., 2] < 120)
    return (c[..., 0] > 150) & (c[..., 1] < 100)


def sale_regions(orig):
    """per sign: (allow mask, protected second-line mask)."""
    out = []
    for idx, (y0, y1), jp, lines, ck in SALE:
        reg = rect_mask(orig.shape, (SALE_X[0], y0, SALE_X[1], y1 - y0 + 1))
        prot = np.zeros(orig.shape[:2], bool)
        if idx in (0, 1):
            # the English second line: its coloured glyphs (+ white %OFF) below the first
            # line, grown by the outline width -> never touched
            cy = 32 * idx
            band = rect_mask(orig.shape, (SALE_X[0], cy + 17, SALE_X[1], 15))
            c = orig[..., :3].astype(np.int32)
            glyph = band & (orig[..., 3] > 40) & (c.max(axis=2) > 90)
            prot = ndi.binary_dilation(glyph, np.ones((3, 3), bool), iterations=3)
        out.append((reg & ~prot, prot))
    return out


def sale_allow(orig, s):
    m = np.zeros(orig.shape[:2], bool)
    for reg, _ in sale_regions(orig):
        m |= reg
    return m


def sale(a, orig, o, colors, allow):
    key = o["key"]
    regs = sale_regions(orig)
    for (idx, (y0, y1), jp, lines, ck), (reg, prot) in zip(SALE, regs):
        reg = reg & allow
        oldc = sale_colour(orig, ck) & reg
        ys, cols = row_profile(orig, oldc)
        # erase: the old line (coloured glyphs + outline) -> transparent; pixels of the
        # protected second line's outline stay as they are (outside reg)
        a[reg] = clear_px(orig, (0, 0, 20, 128))
        lay = Layer(a.shape)
        G = np.zeros((a.shape[0] * SS, a.shape[1] * SS), np.float32)
        y_top, y_bot = 1e9, -1e9
        for text, fn, cap, cy in lines:
            cap = fit_cap(text, fn, cap, SALE_X[1] - 2 * SALE_OUTLINE - 4)
            g = Glyphs(a.shape, text, fn, cap, SALE_X[0] + SALE_X[1] / 2.0, cy)
            G = np.maximum(G, g.full)
            y_top, y_bot = min(y_top, g.ink[1]), max(y_bot, g.ink[3])
        lay.paint(dil_ss(G, SALE_OUTLINE), (0, 0, 0))
        lay.paint(G, profile_fill(a.shape, ys, cols, y_top, y_bot))
        put(a, lay.down(), allow, key, jp, orig=orig)


# ------------------------------------------------------------------ 水曜エンタメ logo
# Same art at the same place in EVENT dk-1/dk-1, food/f_title, not30/casino, race/race
# (1024x512 'nohdr'; logo inside x 200..445, y 55..228).  Three lettering groups:
#   top  みんなで対決!!  red->yellow, white + dark outline   -> SHOWDOWN FOR ALL!!
#   mid  水曜            blue, white bevel + dark outline     -> WEDNESDAY
#   bot  エンタメ        grungy brown-red, white + black      -> SHOWTIME!
# The English 'DOKAPON / WednesDay Entertainment' below the logo is untouched.
WED = {
    "top": {"box": (225, 58, 418, 90), "text": "SHOWDOWN FOR ALL!!", "font": "ExtraCondensedBlack",
            "cap": 14.0, "cx": 321.0, "cy": 77.0, "max_w": 182, "sy": 1.15, "skew": 0.10},
    "mid": {"box": (266, 94, 376, 166), "text": "WEDNESDAY", "font": "ExtraCondensedBlack",
            "cap": 24.0, "cx": 321.0, "cy": 128.0, "max_w": 168, "sy": 1.45, "skew": 0.0},
    "bot": {"box": (200, 150, 445, 228), "text": "SHOWTIME!", "font": "ExtraCondensedBlack",
            "cap": 30.0, "cx": 324.0, "cy": 191.0, "max_w": 214, "sy": 1.25, "skew": 0.12},
}
WED_LOGO_BOX = (200, 52, 248, 178)       # x 200..447, y 52..229
WED_RING = (320.23, 131.13, 31.0, 48.0)   # gold ring: centre, radii rebuilt by ring_polar (fit on dk-1)


def ring_polar(a, hole, cx, cy, r0, r1, unknown=None):
    """fill hole pixels with r0 <= radius <= r1 by periodic linear interpolation in
    angle between the known pixels (not in `unknown`, default hole) of the same
    0.5 px radius bin.  Returns the mask of pixels filled."""
    if unknown is None:
        unknown = hole
    H, W = hole.shape
    yy, xx = np.mgrid[0:H, 0:W]
    d = np.hypot(xx + 0.5 - cx, yy + 0.5 - cy)
    th = np.arctan2(yy + 0.5 - cy, xx + 0.5 - cx)
    ann = (d >= r0) & (d <= r1)
    done = np.zeros_like(hole)
    rb = np.rint(d * 2).astype(int)
    for k in np.unique(rb[ann & hole]):
        sel = ann & (rb == k)
        kn = sel & ~unknown
        tg = sel & hole
        if kn.sum() < 3:
            continue
        t_k = th[kn]
        o = np.argsort(t_k)
        t_k = t_k[o]
        for c in range(4):
            v = a[..., c][kn][o].astype(np.float64)
            a[..., c][tg] = np.rint(np.interp(th[tg], t_k, v, period=2 * np.pi)).astype(np.uint8)
        done |= tg
    return done


def _wed_fill(a, part):
    r, g, b = (a[..., i].astype(np.int32) for i in range(3))
    if part == "top":
        return ((r > 150) & (b < 110) & (r > g + 20)) | ((r > 200) & (g > 150) & (b < 90))
    if part == "mid":
        return (b > r + 30) & (b > g + 5) & (b > 60)
    return (r > g + 30) & (b < 100) & (g < 130) & (r > 70)


def wed_footprints(orig):
    """old lettering footprint per group: fill colour (closed, holes filled, big
    components only) grown up to 5 px through non-green pixels (white + dark outline,
    drop shadow)."""
    H, W = orig.shape[:2]
    r, g, b = (orig[..., i].astype(np.int32) for i in range(3))
    greenish = (g > r + 25) & (g > b + 10)
    out = {}
    for part, P in WED.items():
        x0, y0, x1, y1 = P["box"]
        reg = np.zeros((H, W), bool)
        reg[y0:y1, x0:x1] = True
        f = ndi.binary_closing(_wed_fill(orig, part) & reg, np.ones((3, 3), bool))
        f = ndi.binary_fill_holes(f)
        lab, n = ndi.label(f)
        sz = ndi.sum(f, lab, range(1, n + 1))
        keep = 1 + np.nonzero(sz >= (150 if part == "mid" else 12))[0]
        if part == "mid":   # the crown is blue too: keep the components in the ring's middle
            cs = ndi.center_of_mass(f, lab, keep)
            keep = [k for k, (cy, cx) in zip(keep, cs) if 280 <= cx <= 362]
        f = np.isin(lab, keep)
        m = f.copy()
        for _ in range(8 if part == "mid" else 5):   # mid: its dotted drop shadow reaches ~8 px
            m |= ndi.binary_dilation(m, np.ones((3, 3), bool)) & ~greenish & reg
        out[part] = m
    return out


def wed_glyphs(shape):
    gl = {}
    for part, P in WED.items():
        cap = fit_cap(P["text"], P["font"], P["cap"], P["max_w"])
        gl[part] = Glyphs(shape, P["text"], P["font"], cap, P["cx"], P["cy"], sy=P["sy"], skew=P["skew"])
    return gl


WED_OUT = {"top": (1.6, 1.3), "mid": (2.2, 1.6), "bot": (2.2, 1.8)}   # white, dark outline px


def wed_cover(shape, gl):
    """texture-res mask of everything the new lettering paints (glyph + outlines + shadow)."""
    m = np.zeros(shape[:2], bool)
    for part, g in gl.items():
        w, d = WED_OUT[part]
        c = dil_ss(g.full, w + d + 1.6)
        c = np.maximum(c, shift_ss(c, 1.5, 2.5))
        H, W = shape[:2]
        m |= c.reshape(H, SS, W, SS).max(axis=(1, 3)) > 0.01
    return m


def wed_allow(orig, s):
    fp = wed_footprints(orig)
    m = np.zeros(orig.shape[:2], bool)
    for v in fp.values():
        m |= v
    m |= wed_cover(orig.shape, wed_glyphs(orig.shape))
    m &= rect_mask(orig.shape, WED_LOGO_BOX)
    return m


def wed_logo(a, orig, o, colors, allow):
    key = o["key"]
    fp = wed_footprints(orig)
    hole = np.zeros(a.shape[:2], bool)
    for v in fp.values():
        hole |= v
    hole &= allow
    gl = wed_glyphs(a.shape)
    # rebuild everything the new lettering will not paint OPAQUELY (its outline
    # coverage >= 0.98); counters and gaps between letters show the rebuilt art
    H, W = a.shape[:2]
    opaque = np.zeros((H, W), bool)
    for part, g in gl.items():
        w, d = WED_OUT[part]
        c = dil_ss(g.full, w + d).reshape(H, SS, W, SS).mean(axis=(1, 3))
        opaque |= c >= 0.98
    todo = hole & ~opaque
    valid = rect_mask(a.shape, (WED_LOGO_BOX[0] - 30, WED_LOGO_BOX[1] - 20, WED_LOGO_BOX[2] + 60,
                                WED_LOGO_BOX[3] + 30)) & ~hole
    # the gold ring behind 水曜 is a circle: rebuild it by angular interpolation
    # at constant radius from its visible parts, then patch-copy the rest
    # clean ring pixels inside the grown footprint (gold, above the bottom word) are
    # known samples too: they carry the ring's yellow -> orange shading
    r_, g_, b_ = (orig[..., i].astype(np.int32) for i in range(3))
    gold = (r_ > 180) & (g_ > 100) & (b_ < 90) & (r_ > g_) & (np.arange(a.shape[0])[:, None] < 162)
    gold &= ~ndi.binary_dilation(_wed_fill(orig, "mid"), iterations=2)
    ring = ring_polar(a, todo, WED_RING[0], WED_RING[1], WED_RING[2], WED_RING[3], unknown=hole & ~gold)
    todo &= ~ring
    # inside the ring (behind the old 水曜) only scraps of the crown show: give the
    # few uncovered hole pixels there the smooth local colour (normalised low-pass of
    # the known interior pixels), not copies of the crown's blue strokes
    H, W = todo.shape
    yy, xx = np.mgrid[0:H, 0:W]
    inside = np.hypot(xx + 0.5 - WED_RING[0], yy + 0.5 - WED_RING[1]) < WED_RING[2]
    kn = inside & ~hole
    if kn.sum() > 50 and (todo & inside).any():
        from batch_d_banner_art import lowpass
        lp = lowpass(a.astype(np.float32), kn | ring, 3.0)
        t = todo & inside
        a[t] = np.clip(np.rint(lp[t]), 0, 255).astype(np.uint8)
        a[t, 3] = 255
        todo &= ~inside
        ring |= t
    a[todo] = 0
    rebuild(a, todo, (valid | ring | todo), P=4, win=36, seed=5)
    lay = Layer(a.shape)
    for part in ("top", "mid", "bot"):
        g = gl[part]
        G = g.full
        w, d = WED_OUT[part]
        old = _wed_fill(orig, part) & fp[part]
        ys, cols = row_profile(orig, old)
        y0, y1 = g.ink[1], g.ink[3]
        if part == "bot":
            # drop shadow like the old katakana
            lay.paint(blur_ss(shift_ss(dil_ss(G, w + d), 1.2, 2.0), 0.6) * 0.8, (10, 5, 0))
        lay.paint(dil_ss(G, w + d), (12, 10, 20) if part != "bot" else (8, 4, 0))
        lay.paint(dil_ss(G, w), (255, 255, 255))
        if part == "bot":
            src = orig_colour_image(orig, old & ~mx.grow(~old, 2))
            ysrc = np.array([y for y in range(a.shape[0]) if old[y].any()])
            # remap rows of the old grunge surface onto the new letters' rows
            Hs = a.shape[0]
            rows = np.clip(np.interp(np.arange(Hs), [y0, y1], [ysrc.min(), ysrc.max()]), 0, Hs - 1).astype(int)
            tex = src[rows]
            lay.paint(G, up(tex))
        else:
            lay.paint(G, profile_fill(a.shape, ys, cols, y0, y1))
        if part == "mid":   # light bevel on the upper-left inner edge
            inner = np.clip(G - shift_ss(G, 1.2, 1.2), 0, 1) * G
            lay.paint(inner * 0.55, (170, 220, 255))
    put(a, lay.down(), allow, key, "logo")


# ------------------------------------------------------------------ generic titles
# A title = footprint groups (box, colour rule, growth) + English lines.  The old
# lettering (fill colour, closed + holes filled, grown through outline/shadow
# pixels that are not background) is rebuilt by patch copy from the same texture
# except where the new lettering paints opaquely; the new lines reuse the old
# letters' surface (rows of the old letters remapped onto the new letters' rows).
def colour_rule(a, rule):
    r, g, b = (a[..., i].astype(np.int32) for i in range(3))
    al = a[..., 3].astype(np.int32)
    mxc = np.maximum(np.maximum(r, g), b)
    mnc = np.minimum(np.minimum(r, g), b)
    if rule == "warm":          # orange / red / dark red letters
        return (r > g + 40) & (b < 120) & (r > 90) & (al > 64)
    if rule == "fire":          # fire letters: red, orange, yellow, dark red
        return (r > 150) & (b < 110) & (r > g + 10) & (al > 64) | ((r > 90) & (r > g + 50) & (b < 80) & (al > 64))
    if rule == "white":
        return (mnc > 185) & (al > 64)
    if rule == "orange":        # casino orange-yellow gradient letters
        return (r > 200) & (g > 90) & (b < 110) & (r > g + 20) & (al > 64)
    if rule == "red":
        return (r > 150) & (g < 110) & (b < 110) & (al > 64)
    if rule == "blue":
        return (b > r + 30) & (b > g) & (al > 64)
    if rule == "yellow":
        return (r > 200) & (g > 170) & (b < 120) & (al > 64)
    if rule == "dark":
        return (mxc < 90) & (al > 64)
    if rule == "opaque":
        return al > 0
    if rule == "inked":         # opaque and not sticker white (glyph + its outline)
        return (al > 64) & (mnc < 200)
    raise SystemExit("unknown rule %r" % rule)


def background_rule(a, kind):
    r, g, b = (a[..., i].astype(np.int32) for i in range(3))
    if kind == "green":
        return (g > r + 25) & (g > b + 10)
    if kind == "green_blue":   # casino: green background + the blue playing cards
        return ((g > r + 25) & (g > b + 10)) | ((b > r + 30) & (b > g))
    if kind == "not_dark":     # grow only through dark outline pixels
        return np.maximum(np.maximum(r, g), b) >= 90
    if kind == "transparent":
        return a[..., 3] < 8
    if kind == "panel":   # food_t bracket panel: light orange
        return (r > 220) & (g > 170) & (b > 90) & (b < 200) & (r - b > 60)
    raise SystemExit("unknown background %r" % kind)


def title_footprint(orig, groups):
    H, W = orig.shape[:2]
    out = np.zeros((H, W), bool)
    for G in groups:
        x0, y0, x1, y1 = G["box"]
        reg = np.zeros((H, W), bool)
        reg[y0:y1, x0:x1] = True
        f = np.zeros((H, W), bool)
        for rule in G["rules"]:
            f |= colour_rule(orig, rule)
        f &= reg
        f = ndi.binary_closing(f, np.ones((3, 3), bool))
        f = ndi.binary_fill_holes(f)
        lab, n = ndi.label(f)
        if n:
            sz = ndi.sum(f, lab, range(1, n + 1))
            f = np.isin(lab, 1 + np.nonzero(sz >= G.get("min_size", 12))[0])
        bg = background_rule(orig, G.get("bg", "green"))
        m = f.copy()
        for _ in range(G.get("grow", 5)):
            m |= ndi.binary_dilation(m, np.ones((3, 3), bool)) & ~bg & reg
        if G.get("shadow_grow"):
            # the old letters' soft drop shadow is a DARKER background colour: grow
            # through pixels whose green is below shadow_g (the background next to the
            # title is brighter than that)
            r_, g_ = orig[..., 0].astype(np.int32), orig[..., 1].astype(np.int32)
            dk = ((g_ < G.get("shadow_g", 165)) | ((r_ > G.get("halo_r", 999)) & (g_ > r_ + 40))) \
                & (orig[..., 3] > 64)     # darker shadow or light yellow-green halo ring, not the clear surround
            for _ in range(G["shadow_grow"]):
                m |= ndi.binary_dilation(m, np.ones((3, 3), bool)) & dk & reg
        if G.get("pad"):       # unconditional margin (anti-aliased outline ring)
            m = ndi.binary_dilation(m, np.ones((3, 3), bool), iterations=G["pad"]) & reg
        out |= m
    return out


def smooth_fill(a, hole, valid, sigmas=(2.0, 4.0, 8.0, 16.0)):
    """fill hole by normalised convolution of the valid pixels, finest scale that
    has enough support (for soft glows / gradients, where patch copy would leave
    letter-shaped seams)."""
    from batch_d_banner_art import lowpass
    kn = valid & ~hole
    left = hole.copy()
    img = a.astype(np.float32)
    for sg in sigmas:
        w = ndi.gaussian_filter(kn.astype(np.float32), sg)
        est = lowpass(img, kn, sg)
        ok = left & (w > 0.15)
        if sg == sigmas[-1]:
            ok = left
        a[ok] = np.clip(np.rint(est[ok]), 0, 255).astype(np.uint8)
        left &= ~ok
        if not left.any():
            break


def ray_fill(a, hole, valid, cx, cy, max_r=200):
    """fill hole pixels of a radial burst centred on (cx, cy): each takes the
    distance-weighted mix of the first known pixel inward and outward along its
    own ray, so radial streaks continue through the hole."""
    H, W = hole.shape
    c = a[..., :3].astype(np.int32)
    greenish = c[..., 1] > c[..., 0] + 25
    # never sample stray outline/AA pixels; transparent surround is a valid sample
    kn = valid & ~hole & ((c.max(axis=2) >= 170) | greenish | (a[..., 3] < 64))
    ys, xs = np.nonzero(hole)
    dx, dy = xs + 0.5 - cx, ys + 0.5 - cy
    rr = np.hypot(dx, dy) + 1e-6
    ux, uy = dx / rr, dy / rr
    res = []
    for sgn in (1, -1):
        col = np.zeros((len(xs), 4), np.float32)
        dist = np.full(len(xs), np.inf, np.float32)
        todo = np.ones(len(xs), bool)
        for st in range(1, max_r):
            if not todo.any():
                break
            px = np.rint(xs + sgn * ux * st).astype(int)
            py = np.rint(ys + sgn * uy * st).astype(int)
            inside = (px >= 0) & (px < W) & (py >= 0) & (py < H)
            if sgn < 0:     # do not walk through the centre
                inside &= (st < rr)
            hit = todo & inside
            hit[hit] = kn[py[hit], px[hit]]
            col[hit] = a[py[hit], px[hit]]
            dist[hit] = st
            todo &= ~hit
            todo &= inside | ~todo
        res.append((col, dist))
    (c1, d1), (c2, d2) = res
    w1 = np.where(np.isfinite(d1), 1.0 / np.maximum(d1, 1), 0)
    w2 = np.where(np.isfinite(d2), 1.0 / np.maximum(d2, 1), 0)
    tot = np.maximum(w1 + w2, 1e-6)
    # premultiplied: a transparent sample (glow fading out) must not darken the colour
    al = (c1[:, 3] * w1 + c2[:, 3] * w2) / tot
    pw1, pw2 = w1 * c1[:, 3], w2 * c2[:, 3]
    ptot = pw1 + pw2
    rgb = np.where(ptot[:, None] > 0, (c1[:, :3] * pw1[:, None] + c2[:, :3] * pw2[:, None]) /
                   np.maximum(ptot, 1e-6)[:, None], (c1[:, :3] * w1[:, None] + c2[:, :3] * w2[:, None]) / tot[:, None])
    out = np.concatenate([rgb, al[:, None]], axis=1)
    ok = (w1 + w2) > 0
    a[ys[ok], xs[ok]] = np.clip(np.rint(out[ok]), 0, 255).astype(np.uint8)
    left = hole.copy()
    left[ys[ok], xs[ok]] = False
    return left


def title_lines(shape, lines):
    gl = []
    for L in lines:
        cap = fit_cap(L["text"], L["font"], L["cap"], L["max_w"], sx=L.get("sx", 1.0),
                      tracking=L.get("tracking", 0.0))
        gl.append(Glyphs(shape, L["text"], L["font"], cap, L["cx"], L["cy"], sx=L.get("sx", 1.0),
                         sy=L.get("sy", 1.0), skew=L.get("skew", 0.0), tracking=L.get("tracking", 0.0)))
    return gl


def _reach(L):
    return sum(r for r, _ in L.get("outline", [])) + max(abs(L.get("shadow", {}).get("dx", 0)),
                                                         abs(L.get("shadow", {}).get("dy", 0))) \
        + L.get("shadow", {}).get("blur", 0) * 2 + L.get("glow", {}).get("r", 0) * 2.5 + 1.5


def title_cover(shape, lines, gl):
    H, W = shape[:2]
    m = np.zeros((H, W), bool)
    for L, g in zip(lines, gl):
        c = dil_ss(g.full, _reach(L))
        m |= c.reshape(H, SS, W, SS).max(axis=(1, 3)) > 0.01
    return m


def protect_mask(orig, T):
    """pixels never touched: rects ("protect", x0,y0,x1,y1) and lettering selected by
    colour inside a box, grown ("protect_glyphs": [{"box", "rule", "grow"}])."""
    m = np.zeros(orig.shape[:2], bool)
    for x0, y0, x1, y1 in T.get("protect", []):
        m |= rect_mask(orig.shape, (x0, y0, x1 - x0, y1 - y0))
    for P in T.get("protect_glyphs", []):
        x0, y0, x1, y1 = P["box"]
        g = colour_rule(orig, P["rule"]) & rect_mask(orig.shape, (x0, y0, x1 - x0, y1 - y0))
        if "min_cy" in P and g.any():     # keep only glyph components centred below min_cy
            lab, n = ndi.label(g, np.ones((3, 3), bool))
            cs = ndi.center_of_mass(g, lab, range(1, n + 1))
            g = np.isin(lab, [i + 1 for i, (cy, cx) in enumerate(cs) if cy >= P["min_cy"]])
        # (iterations=0 would dilate until convergence: only dilate for grow >= 1)
        m |= ndi.binary_dilation(g, np.ones((3, 3), bool), iterations=P.get("grow", 3)) \
            if (g.any() and P.get("grow", 3) >= 1) else g
    return m


def title_allow(orig, T):
    m = title_footprint(orig, T["groups"]) | title_cover(orig.shape, T["lines"], title_lines(orig.shape, T["lines"]))
    if "box" in T:
        x0, y0, x1, y1 = T["box"]
        m &= rect_mask(orig.shape, (x0, y0, x1 - x0, y1 - y0))
    return m & ~protect_mask(orig, T)


def title_allow_s(orig, s):
    return title_allow(orig, s["title"])


def paint_line(lay, a, orig, L, g, fp):
    G = g.full
    y0, y1 = g.ink[1], g.ink[3]
    outl = L.get("outline", [])
    tot = sum(r for r, _ in outl)
    if "glow" in L:
        gw = L["glow"]
        lay.paint(np.clip(blur_ss(dil_ss(G, gw["r"]), gw["r"] * 0.6) * gw.get("alpha", 0.8), 0, 1), gw["colour"])
    if "shadow" in L:
        s = L["shadow"]
        m = blur_ss(shift_ss(dil_ss(G, tot + s.get("grow", 0)), s["dx"], s["dy"]), s.get("blur", 0))
        lay.paint(m * s.get("alpha", 1.0), s["colour"])
    acc = tot
    for r, c in outl:              # outermost first
        lay.paint(dil_ss(G, acc), c)
        acc -= r
    f = L["fill"]
    if isinstance(f, (list, tuple)):
        lay.paint(G, f)
        return
    # remap the old letters' surface: rows (oy0..oy1) of the old fill pixels in box
    x0, oy0, x1, oy1 = f["band"]
    old = np.zeros(a.shape[:2], bool)
    old[oy0:oy1, x0:x1] = True
    rr = np.zeros(a.shape[:2], bool)
    for rule in f["rules"]:
        rr |= colour_rule(orig, rule)
    old &= rr & (ndi.binary_erosion(fp, iterations=f["inner"]) if f.get("inner") else fp)
    if f.get("mode", "texture") == "profile":
        ys, cols = row_profile(orig, old)
        lay.paint(G, profile_fill(a.shape, ys, cols, y0, y1))
        return
    src = orig_colour_image(orig, old)
    ysrc = np.nonzero(old.any(axis=1))[0]
    Hs = a.shape[0]
    rows = np.clip(np.rint(np.interp(np.arange(Hs) + 0.5, [y0, y1], [ysrc.min(), ysrc.max() + 1]) - 0.5),
                   0, Hs - 1).astype(int)
    xs = np.nonzero(old.any(axis=0))[0]
    W = a.shape[1]
    # horizontal: tile the old surface across the new width (keeps the grain scale)
    gx0, gx1 = g.ink[0], g.ink[2]
    span = max(1, xs.max() - xs.min())
    cols_ = (xs.min() + (np.arange(W) - int(gx0)) % span).clip(0, W - 1)
    tex = src[rows][:, cols_]
    lay.paint(G, up(tex))


def title(a, orig, o, colors, allow):
    """hook: o = {"key", "title": T} with T = {"groups": [...], "lines": [...]}."""
    T = o["title"]
    key = o["key"]
    fp = title_footprint(orig, T["groups"]) & allow
    fp &= ~protect_mask(orig, T)
    gl = title_lines(a.shape, T["lines"])
    H, W = a.shape[:2]
    opaque = np.zeros((H, W), bool)
    for L, g in zip(T["lines"], gl):
        tot = sum(r for r, _ in L.get("outline", []))
        c = dil_ss(g.full, tot).reshape(H, SS, W, SS).mean(axis=(1, 3))
        opaque |= c >= 0.98
    todo = fp & ~opaque
    bx = T.get("valid_box", T.get("box", (0, 0, W, H)))
    valid = rect_mask(a.shape, (bx[0], bx[1], bx[2] - bx[0], bx[3] - bx[1])) & ~fp
    if "donor" in T:      # only background pixels may be copied (not other lettering)
        valid &= ndi.binary_erosion(background_rule(orig, T["donor"]), iterations=1)
    for x2, (bx0, by0, bx1, by1) in T.get("local_mirror", []):
        # a locally symmetric part (casino: each card's round crest about its own centre)
        sel = todo & rect_mask(a.shape, (bx0, by0, bx1 - bx0, by1 - by0))
        ys, xs = np.nonzero(sel)
        xm = x2 - 1 - xs
        okm = (xm >= 0) & (xm < W)
        ys, xs, xm = ys[okm], xs[okm], xm[okm]
        src_ok = ~fp[ys, xm] & ~background_rule(orig, T.get("mirror_bg", "green"))[ys, xm]
        a[ys[src_ok], xs[src_ok]] = orig[ys[src_ok], xm[src_ok]]
        todo[ys[src_ok], xs[src_ok]] = False
    if "mirror_x2" in T:
        # symmetric art (casino: the two cards mirror each other about x = mirror_x2/2):
        # a hole pixel whose mirror image is known, non-background art takes that pixel
        ys, xs = np.nonzero(todo)
        xm = T["mirror_x2"] - 1 - xs
        okm = (xm >= 0) & (xm < W)
        ys, xs, xm = ys[okm], xs[okm], xm[okm]
        src_ok = ~fp[ys, xm] & ~background_rule(orig, T.get("mirror_bg", "green"))[ys, xm]
        a[ys[src_ok], xs[src_ok]] = orig[ys[src_ok], xm[src_ok]]
        todo[ys[src_ok], xs[src_ok]] = False
        valid |= np.isin(np.arange(H)[:, None] * W + np.arange(W)[None, :],
                         ys[src_ok] * W + xs[src_ok])
    if T.get("rebuild", "exemplar") == "clear":
        a[todo] = clear_px(orig, T["clear_from"])
    elif T.get("rebuild") == "smooth":
        smooth_fill(a, todo, valid, T.get("sigmas", (2.0, 4.0, 8.0, 16.0)))
    elif T.get("rebuild") == "ray":
        left = ray_fill(a, todo, valid, *T["centre"])
        if left.any():
            smooth_fill(a, left, valid | (todo & ~left))
        # soften the per-row streaks a ray fill leaves near the burst's horizontal axis and
        # the seam to the untouched pixels: light blur of the filled pixels only
        if T.get("soften", 1.2) > 0:
            from batch_d_banner_art import lowpass
            sup = ndi.binary_dilation(todo, iterations=3) & (valid | todo)
            lp = lowpass(a.astype(np.float32), sup, T.get("soften", 1.2))
            a[todo] = np.clip(np.rint(lp[todo]), 0, 255).astype(np.uint8)
    else:
        a[todo] = 0
        rebuild(a, todo, valid | todo, P=T.get("P", 4), win=T.get("win", 40), seed=T.get("seed", 1))
    lay = Layer(a.shape)
    for L, g in zip(T["lines"], gl):
        paint_line(lay, a, orig, L, g, fp)
    put(a, lay.down(), allow, key, "title", orig=orig)


# ------------------------------------------------------------------ brand logo (option A)
# ETC title.txd (transparent surround) and SYSTEM allmap_1/2 (logo over the world map):
# the katakana ドカポン・ザ・ワールド become DOKAPON / THE WORLD in the logo's own
# style (yellow->orange gradient, black outline, navy extrusion, white sticker edge).
# Kept byte-identical: the small English 'DOKAPON THE WORLD' line and the dial, except
# the dial's left rim where the old ド covered it (rebuilt along its own circles).
def brand_parts(orig, B):
    H, W = orig.shape[:2]
    x0, y0, x1, y1 = B["box"]
    box = rect_mask(orig.shape, (x0, y0, x1 - x0, y1 - y0))
    cx, cy, R = B["dial"]
    yy, xx = np.mgrid[0:H, 0:W]
    dd = np.hypot(xx + 0.5 - cx, yy + 0.5 - cy)
    c = orig[..., :3].astype(np.int32)
    warm = (c[..., 0] > 190) & (c[..., 1] > 60) & (c[..., 0] - c[..., 2] > 150)
    dark = c.max(axis=2) < 70
    # old letters in front of the dial: warm (yellow/orange) components that also reach
    # outside the dial disc (the dial's own bronze/beige never does), + their outline,
    # extrusion and sticker edge (grown lp px inside the disc)
    disc = dd <= R + B.get("dial_pad", 4)
    # (the dial itself is bronze/beige/dark and its needle red: none of it is 'warm')
    lab, n = ndi.label(warm & box & disc, np.ones((3, 3), bool))
    if n:
        sz = ndi.sum(np.ones_like(lab), lab, range(1, n + 1))
        ids = 1 + np.nonzero(sz >= B.get("letter_min", 15))[0]
    else:
        ids = []
    lett = np.isin(lab, ids) & disc
    lett = ndi.binary_dilation(lett, iterations=B.get("letter_pad", 5)) & disc if lett.any() else lett
    dial = disc & ~lett
    if B.get("small") is None:          # the small English line is replaced too
        small = np.zeros((H, W), bool)
        logo = box & (orig[..., 3] > 0) if B["bg"] == "transparent" else \
            box & ndi.binary_fill_holes(B_logo_mask(orig, B))
        return logo & ~dial, dial, lett, dd
    px0, py0, px1, py1 = B["small"]
    sm = rect_mask(orig.shape, (px0, py0, px1 - px0, py1 - py0))
    inked = sm & (c.min(axis=2) < 200) & (orig[..., 3] > 64)
    # only the small line's own glyph components (centred above small_cy), not katakana tops
    lab, n = ndi.label(inked, np.ones((3, 3), bool))
    if n:
        cs = ndi.center_of_mass(inked, lab, range(1, n + 1))
        inked = np.isin(lab, [i + 1 for i, (yc, xc) in enumerate(cs) if yc < B["small_cy"]])
    small = ndi.binary_dilation(inked, iterations=B.get("small_pad", 4)) if inked.any() else inked
    if B["bg"] == "transparent":
        logo = box & (orig[..., 3] > 0)
    else:   # over the map: the logo = everything that is not ocean texture inside its outline
        logo = box & ndi.binary_fill_holes(B_logo_mask(orig, B))
    erase = logo & ~small & ~dial
    return erase, dial, lett, dd


def B_logo_mask(orig, B):
    """allmap: the logo sticker = white edge pixels + everything enclosed by them."""
    c = orig[..., :3].astype(np.int32)
    x0, y0, x1, y1 = B["box"]
    box = rect_mask(orig.shape, (x0, y0, x1 - x0, y1 - y0))
    white = (c.min(axis=2) > 200) & box
    warm = (c[..., 0] > 190) & (c[..., 1] > 60) & (c[..., 0] - c[..., 2] > 150) & box
    dark = (c.max(axis=2) < 60) & box
    m = ndi.binary_closing(white | warm | dark, np.ones((3, 3), bool), iterations=2)
    return ndi.binary_fill_holes(m) & box


def brand_glyphs(shape, B):
    return title_lines(shape, B["lines"])


def brand_allow(orig, s):
    B = s["brand"]
    erase, dial, lett, dd = brand_parts(orig, B)
    gl = brand_glyphs(orig.shape, B)
    H, W = orig.shape[:2]
    cov = np.zeros((H, W), bool)
    for L, g in zip(B["lines"], gl):
        c = dil_ss(g.full, B["outline"] + B["sticker"] + 1.5)
        c = np.maximum(c, shift_ss(c, B["extrude"][0], B["extrude"][1]))
        cov |= c.reshape(H, SS, W, SS).max(axis=(1, 3)) > 0.01
    x0, y0, x1, y1 = B["box"]
    _, _, R = B["dial"]
    # the new letters may stand in front of the dial, as the old ド did
    return (erase | lett | cov) & rect_mask(orig.shape, (x0, y0, x1 - x0, y1 - y0))


def brand_logo(a, orig, o, colors, allow):
    key = o["key"]
    B = o["brand"]
    erase, dial, lett, dd = brand_parts(orig, B)
    erase &= allow
    cx, cy, R = B["dial"]
    # 1) the old letters over the dial: rebuild the dial.  Its rim/sticker rings by
    #    angular interpolation (they are circles); the face by patch copy from the
    #    visible part of the face
    H, W = a.shape[:2]
    yy, xx = np.mgrid[0:H, 0:W]
    rim0 = R * B.get("rim_frac", 0.80)
    ringpart = lett & allow & (dd >= rim0)
    cc = orig[..., :3].astype(np.int32)
    warm_ = (cc[..., 0] > 190) & (cc[..., 1] > 60) & (cc[..., 0] - cc[..., 2] > 150)
    ring_polar(a, ringpart, cx, cy, rim0, R + B.get("dial_pad", 4),
               unknown=erase | lett | ndi.binary_dilation(warm_, iterations=6))
    face = lett & allow & (dd < rim0)
    if face.any():
        cc = orig[..., :3].astype(np.int32)
        warm = (cc[..., 0] > 190) & (cc[..., 1] > 60) & (cc[..., 0] - cc[..., 2] > 150)
        src = (dd < rim0) & ~(erase | lett) & ~ndi.binary_dilation(warm, iterations=4)
        # the face is plain parchment where the old letter hid it: its smooth local colour
        smooth_fill(a, face, src | face, sigmas=(3.0, 6.0, 12.0, 24.0))
    # 2) everything else of the old logo: transparent (title) or the map (allmap)
    rest = erase & ~lett
    if B["bg"] == "transparent":
        a[rest] = clear_px(orig, B["clear_from"])
    else:
        x0, y0, x1, y1 = B["box"]
        valid = rect_mask(a.shape, (x0, y0, x1 - x0 + 40, y1 - y0 + 40)) & ~B_logo_mask(orig, B)
        a[rest] = 0
        rebuild(a, rest, valid | rest, P=4, win=40, seed=2)
    # 3) the new lettering: one sticker for both lines
    gl = brand_glyphs(a.shape, B)
    o_ = orig[..., :3].astype(np.int32)
    old_fill = (o_[..., 0] > 190) & (o_[..., 1] > 60) & (o_[..., 0] - o_[..., 2] > 150) & erase
    ys, cols = row_profile(orig, old_fill & ~lett)
    lay = Layer(a.shape)
    G_all = np.zeros_like(gl[0].full)
    for g in gl:
        G_all = np.maximum(G_all, g.full)
    ol = B["outline"]
    ex = B["extrude"]
    st = B["sticker"]
    body = np.maximum(dil_ss(G_all, ol), 0)
    exm = np.zeros_like(body)
    n = int(max(abs(ex[0]), abs(ex[1])) * SS) or 1
    for k in range(1, n + 1):
        exm = np.maximum(exm, shift_ss(body, ex[0] * k / n, ex[1] * k / n))
    sticker = dil_ss(np.maximum(body, exm), st)
    lay.paint(sticker, (255, 255, 255))
    lay.paint(exm, B["extrude_colour"])
    lay.paint(body, (0, 0, 0))
    for g in gl:
        lay.paint(g.full, profile_fill(a.shape, ys, cols, g.ink[1], g.ink[3]))
        # light top bevel like the katakana
        inner = np.clip(g.full - shift_ss(g.full, 0, -1.5 * B.get("scale", 1.0)), 0, 1) * g.full
        lay.paint(inner * 0.5, (255, 250, 200))
    put(a, lay.down(), allow, key, "brand", orig=orig)


# ------------------------------------------------------------------ brand logo v2 (owner 2026-10-01)
# Owner: do not invent the hidden dial; REUSE the game's own English 'DOKAPON THE WORLD'
# lettering (the small line on ETC title.txd, x 103..272, y 66..95, saved as
# generated/explainer-specs/batch_e_parts/title_small_line.png) scaled up in place of the
# katakana.  The new lettering + its sticker must cover every pixel of the old ド that lies
# on the dial (the dial itself is never repainted), the way the JP logo overlapped it.
PARTS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                     "generated", "explainer-specs", "batch_e_parts")


def reuse_layer(shape, B):
    """supersampled lettering layer from the small-line crop: each segment
    {"src":[x0,x1] (crop columns), "at":[x,y] (top-left, texture px), "scale":s}.
    Returns (Layer, glyph coverage SS, backing coverage SS)."""
    H, W = shape[:2]
    src = np.array(Image.open(os.path.join(PARTS, "title_small_line.png")).convert("RGBA")).astype(np.float32)
    # keep the letters and their dark outline only: the light-grey anti-aliasing towards the
    # small line's white sticker would scale up into a dotted grey ring
    mn, mxv = src[..., :3].min(axis=2), src[..., :3].max(axis=2)
    src[..., 3] = np.where((mn < 140) | (mxv - mn > 60), src[..., 3], 0)
    glyph = np.zeros((H * SS, W * SS), np.float32)
    rgbp = np.zeros((H * SS, W * SS, 3), np.float32)
    for seg in B["segments"]:
        x0, x1 = seg["src"]
        part = src[:, x0:x1]
        s = seg["scale"] * SS
        h, w = part.shape[:2]
        tw, th = max(1, int(round(w * s))), max(1, int(round(h * s)))
        al = part[..., 3:4] / 255.0
        pre = Image.fromarray(np.clip(part[..., :3] * al, 0, 255).astype(np.uint8), "RGB").resize((tw, th), Image.BICUBIC)
        alp = Image.fromarray(part[..., 3].astype(np.uint8), "L").resize((tw, th), Image.BICUBIC)
        pre = np.array(pre).astype(np.float32)
        alp = np.array(alp).astype(np.float32) / 255.0
        ox, oy = int(round(seg["at"][0] * SS)), int(round(seg["at"][1] * SS))
        Y0, X0 = max(0, oy), max(0, ox)
        Y1, X1 = min(H * SS, oy + th), min(W * SS, ox + tw)
        glyph[Y0:Y1, X0:X1] = np.maximum(glyph[Y0:Y1, X0:X1], alp[Y0 - oy:Y1 - oy, X0 - ox:X1 - ox])
        rgbp[Y0:Y1, X0:X1] += pre[Y0 - oy:Y1 - oy, X0 - ox:X1 - ox]
    with np.errstate(invalid="ignore", divide="ignore"):
        rgb = np.where(glyph[..., None] > 0, rgbp / np.maximum(glyph[..., None], 1e-6), 0)
    rgb = np.clip(rgb, 0, 255)
    lay = Layer(shape)
    back = dil_ss((glyph > 0.5).astype(np.float32), B["sticker"])
    ex = np.zeros_like(back)
    if B.get("extrude"):
        dx, dy = B["extrude"]
        n = int(max(abs(dx), abs(dy)) * SS) or 1
        for k in range(1, n + 1):
            ex = np.maximum(ex, shift_ss(dil_ss((glyph > 0.5).astype(np.float32), B.get("extrude_r", 1.0)),
                                         dx * k / n, dy * k / n))
        back = np.maximum(back, dil_ss(ex, B["sticker"] * 0.6))
    lay.paint(back, B["sticker_colour"])
    if B.get("extrude"):
        lay.paint(ex, B["extrude_colour"])
    lay.paint(glyph, rgb)
    return lay, glyph, back


def brand2_parts(orig, B):
    Bx = dict(B, small=None)
    erase, dial, lett, dd = brand_parts(orig, Bx)
    if B["bg"] != "transparent":   # the map logo's soft dark rim around the letters
        erase = ndi.binary_dilation(erase, iterations=B.get("erase_pad", 1)) & ~dial & \
            rect_mask(orig.shape, (B["box"][0], B["box"][1], B["box"][2] - B["box"][0], B["box"][3] - B["box"][1]))
    return erase, dial, lett


def brand2_allow(orig, s):
    B = s["brand"]
    erase, dial, lett = brand2_parts(orig, B)
    lay, glyph, back = reuse_layer(orig.shape, B)
    H, W = orig.shape[:2]
    cov = lay.down()[..., 3] > 0
    x0, y0, x1, y1 = B["box"]
    return (erase | lett | cov) & rect_mask(orig.shape, (x0, y0, x1 - x0, y1 - y0))


def brand_logo2(a, orig, o, colors, allow):
    key = o["key"]
    B = o["brand"]
    erase, dial, lett = brand2_parts(orig, B)
    lay, glyph, back = reuse_layer(a.shape, B)
    L = lay.down()
    opaque = L[..., 3] >= 254
    miss = lett & ~opaque
    if miss.sum() > B.get("max_uncovered", 0):
        ys, xs = np.nonzero(miss)
        raise SystemExit("%s: %d old-letter px on the dial left uncovered, e.g. %s" % (
            key, len(xs), list(zip(xs.tolist(), ys.tolist()))[:8]))
    rest = erase & ~opaque & allow
    if B["bg"] == "transparent":
        a[rest] = clear_px(orig, B["clear_from"])
    else:
        x0, y0, x1, y1 = B["box"]
        valid = rect_mask(a.shape, (max(0, x0 - 30), max(0, y0 - 20), x1 - x0 + 60, y1 - y0 + 40)) & \
            ~ndi.binary_dilation(B_logo_mask(orig, B), iterations=2) & ~dial
        cc = orig[..., :3].astype(np.int32)
        valid &= (cc[..., 2] > cc[..., 0] + 30)          # ocean only (no land / white islands)
        a[rest] = 0
        rebuild(a, rest, valid | rest, P=4, win=40, seed=2)
    put(a, L, allow, key, "brand2", orig=orig)
