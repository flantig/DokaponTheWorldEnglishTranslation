import pathlib,hashlib,json,ast,sys,datetime,platform
import numpy as np
import scipy
import scipy.ndimage as ndi
import PIL
w=pathlib.Path(__file__).parent;source=pathlib.Path('/home/franklinl/Documents/Dokapon World Mod/tools/batch_e_art.py');raw=source.read_bytes();(w/'batch_e_art.py').write_bytes(raw);tree=ast.parse(raw);names=['rect_mask','op_label_rect','op_allow','button_disc','button_allow','sale_regions','sale_allow'];constants=['OP_COLOURS','OP_LABEL_X0','OP_OK','SALE','SALE_X'];nodes=[];pins=[]
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in names or isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constants for t in node.targets):
  nodes.append(node);segment=ast.get_source_segment(raw.decode(),node);pins.append({'name':getattr(node,'name',','.join(t.id for t in node.targets if isinstance(t,ast.Name)) if isinstance(node,ast.Assign) else '?'),'line':node.lineno,'end_line':node.end_lineno,'sha256':hashlib.sha256(segment.encode()).hexdigest()})
authority={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'source_sha256':hashlib.sha256(raw).hexdigest(),'source_bytes':len(raw),'isolated_nodes':pins,'interpreter':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'pillow':PIL.__version__,'original_helpers_called':False,'module_top_level_imports_not_executed':True};(w/'source-authority-before-calls.json').write_text(json.dumps(authority,indent=2)+'\n')
zero7=['0000000']*7;center7=zero7.copy();center7[3]='0001000'
cases=[('cross1-center','dilation','cross',1,center7,['0000000','0000000','0001000','0011100','0001000','0000000','0000000']),('square1-center','dilation','square',1,center7,['0000000','0000000','0011100','0011100','0011100','0000000','0000000']),('cross3-center','dilation','cross',3,center7,['0001000','0011100','0111110','1111111','0111110','0011100','0001000']),('square3-center','dilation','square',3,center7,['1111111']*7),('cross1-edge','dilation','cross',1,['1000','0000','0000','0000'],['1100','1000','0000','0000']),('square1-edge','dilation','square',1,['1000','0000','0000','0000'],['1100','1100','0000','0000']),('cross3-edge','dilation','cross',3,['1000','0000','0000','0000'],['1111','1110','1100','1000']),('square3-edge','dilation','square',3,['1000','0000','0000','0000'],['1111']*4),('cross-erosion-plus','erosion','cross',1,['010','111','010'],['000','010','000']),('square-erosion-plus','erosion','square',1,['010','111','010'],['000','000','000']),('fill4-diagonal-hole','fill','cross',0,['011','101','111'],['011','111','111']),('fill8-diagonal-hole-counterexample','fill','square',0,['011','101','111'],['011','101','111']),('square-erosion-full3','erosion','square',1,['111','111','111'],['000','010','000'])]
manual=[]
for id,operation,kernel,iterations,inp,expected in cases:
 inputraw=bytes(int(x) for line in inp for x in line);outraw=bytes(int(x) for line in expected for x in line);(w/(id+'.input.mask')).write_bytes(inputraw);(w/(id+'.expected.mask')).write_bytes(outraw);manual.append({'id':id,'operation':operation,'kernel':kernel,'iterations':iterations,'shape':[len(inp),len(inp[0])],'input_rows':inp,'expected_rows':expected,'expected_count':sum(outraw),'input_blob':id+'.input.mask','expected_blob':id+'.expected.mask','expected_sha256':hashlib.sha256(outraw).hexdigest()})
rects=[[233,255,54,17],[233,284,54,17],[233,313,54,17],[233,342,54,17],[233,371,54,17],[337,255,54,17],[337,284,54,17],[337,313,54,17],[337,342,54,17],[337,371,54,17],[385,3,50,28]]
extra={'op11_rectangles':rects,'op_count':10580,'button_cells':[[32*(i%4),32*(i//4),32,32] for i in range(16)],'all_opaque129_button_cells_expected_interior':{'offset':[1,1],'size':[30,30],'count':14400},'seam_window_input_rows':['000000','011110','011110','011110','011110','000000'],'seam_global_square_eroded_rows':['000000','000000','001100','001100','000000','000000'],'seam_per_cell_square_eroded_rows':['000000']*6,'alpha_boundary':{'RGBA':[[[0,0,0,128],[0,0,0,129]]],'expected_rows':['01']},'sale_threshold':{'RGBA':[[[90,90,90,40],[91,0,0,40]],[[90,90,90,41],[91,0,0,41]]],'expected_rows':['00','01']},'sale_rectangles':[[20,0,87,18],[20,32,87,18],[20,66,87,30],[20,97,87,30]],'sale_bands':[[20,17,87,15],[20,49,87,15]],'sale_single_seed':{'canvas':[512,512],'RGBA_seed':[20,17,91,0,0,41],'window':[17,14,7,7],'expected_raw_protection_rows':['1111111']*7,'expected_reg_window_before_rows':['0001111']*4+['0000000']*3,'expected_reg_window_after_rows':['0000000']*7,'expected_raw_protection_count':49,'expected_sale_allow_count':8336},'sale_late_band_seeds_do_not_veto_other_signs':{'seeds':[[104,31],[50,63]],'allowed_points':[[104,32],[50,66]],'reason':'Each prot is subtracted only from its own corresponding sign region before union.'}}
(w/'manual-expectations.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FROZEN_BEFORE_ORIGINAL_HELPER_CALLS','bitmaps':manual,'extra_source_equations':extra},indent=2)+'\n')
# Independently authored full source-context expectations, still no helper calls.
contexts=[]
for name in ['A','B']:
 a=np.zeros((512,512,4),dtype=np.uint8)
 if name=='A':
  a[:128,:128,3]=129;seeds=[(20,17,91,0,0,41),(24,17,90,90,90,41),(28,17,91,0,0,40),(50,49,91,0,0,41)];true=[[20,17],[50,49]]
 else:
  for i in range(16):
   x,y=32*(i%4),32*(i//4);a[y+12:y+17,x+12:x+17]=(50,40,30,129);a[y+14,x+14,3]=0;a[y+3:y+6,x+3:x+6]=(0,0,0,129 if i%2==0 else 128)
  seeds=[(20,17,91,0,0,40),(24,17,90,90,90,41),(30,17,91,0,0,41),(104,31,91,0,0,41),(70,49,91,0,0,41),(50,63,91,0,0,41)];true=[[30,17],[104,31],[70,49],[50,63]]
 for x,y,R,G,B,A in seeds:a[y,x]=(R,G,B,A)
 (w/('fixture-'+name+'.rgba')).write_bytes(a.tobytes());current=np.zeros_like(a) if name=='A' else np.full_like(a,255);(w/('current-'+name+'.rgba')).write_bytes(current.tobytes());op=np.zeros((512,512),bool)
 for x,y,ww,hh in rects:op[y:y+hh,x:x+ww]=True
 button=np.zeros((512,512),bool)
 for i in range(16):
  x,y=32*(i%4),32*(i//4)
  if name=='A':button[y+1:y+31,x+1:x+31]=True
  else:
   button[y+13:y+16,x+13:x+16]=True
   if i%2==0:button[y+4,x+4]=True
 sale=np.zeros((512,512),bool);prots=[]
 for i,(x,y,ww,hh) in enumerate(extra['sale_rectangles']):
  reg=np.zeros_like(sale);reg[y:y+hh,x:x+ww]=True;prot=np.zeros_like(sale)
  if i<2:
   for xx,yy in true:
    if 17+32*i<=yy<32+32*i:prot[max(0,yy-3):yy+4,max(0,xx-3):xx+4]=True
  sale|=reg&~prot;prots.append(prot)
 for provider,mask in [('op_allow',op),('button_allow',button),('sale_allow',sale)]: (w/(name+'-'+provider+'.expected.mask')).write_bytes(mask.astype(np.uint8).tobytes())
 contexts.append({'id':name,'fixture':'fixture-'+name+'.rgba','current':'current-'+name+'.rgba','true_sale_seeds':true,'manual_counts':{'op_allow':int(op.sum()),'button_allow':int(button.sum()),'sale_allow':int(sale.sum())},'expected_masks':{k:name+'-'+k+'.expected.mask' for k in ['op_allow','button_allow','sale_allow']}})
(w/'context-equations-before-calls.json').write_text(json.dumps(contexts,indent=2)+'\n');files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(w.iterdir()) if p.is_file() and p.name!='prepare.py'};(w/'pre-original-freeze.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_helpers_called':False,'files':files},indent=2)+'\n');print('sourceSHA',authority['source_sha256']);print('manualfreezeSHA',hashlib.sha256((w/'manual-expectations.json').read_bytes()).hexdigest());print('prefreezeSHA',hashlib.sha256((w/'pre-original-freeze.json').read_bytes()).hexdigest());print(contexts)
