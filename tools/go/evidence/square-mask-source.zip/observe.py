import pathlib,json,hashlib,ast,sys,zipfile
import numpy as np
from scipy import ndimage as ndi
w=pathlib.Path(__file__).parent;freeze=json.loads((w/'pre-original-freeze.json').read_text())
for n,h in freeze['files'].items():assert hashlib.sha256((w/n).read_bytes()).hexdigest()==h,n
manual=json.loads((w/'manual-expectations.json').read_text());small=[]
for c in manual['bitmaps']:
 a=np.frombuffer((w/c['input_blob']).read_bytes(),np.uint8).reshape(c['shape']).astype(bool);structure=np.ones((3,3),bool) if c['kernel']=='square' else ndi.generate_binary_structure(2,1)
 if c['operation']=='fill':out=ndi.binary_fill_holes(a,structure=structure)
 elif c['operation']=='erosion':out=ndi.binary_erosion(a,structure=structure,iterations=c['iterations'])
 else:out=ndi.binary_dilation(a,structure=structure,iterations=c['iterations'])
 assert out.astype(np.uint8).tobytes()==(w/c['expected_blob']).read_bytes(),c['id'];small.append({'id':c['id'],'manual_expected_equal':True,'count':int(out.sum())})
tree=ast.parse((w/'batch_e_art.py').read_text());names={'rect_mask','op_label_rect','op_allow','button_disc','button_allow','sale_regions','sale_allow'};constants={'OP_COLOURS','OP_LABEL_X0','OP_OK','SALE','SALE_X'};nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constants for t in n.targets)];env={'np':np,'ndi':ndi};exec(compile(ast.Module(body=nodes,type_ignores=[]),'frozen-original-pure-permissions','exec'),env)
assert [list(env['op_label_rect'](r)) for r,_,_ in env['OP_COLOURS']]+[list(env['OP_OK'])]==manual['extra_source_equations']['op11_rectangles']
observations=[];stageledger=[];exceptions=[]
for ctx in json.loads((w/'context-equations-before-calls.json').read_text()):
 id=ctx['id'];orig=np.frombuffer((w/ctx['fixture']).read_bytes(),np.uint8).reshape(512,512,4).copy();before=orig.tobytes();current=np.frombuffer((w/ctx['current']).read_bytes(),np.uint8).reshape(512,512,4).copy()
 for provider in ['op_allow','button_allow','sale_allow']:
  mask=env[provider](orig,{});blob=id+'-'+provider+'.source.mask';raw=mask.astype(np.uint8).tobytes();(w/blob).write_bytes(raw);assert raw==(w/ctx['expected_masks'][provider]).read_bytes();wrong=env[provider](current,{});wrongblob=id+'-'+provider+'.WRONG-current.mask';(w/wrongblob).write_bytes(wrong.astype(np.uint8).tobytes());assert env[provider](orig,{}).astype(np.uint8).tobytes()==raw;observations.append({'id':id+'/'+provider,'provider':provider,'fixture':ctx['fixture'],'mask':blob,'mask_sha256':hashlib.sha256(raw).hexdigest(),'count':int(mask.sum()),'manual_full_mask_equal':True,'wrong_current_count':int(wrong.sum()),'wrong_current_differs':bool(np.any(mask!=wrong)),'wrong_current_mask':wrongblob,'whole_original_preserved':orig.tobytes()==before})
 for i in range(16):
  x,y=32*(i%4),32*(i//4);alpha=orig[y:y+32,x:x+32,3]>128;filled=ndi.binary_fill_holes(alpha);eroded=ndi.binary_erosion(filled,np.ones((3,3),bool),iterations=1);disc=env['button_disc'](orig,i);assert np.array_equal(disc[y:y+32,x:x+32],eroded);assert int(disc.sum())==int(eroded.sum())
  for stage,mask in [('alpha',alpha),('fill4',filled),('square_erode1',eroded),('disc_full',disc)]:
   blob=f'{id}-button-{i:02d}-{stage}.mask';raw=mask.astype(np.uint8).tobytes();(w/blob).write_bytes(raw);stageledger.append({'context':id,'provider':'button_disc','cell':i,'rect':[x,y,32,32],'stage':stage,'shape':list(mask.shape),'blob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'count':int(mask.sum())})
 regions=env['sale_regions'](orig)
 for i,((regafter,prot),(x,y,ww,hh)) in enumerate(zip(regions,manual['extra_source_equations']['sale_rectangles'])):
  reg=env['rect_mask'](orig.shape,(x,y,ww,hh));band=env['rect_mask'](orig.shape,(20,17+32*i,87,15)) if i<2 else np.zeros((512,512),bool);glyph=band&(orig[...,3]>40)&(orig[...,:3].astype(np.int32).max(axis=2)>90);assert np.array_equal(regafter,reg&~prot)
  for stage,mask in [('reg_before',reg),('band',band),('glyph',glyph),('protection_full',prot),('protection_clipped_own',prot&reg),('reg_after',regafter)]:
   blob=f'{id}-sale-{i}-{stage}.mask';raw=mask.astype(np.uint8).tobytes();(w/blob).write_bytes(raw);stageledger.append({'context':id,'provider':'sale_regions','region':i,'rect':[x,y,ww,hh],'stage':stage,'shape':[512,512],'blob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'count':int(mask.sum())})
 if id=='B':
  final=env['sale_allow'](orig,{});assert final[32,104] and final[66,50];assert regions[0][1][32,104] and regions[1][1][66,50];wrong=np.logical_or.reduce([env['rect_mask'](orig.shape,r) for r in manual['extra_source_equations']['sale_rectangles']])&~np.logical_or.reduce([x[1] for x in regions]);assert not wrong[32,104] and not wrong[66,50];(w/'B-WRONG-global-unclipped-sale.mask').write_bytes(wrong.astype(np.uint8).tobytes())
 assert orig.tobytes()==before
single=np.zeros((512,512,4),np.uint8);single[17,20]=(91,0,0,41);regions=env['sale_regions'](single);assert regions[0][1][14:21,17:24].astype(np.uint8).tobytes()==bytes([1])*49 and not regions[0][0][14:21,17:24].any() and int(env['sale_allow'](single,{}).sum())==8336
for provider in ['button_allow','sale_allow']:
 try:env[provider](np.zeros((512,512,3),np.uint8),{});raise AssertionError('expected RGB-only channel refusal')
 except IndexError as exc:exceptions.append({'provider':provider,'input_shape':[512,512,3],'source_exception':'IndexError','text':str(exc),'not_a_Go_wire_refusal':True})
# The numeric kernel/manual and pure-provider observations are separate from wire.
(w/'observations.json').write_text(json.dumps({'small_manual_cases':small,'providers':observations,'all_manual_and_original_assertions_passed':True,'source_exceptions':exceptions,'original_module_main_font_art_hooks_executed':False,'source_input_bytes_preserved':True},indent=2)+'\n');(w/'stages.json').write_text(json.dumps(stageledger,indent=2)+'\n')
print('PASS manual',len(small),'providerwhole',len(observations),'stages',len(stageledger),'exceptions',len(exceptions))
